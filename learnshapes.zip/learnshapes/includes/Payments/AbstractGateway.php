<?php
namespace Learnshapes\Payments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Abstract Payment Gateway Base Class.
 *
 * All payment gateways must extend this class and implement process_payment().
 * Provides common functionality: option storage, enable/disable state, and
 * checkout field rendering with proper hooks.
 */
abstract class AbstractGateway {

	/** @var string Gateway unique ID (e.g. 'paypal', 'offline'). */
	public $id = '';

	/** @var string Gateway display title shown to customers. */
	public $title = '';

	/** @var string Short description shown at checkout. */
	public $description = '';

	/** @var bool Whether this gateway is currently enabled. */
	public $enabled = false;

	/** @var int Order in the checkout payment list. */
	public $order = 99;

	/** @var string Icon URL (optional). */
	public $icon = '';

	/**
	 * Constructor — loads enabled state from DB.
	 */
	public function __construct() {
		$this->enabled = $this->get_option( 'enabled', 'no' ) === 'yes';
		$this->order   = (int) $this->get_option( 'order', 99 );
	}

	/**
	 * Process payment for a given order ID.
	 * Must return array with 'result' key ('success'|'failure') and optionally 'redirect_url'.
	 * May return WP_Error on failure.
	 *
	 * @param  int $order_id
	 * @return array|\WP_Error
	 */
	abstract public function process_payment( $order_id );

	/**
	 * Get a stored option for this gateway.
	 *
	 * @param  string $key
	 * @param  mixed  $default
	 * @return mixed
	 */
	public function get_option( $key, $default = '' ) {
		$settings = get_option( 'learnshapes_payment_' . $this->id, [] );
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Update a stored option for this gateway.
	 *
	 * @param string $key
	 * @param mixed  $value
	 */
	public function update_option( $key, $value ) {
		$settings          = get_option( 'learnshapes_payment_' . $this->id, [] );
		$settings[ $key ]  = $value;
		update_option( 'learnshapes_payment_' . $this->id, $settings );
	}

	/**
	 * Render any additional fields inside the payment box on the checkout page.
	 * Override in child gateway for gateway-specific fields.
	 */
	public function render_checkout_fields() {
		do_action( 'learnshapes_payment_checkout_fields', $this->id, $this );
	}

	/**
	 * Validate checkout fields before order creation.
	 * Return true if valid, WP_Error if not.
	 *
	 * @return true|\WP_Error
	 */
	public function validate_checkout_fields() {
		return apply_filters( 'learnshapes_validate_checkout_fields_' . $this->id, true, $this );
	}

	/**
	 * Whether this gateway is currently enabled.
	 *
	 * @return bool
	 */
	public function is_enabled() {
		return (bool) $this->enabled;
	}

	/**
	 * Human-readable gateway title used in admin.
	 *
	 * @return string
	 */
	public function get_title() {
		return apply_filters( 'learnshapes_gateway_title', $this->title, $this->id );
	}

	/**
	 * Human-readable description shown at checkout.
	 *
	 * @return string
	 */
	public function get_description() {
		return apply_filters( 'learnshapes_gateway_description', $this->description, $this->id );
	}
}
