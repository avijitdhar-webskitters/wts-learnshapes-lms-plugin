<?php
namespace Learnshapes\Payments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Learnshapes Order Model.
 *
 * Wraps a row in wp_learnshapes_orders and provides business logic for
 * status transitions, enrollment triggering, and email notifications.
 */
class Order {

	/** @var int|null DB row ID. */
	private $id;

	/** @var array|null Raw DB row as associative array. */
	private $data;

	/**
	 * Constructor.
	 *
	 * @param int $id  Optional existing order ID to load.
	 */
	public function __construct( $id = 0 ) {
		if ( $id > 0 ) {
			$this->id = $id;
			$this->load();
		}
	}

	// ── Loaders ───────────────────────────────────────────────────────────────

	/**
	 * Load order data from DB.
	 */
	private function load() {
		global $wpdb;
		$this->data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}learnshapes_orders WHERE id = %d",
				$this->id
			),
			ARRAY_A
		);
	}

	// ── Getters ───────────────────────────────────────────────────────────────

	/** @return int */
	public function get_id() {
		return (int) $this->id;
	}

	/** @return string */
	public function get_status() {
		return $this->data['status'] ?? 'pending';
	}

	/** @return int */
	public function get_user_id() {
		return (int) ( $this->data['user_id'] ?? 0 );
	}

	/** @return int */
	public function get_course_id() {
		return (int) ( $this->data['course_id'] ?? 0 );
	}

	/** @return float */
	public function get_amount() {
		return (float) ( $this->data['amount'] ?? 0 );
	}

	/** @return string */
	public function get_currency() {
		return $this->data['currency'] ?? 'USD';
	}

	/** @return string */
	public function get_payment_gateway() {
		return $this->data['payment_gateway'] ?? '';
	}

	/** @return string */
	public function get_transaction_id() {
		return $this->data['transaction_id'] ?? '';
	}

	/** @return string */
	public function get_created_at() {
		return $this->data['created_at'] ?? '';
	}

	/** @return string */
	public function get_order_key() {
		return $this->data['order_key'] ?? '';
	}

	/**
	 * Return a human-friendly order number such as "ORDER-00042".
	 *
	 * @return string
	 */
	public function get_order_number() {
		$settings = get_option( 'learnshapes_settings', [] );
		$slug     = isset( $settings['payment']['order_slug'] ) ? sanitize_key( $settings['payment']['order_slug'] ) : 'order';
		return strtoupper( $slug ) . '-' . str_pad( $this->id, 5, '0', STR_PAD_LEFT );
	}

	/**
	 * Return all raw data (used for display in admin tables etc.).
	 *
	 * @return array
	 */
	public function get_data() {
		return $this->data ?? [];
	}

	// ── Mutators ──────────────────────────────────────────────────────────────

	/**
	 * Update the order status and optionally record a transaction ID.
	 * Fires the appropriate action hooks and triggers enrollment on completion.
	 *
	 * @param string $status         New status: pending|processing|completed|failed|cancelled.
	 * @param string $transaction_id Optional gateway transaction/reference ID.
	 */
	public function update_status( $status, $transaction_id = '' ) {
		global $wpdb;

		$allowed = [ 'pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded' ];
		$status  = in_array( $status, $allowed, true ) ? $status : 'pending';

		$update_data = [
			'status'     => $status,
			'updated_at' => current_time( 'mysql' ),
		];

		if ( $transaction_id ) {
			$update_data['transaction_id'] = $transaction_id;
		}

		$wpdb->update(
			$wpdb->prefix . 'learnshapes_orders',
			$update_data,
			[ 'id' => $this->id ]
		);

		$old_status          = $this->data['status'] ?? '';
		$this->data['status'] = $status;

		if ( $transaction_id ) {
			$this->data['transaction_id'] = $transaction_id;
		}

		// Fire general status change hook.
		do_action( 'learnshapes_order_status_changed', $this->id, $old_status, $status, $this );

		// Fire specific status hooks.
		do_action( "learnshapes_order_{$status}", $this->id, $this );

		// On completion: enroll the student and send receipt.
		if ( $status === 'completed' ) {
			GatewayManager::enroll_student(
				$this->get_user_id(),
				$this->get_course_id(),
				$this->get_payment_gateway(),
				$transaction_id,
				$this->get_amount()
			);
		}
	}

	// ── Statics ───────────────────────────────────────────────────────────────

	/**
	 * Create a new order record in the database.
	 *
	 * @param int    $user_id
	 * @param int    $course_id
	 * @param float  $amount
	 * @param string $currency
	 * @param string $gateway
	 * @param array  $extra     Optional extra columns (billing_email, billing_name, order_key).
	 * @return Order
	 */
	public static function create( $user_id, $course_id, $amount, $currency, $gateway, $extra = [] ) {
		global $wpdb;

		// Generate a unique order key for verification.
		$order_key = 'ls_' . wp_generate_password( 20, false );

		$insert = array_merge( [
			'user_id'         => $user_id,
			'course_id'       => $course_id,
			'amount'          => $amount,
			'currency'        => $currency,
			'payment_gateway' => $gateway,
			'status'          => 'pending',
			'order_key'       => $order_key,
			'created_at'      => current_time( 'mysql' ),
		], $extra );

		do_action( 'learnshapes_before_order_create', $insert );

		$wpdb->insert( $wpdb->prefix . 'learnshapes_orders', $insert );
		$id = $wpdb->insert_id;

		do_action( 'learnshapes_order_created', $id );

		return new self( $id );
	}

	/**
	 * Get list of orders with optional filters (admin list).
	 *
	 * @param array $args {
	 *   @type int    $user_id
	 *   @type int    $course_id
	 *   @type string $status
	 *   @type int    $limit
	 *   @type int    $offset
	 *   @type string $orderby
	 *   @type string $order
	 * }
	 * @return array Array of raw order rows.
	 */
	public static function get_orders( $args = [] ) {
		global $wpdb;

		$defaults = [
			'user_id'   => 0,
			'course_id' => 0,
			'status'    => '',
			'limit'     => 20,
			'offset'    => 0,
			'orderby'   => 'created_at',
			'order'     => 'DESC',
		];

		$args = wp_parse_args( $args, $defaults );

		$where  = [];
		$params = [];

		if ( $args['user_id'] ) {
			$where[]  = 'o.user_id = %d';
			$params[] = $args['user_id'];
		}
		if ( $args['course_id'] ) {
			$where[]  = 'o.course_id = %d';
			$params[] = $args['course_id'];
		}
		if ( $args['status'] ) {
			$where[]  = 'o.status = %s';
			$params[] = $args['status'];
		}

		$allowed_order = [ 'ASC', 'DESC' ];
		$order         = in_array( strtoupper( $args['order'] ), $allowed_order, true ) ? strtoupper( $args['order'] ) : 'DESC';

		$allowed_orderby = [ 'id', 'created_at', 'amount', 'status', 'user_id', 'course_id' ];
		$orderby         = in_array( $args['orderby'], $allowed_orderby, true ) ? $args['orderby'] : 'created_at';

		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

		$sql = "SELECT o.*, p.post_title AS course_title, u.user_email AS user_email, u.display_name AS user_name
				FROM {$wpdb->prefix}learnshapes_orders o
				LEFT JOIN {$wpdb->posts} p ON p.ID = o.course_id
				LEFT JOIN {$wpdb->users} u ON u.ID = o.user_id
				{$where_sql}
				ORDER BY o.{$orderby} {$order}
				LIMIT %d OFFSET %d";

		$params[] = $args['limit'];
		$params[] = $args['offset'];

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A );
	}

	/**
	 * Count orders with optional filters.
	 *
	 * @param  array $args Same keys as get_orders() except limit/offset/orderby/order.
	 * @return int
	 */
	public static function count_orders( $args = [] ) {
		global $wpdb;

		$where  = [];
		$params = [];

		if ( ! empty( $args['user_id'] ) ) {
			$where[]  = 'user_id = %d';
			$params[] = $args['user_id'];
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}

		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		$sql       = "SELECT COUNT(*) FROM {$wpdb->prefix}learnshapes_orders {$where_sql}";

		if ( $params ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $sql );
	}
}
