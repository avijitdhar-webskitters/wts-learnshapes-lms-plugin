<?php
namespace Learnshapes\Payments\Gateways;

use Learnshapes\Payments\AbstractGateway;
use Learnshapes\Payments\Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Offline / Bank Transfer Payment Gateway.
 *
 * Accepts manual payment (bank transfer, cash, etc.).
 * The order is placed in "pending" status and the admin
 * must manually mark it as "completed" to trigger enrollment.
 *
 * The admin receives an email notification on every new offline order.
 * The customer sees customisable payment instructions below their receipt.
 */
class Offline extends AbstractGateway {

	public function __construct() {
		$this->id          = 'offline';
		$this->title       = __( 'Offline / Bank Transfer', 'learnshapes' );
		$this->description = __( 'Pay via direct bank transfer or cash. Your order will be pending until payment is confirmed by our team.', 'learnshapes' );
		parent::__construct();

		// Hook: when admin marks an offline order complete → enroll.
		add_action( 'learnshapes_order_completed', [ $this, 'on_order_completed' ], 10, 2 );
	}

	/**
	 * Process the offline payment — set order to pending and notify admin.
	 *
	 * @param  int $order_id
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order = new Order( $order_id );

		// Determine what status to set immediately.
		$initial_status = apply_filters(
			'learnshapes_offline_initial_status',
			$this->get_option( 'initial_status', 'pending' ),
			$order
		);

		$order->update_status( $initial_status, 'OFFLINE-' . $order_id );

		do_action( 'learnshapes_offline_payment_placed', $order_id, $order );

		// Notify admin via email (handled in Mailer via learnshapes_order_created hook).
		// Additionally send "awaiting payment" email to customer.
		$this->send_pending_email( $order );

		$settings    = get_option( 'learnshapes_settings', [] );
		$checkout_id = $settings['pages']['checkout'] ?? 0;
		$base        = $checkout_id ? get_permalink( $checkout_id ) : home_url( '/' );

		return [
			'result'       => 'success',
			'redirect_url' => add_query_arg( [ 'ls_order_received' => $order_id ], $base ),
		];
	}

	/**
	 * When admin manually completes an offline order, enrollment is already handled
	 * by Order::update_status() → GatewayManager::enroll_student().
	 * This hook is available for additional custom actions.
	 *
	 * @param int   $order_id
	 * @param Order $order
	 */
	public function on_order_completed( $order_id, $order ) {
		if ( $order->get_payment_gateway() !== 'offline' ) {
			return;
		}
		do_action( 'learnshapes_offline_order_approved', $order_id, $order );
	}

	/**
	 * Send a "payment pending" confirmation email to the customer.
	 *
	 * @param Order $order
	 */
	private function send_pending_email( Order $order ) {
		$user = get_userdata( $order->get_user_id() );
		if ( ! $user ) {
			return;
		}

		$course_title = get_the_title( $order->get_course_id() );
		$instructions = wp_kses_post( wpautop( $this->get_option( 'instructions', '' ) ) );

		$subject = sprintf(
			__( 'Your order #%s is awaiting payment', 'learnshapes' ),
			$order->get_order_number()
		);

		$body = sprintf(
			/* translators: 1: display name, 2: order number, 3: course title, 4: payment instructions */
			__(
				'Hi %1$s,<br><br>Thank you for your order (#%2$s) for <strong>%3$s</strong>.<br><br>Your enrolment will be activated once we confirm your payment.<br><br><strong>Payment Instructions:</strong><br>%4$s',
				'learnshapes'
			),
			esc_html( $user->display_name ),
			esc_html( $order->get_order_number() ),
			esc_html( $course_title ),
			$instructions
		);

		$settings     = get_option( 'learnshapes_settings', [] );
		$from_name    = $settings['email']['from_name']  ?? get_bloginfo( 'name' );
		$from_email   = $settings['email']['from_email'] ?? get_option( 'admin_email' );
		$headers      = [
			'Content-Type: text/html; charset=UTF-8',
			"From: {$from_name} <{$from_email}>",
		];

		wp_mail( $user->user_email, $subject, $body, $headers );
	}

	/**
	 * Render payment instructions inside the checkout payment box.
	 */
	public function render_checkout_fields() {
		$instructions = $this->get_option( 'instructions', '' );

		if ( $instructions ) {
			echo '<div class="ls-offline-instructions">'
				 . wp_kses_post( wpautop( $instructions ) )
				 . '</div>';
		}

		parent::render_checkout_fields();
	}
}
