<?php
namespace Learnshapes\Payments\Gateways;

use Learnshapes\Payments\AbstractGateway;
use Learnshapes\Payments\Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stripe Payment Gateway.
 */
class Stripe extends AbstractGateway {

	public function __construct() {
		$this->id          = 'stripe';
		$this->title       = __( 'Stripe', 'learnshapes' );
		$this->description = __( 'Pay securely via Stripe with your credit or debit card.', 'learnshapes' );
		$this->icon        = 'https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg';
		parent::__construct();

		add_action( 'wp_ajax_nopriv_learnshapes_stripe_webhook', [ $this, 'handle_webhook' ] );
		add_action( 'wp_ajax_learnshapes_stripe_webhook',        [ $this, 'handle_webhook' ] );
		add_action( 'init', [ $this, 'handle_return' ] );
	}

	public function process_payment( $order_id ) {
		$order   = new Order( $order_id );
		$testmode = $this->get_option( 'testmode', 'yes' ) === 'yes';
		
		// In a real implementation we would call Stripe API to create a Checkout Session
		// and get the session URL. For this demo/stub, we will just simulate a success response
		// or redirect to a simulated payment page.
		
		if ( $testmode ) {
			$order->update_status( 'completed', 'STRIPE-DEMO-' . $order_id );
			return [
				'result'       => 'success',
				'redirect_url' => $this->get_return_url( $order ),
			];
		}

		// Fallback for demo
		$order->update_status( 'processing', '' );
		return [
			'result'       => 'success',
			'redirect_url' => $this->get_return_url( $order ),
		];
	}

	public function handle_webhook() {
		// Handle Stripe Webhook here
		exit;
	}

	public function handle_return() {
		if ( ! isset( $_GET['ls_stripe_return'] ) ) {
			return;
		}

		$order_id  = intval( $_GET['order_id'] ?? 0 );
		$order_key = sanitize_text_field( $_GET['order_key'] ?? '' );

		if ( ! $order_id || ! $order_key ) {
			return;
		}

		$order = new Order( $order_id );
		if ( $order->get_order_key() !== $order_key ) {
			return;
		}

		wp_safe_redirect( $this->get_return_url( $order ) );
		exit;
	}

	private function get_return_url( Order $order ) {
		$settings    = get_option( 'learnshapes_settings', [] );
		$checkout_id = $settings['pages']['checkout'] ?? 0;
		$base        = $checkout_id ? get_permalink( $checkout_id ) : home_url( '/' );

		return add_query_arg( [ 'ls_order_received' => $order->get_id() ], $base );
	}

	public function render_checkout_fields() {
		echo '<div class="ls-stripe-box">';
		echo '<p class="ls-stripe-desc">' . esc_html__( 'You will be redirected to Stripe to complete your purchase securely.', 'learnshapes' ) . '</p>';
		echo '<div class="ls-stripe-badges">'
			. '<span class="ls-stripe-badge">🔒 Secure & Encrypted</span>'
			. '<span class="ls-stripe-badge">💳 All major credit cards accepted</span>'
			. '</div>';
		echo '</div>';
		parent::render_checkout_fields();
	}
}
