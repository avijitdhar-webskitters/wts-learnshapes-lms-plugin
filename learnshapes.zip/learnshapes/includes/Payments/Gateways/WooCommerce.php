<?php
namespace Learnshapes\Payments\Gateways;

use Learnshapes\Payments\AbstractGateway;
use Learnshapes\Payments\Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WooCommerce Payment Gateway Integration.
 *
 * When this gateway is enabled the student is redirected to WooCommerce
 * checkout with the linked product already in the cart.
 *
 * Enrollment is triggered automatically when the linked WooCommerce order
 * reaches "completed" or "processing" status (configurable).
 *
 * Course ↔ WooCommerce product mapping is done via the course meta field
 * "_learnshapes_wc_product".  Admins can also configure a global
 * "enrollment on WC status" toggle.
 */
class WooCommerce extends AbstractGateway {

	public function __construct() {
		$this->id          = 'woocommerce';
		$this->title       = __( 'WooCommerce Checkout', 'learnshapes' );
		$this->description = __( 'Complete your purchase securely using any WooCommerce-supported payment method.', 'learnshapes' );
		parent::__construct();

		if ( $this->is_enabled() ) {
			// Listen for WooCommerce order status changes to trigger enrollment.
			add_action( 'woocommerce_order_status_completed',   [ $this, 'handle_wc_order_complete' ], 10, 1 );
			add_action( 'woocommerce_order_status_processing',  [ $this, 'handle_wc_order_complete' ], 10, 1 );
		}
	}

	/**
	 * Process payment: validate product link, add to WC cart, redirect.
	 *
	 * @param  int $order_id  Learnshapes order ID.
	 * @return array|\WP_Error
	 */
	public function process_payment( $order_id ) {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return new \WP_Error( 'wc_missing', __( 'WooCommerce is not active.', 'learnshapes' ) );
		}

		$order      = new Order( $order_id );
		$course_id  = $order->get_course_id();
		$product_id = (int) get_post_meta( $course_id, '_learnshapes_wc_product', true );

		if ( ! $product_id || ! wc_get_product( $product_id ) ) {
			return new \WP_Error(
				'no_wc_product',
				sprintf(
					/* translators: %d: course ID */
					__( 'No WooCommerce product is linked to this course (ID %d). Please contact the site administrator.', 'learnshapes' ),
					$course_id
				)
			);
		}

		// Store the LS order ID on the WC session so we can look it up later.
		WC()->session->set( 'learnshapes_order_id', $order_id );
		WC()->session->set( 'learnshapes_course_id', $course_id );

		// Empty current cart and add the course product.
		WC()->cart->empty_cart();
		WC()->cart->add_to_cart( $product_id, 1, 0, [], [
			'learnshapes_order_id'  => $order_id,
			'learnshapes_course_id' => $course_id,
		] );

		// Mark our order as "processing" while WooCommerce handles the rest.
		$order->update_status( 'processing', 'WC-REDIRECT-' . time() );

		return [
			'result'       => 'success',
			'redirect_url' => wc_get_checkout_url(),
		];
	}

	/**
	 * Called by WooCommerce when an order status changes to "completed" or
	 * "processing".  We look for Learnshapes metadata in order items to
	 * identify which LS course and order to finalize.
	 *
	 * @param int $wc_order_id WooCommerce order ID.
	 */
	public function handle_wc_order_complete( $wc_order_id ) {
		$wc_order = wc_get_order( $wc_order_id );
		if ( ! $wc_order ) {
			return;
		}

		foreach ( $wc_order->get_items() as $item ) {
			$ls_order_id  = (int) $item->get_meta( 'learnshapes_order_id' );
			$ls_course_id = (int) $item->get_meta( 'learnshapes_course_id' );

			if ( ! $ls_order_id && ! $ls_course_id ) {
				// Fallback: check product → course meta mapping.
				$product_id   = $item->get_product_id();
				$ls_course_id = (int) self::get_course_id_by_product( $product_id );
			}

			if ( ! $ls_course_id ) {
				continue;
			}

			// Resolve Learnshapes order if we have an ID.
			if ( $ls_order_id ) {
				$ls_order = new Order( $ls_order_id );
				if ( $ls_order->get_status() !== 'completed' ) {
					$ls_order->update_status( 'completed', 'WC-' . $wc_order_id );
				}
			} else {
				// If no LS order yet, enroll directly (e.g. purchased outside LS checkout flow).
				$customer_id = $wc_order->get_customer_id();
				if ( $customer_id ) {
					\Learnshapes\Payments\GatewayManager::enroll_student(
						$customer_id,
						$ls_course_id,
						'woocommerce',
						'WC-' . $wc_order_id,
						(float) $wc_order->get_total()
					);
				}
			}
		}

		do_action( 'learnshapes_woocommerce_order_processed', $wc_order_id );
	}

	/**
	 * Find a Learnshapes course that has a given WooCommerce product linked.
	 *
	 * @param  int $product_id WooCommerce product ID.
	 * @return int|false  Course ID or false.
	 */
	public static function get_course_id_by_product( $product_id ) {
		global $wpdb;

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta}
				 WHERE meta_key = '_learnshapes_wc_product' AND meta_value = %d
				 LIMIT 1",
				$product_id
			)
		);
	}

	/**
	 * Show a note at checkout about WooCommerce redirect.
	 */
	public function render_checkout_fields() {
		echo '<div class="ls-wc-note" style="padding:8px 0; font-size:13px; color:#64748b;">'
			 . esc_html__( 'You will be redirected to our secure WooCommerce checkout page to complete your payment.', 'learnshapes' )
			 . '</div>';

		parent::render_checkout_fields();
	}
}
