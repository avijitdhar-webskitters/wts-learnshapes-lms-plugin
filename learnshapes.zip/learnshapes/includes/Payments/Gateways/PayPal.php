<?php
namespace Learnshapes\Payments\Gateways;

use Learnshapes\Payments\AbstractGateway;
use Learnshapes\Payments\Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PayPal Payment Gateway.
 *
 * Supports PayPal Standard (IPN) for live payment processing.
 * In sandbox mode the flow is fully simulated locally without
 * hitting PayPal's servers so the plugin works out-of-the-box
 * for testing without PayPal credentials.
 *
 * Live mode builds a real PayPal Standard redirect URL and registers
 * an IPN listener endpoint so PayPal can confirm payments server-side.
 */
class PayPal extends AbstractGateway {

	/** PayPal Standard checkout URL (live). */
	const PAYPAL_URL = 'https://www.paypal.com/cgi-bin/webscr';

	/** PayPal Sandbox checkout URL. */
	const SANDBOX_URL = 'https://www.sandbox.paypal.com/cgi-bin/webscr';

	public function __construct() {
		$this->id          = 'paypal';
		$this->title       = __( 'PayPal', 'learnshapes' );
		$this->description = __( 'Pay securely via PayPal — you can pay with your PayPal account or debit/credit card.', 'learnshapes' );
		$this->icon        = 'https://www.paypalobjects.com/webstatic/mktg/logo/PP_Acceptance_Marks_for_LogoCenter_76x48.png';
		parent::__construct();

		// Register IPN listener.
		add_action( 'wp_ajax_nopriv_learnshapes_paypal_ipn', [ $this, 'handle_ipn' ] );
		add_action( 'wp_ajax_learnshapes_paypal_ipn',        [ $this, 'handle_ipn' ] );

		// Register PDT / return handler.
		add_action( 'init', [ $this, 'handle_return' ] );
	}

	/**
	 * Build and return a PayPal Standard redirect URL for the given order.
	 *
	 * In sandbox mode we immediately mark the order as completed so
	 * testing works without hitting PayPal's sandbox servers.
	 *
	 * @param  int $order_id
	 * @return array|\WP_Error
	 */
	public function process_payment( $order_id ) {
		$order   = new Order( $order_id );
		$sandbox = $this->get_option( 'sandbox', 'yes' ) === 'yes';
		$email   = sanitize_email( $this->get_option( 'email', '' ) );

		// ── Sandbox / demo mode: auto-complete immediately ────────────────────
		if ( $sandbox && ! $email ) {
			$order->update_status( 'completed', 'PP-DEMO-' . $order_id );
			return [
				'result'       => 'success',
				'redirect_url' => $this->get_return_url( $order ),
			];
		}

		// ── Build PayPal Standard redirect arguments ──────────────────────────
		$notify_url = admin_url( 'admin-ajax.php?action=learnshapes_paypal_ipn' );
		$return_url = add_query_arg(
			[
				'ls_paypal_return' => 1,
				'order_id'         => $order_id,
				'order_key'        => $order->get_order_key(),
			],
			home_url( '/' )
		);
		$cancel_url = add_query_arg( [ 'ls_paypal_cancel' => 1, 'order_id' => $order_id ], home_url( '/' ) );

		$paypal_args = apply_filters( 'learnshapes_paypal_args', [
			'cmd'           => '_xclick',
			'business'      => $email,
			'item_name'     => get_the_title( $order->get_course_id() ),
			'item_number'   => $order->get_order_number(),
			'amount'        => $order->get_amount(),
			'currency_code' => $order->get_currency(),
			'invoice'       => $order->get_order_number(),
			'notify_url'    => $notify_url,
			'return'        => $return_url,
			'cancel_return' => $cancel_url,
			'rm'            => '2',    // Return with POST data.
			'charset'       => 'UTF-8',
		], $order );

		$base_url    = $sandbox ? self::SANDBOX_URL : self::PAYPAL_URL;
		$redirect    = $base_url . '?' . http_build_query( $paypal_args );

		// Mark order as processing while we wait for PayPal.
		$order->update_status( 'processing', '' );

		return [
			'result'       => 'success',
			'redirect_url' => $redirect,
		];
	}

	/**
	 * Handle PayPal Instant Payment Notification (IPN).
	 * Called by PayPal's servers to confirm a payment server-to-server.
	 */
	public function handle_ipn() {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$raw_post = file_get_contents( 'php://input' );
		if ( empty( $raw_post ) ) {
			exit;
		}

		$sandbox    = $this->get_option( 'sandbox', 'yes' ) === 'yes';
		$verify_url = $sandbox ? self::SANDBOX_URL : self::PAYPAL_URL;

		// Send data back to PayPal for verification.
		$response = wp_remote_post( $verify_url, [
			'body'    => 'cmd=_notify-validate&' . $raw_post,
			'timeout' => 45,
		] );

		if ( is_wp_error( $response ) || wp_remote_retrieve_body( $response ) !== 'VERIFIED' ) {
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$data = [];
		parse_str( $raw_post, $data );

		$payment_status = strtolower( $data['payment_status'] ?? '' );
		$invoice        = $data['invoice'] ?? '';
		$txn_id         = sanitize_text_field( $data['txn_id'] ?? '' );

		if ( ! $invoice ) {
			exit;
		}

		// Resolve order ID from order number (e.g. "ORDER-00042").
		$order_id = $this->order_id_from_number( $invoice );
		if ( ! $order_id ) {
			exit;
		}

		$order = new Order( $order_id );

		if ( $payment_status === 'completed' ) {
			$order->update_status( 'completed', $txn_id );
		} elseif ( in_array( $payment_status, [ 'refunded', 'reversed' ], true ) ) {
			$order->update_status( 'refunded', $txn_id );
		} elseif ( $payment_status === 'failed' ) {
			$order->update_status( 'failed', $txn_id );
		}

		do_action( 'learnshapes_paypal_ipn_processed', $order_id, $data );
		exit;
	}

	/**
	 * Handle PayPal return / PDT after buyer completes checkout.
	 */
	public function handle_return() {
		if ( ! isset( $_GET['ls_paypal_return'] ) ) {
			return;
		}

		$order_id  = intval( $_GET['order_id'] ?? 0 );
		$order_key = sanitize_text_field( $_GET['order_key'] ?? '' );

		if ( ! $order_id || ! $order_key ) {
			return;
		}

		$order = new Order( $order_id );
		if ( $order->get_order_key() !== $order_key ) {
			return;
		}

		// If still processing (IPN not yet received), show order-received page.
		wp_safe_redirect( $this->get_return_url( $order ) );
		exit;
	}

	/**
	 * Build the "order received" page URL for a given order.
	 *
	 * @param  Order $order
	 * @return string
	 */
	private function get_return_url( Order $order ) {
		$settings    = get_option( 'learnshapes_settings', [] );
		$checkout_id = $settings['pages']['checkout'] ?? 0;
		$base        = $checkout_id ? get_permalink( $checkout_id ) : home_url( '/' );

		return add_query_arg( [ 'ls_order_received' => $order->get_id() ], $base );
	}

	/**
	 * Extract numeric order ID from an order number string like "ORDER-00042".
	 *
	 * @param  string $order_number
	 * @return int|false
	 */
	private function order_id_from_number( $order_number ) {
		// Strip slug prefix and leading zeros.
		if ( strpos( $order_number, '-' ) !== false ) {
			$parts = explode( '-', $order_number );
			return (int) end( $parts );
		}
		return false;
	}

	/**
	 * Render the PayPal description and logo at checkout.
	 */
	public function render_checkout_fields() {
		echo '<div class="ls-paypal-box">';
		// Inline PayPal SVG wordmark — no external image dependency
		echo '<div class="ls-paypal-logo">'
			. '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 124 33" width="100" height="27">'
			. '<path fill="#003087" d="M46.2 8.3h-7.4c-.5 0-.9.3-1 .8L34.7 24c-.1.3.1.6.5.6h3.5c.5 0 .9-.3 1-.8l1-6.3c.1-.5.5-.8 1-.8h2.3c4.8 0 7.6-2.3 8.3-6.8.3-2-.1-3.5-1-4.6-.9-1.1-2.6-1.8-5.1-1.8zM47.3 15c-.4 2.6-2.4 2.6-4.3 2.6h-1.1l.8-5c0-.3.3-.5.6-.5h.5c1.3 0 2.5 0 3.2.7.4.5.5 1.2.3 2.2z"/>'
			. '<path fill="#003087" d="M69.8 14.9h-3.5c-.3 0-.6.2-.6.5l-.2.9-.2-.4c-.7-1-2.2-1.3-3.7-1.3-3.5 0-6.5 2.6-7 6.3-.3 1.8.1 3.5 1.2 4.7 1 1.1 2.3 1.6 4 1.6 2.8 0 4.4-1.8 4.4-1.8l-.2.9c-.1.3.1.6.5.6h3.1c.5 0 .9-.3 1-.8l1.9-11.6c0-.3-.2-.6-.7-.6zm-4.8 6.1c-.3 1.7-1.6 2.9-3.3 2.9-.9 0-1.5-.3-2-.8-.4-.5-.6-1.3-.5-2.1.3-1.7 1.6-2.9 3.3-2.9.8 0 1.5.3 2 .8.5.6.6 1.4.5 2.1z"/>'
			. '<path fill="#003087" d="M89.3 14.9h-3.5c-.4 0-.7.2-.9.5l-5 7.5-2.1-7.2c-.1-.5-.6-.8-1-.8h-3.5c-.4 0-.6.3-.5.7l4 11.7-3.8 5.3c-.3.4 0 .9.5.9h3.5c.4 0 .7-.2.9-.5l12.1-17.4c.3-.4 0-.7-.7-.7z"/>'
			. '<path fill="#009cde" d="M100.3 8.3h-7.4c-.5 0-.9.3-1 .8L88.8 24c-.1.3.1.6.5.6h3.8c.3 0 .6-.2.7-.6l1-6.5c.1-.5.5-.8 1-.8h2.3c4.8 0 7.6-2.3 8.3-6.8.3-2-.1-3.5-1-4.6-.9-1.1-2.7-1.8-5.1-1.8zm1.1 6.7c-.4 2.6-2.4 2.6-4.3 2.6H96l.8-5c0-.3.3-.5.6-.5h.5c1.3 0 2.5 0 3.2.7.4.5.5 1.2.3 2.2z"/>'
			. '<path fill="#009cde" d="M123.7 14.9h-3.5c-.3 0-.6.2-.6.5l-.2.9-.2-.4c-.7-1-2.2-1.3-3.7-1.3-3.5 0-6.5 2.6-7 6.3-.3 1.8.1 3.5 1.2 4.7 1 1.1 2.3 1.6 4 1.6 2.8 0 4.4-1.8 4.4-1.8l-.2.9c-.1.3.1.6.5.6h3.1c.5 0 .9-.3 1-.8l1.9-11.6c0-.3-.3-.6-.7-.6zm-4.9 6.1c-.3 1.7-1.6 2.9-3.3 2.9-.8 0-1.5-.3-2-.8-.4-.5-.6-1.3-.5-2.1.3-1.7 1.6-2.9 3.3-2.9.8 0 1.5.3 2 .8.6.6.7 1.4.5 2.1z"/>'
			. '<path fill="#003087" d="M16.1 3.3C14.6 1.6 11.8.8 8.2.8H1.4C.8.8.2 1.4.1 2l-3 19c-.1.5.3.9.7.9h5.3l1.3-8.5v.3c.1-.7.7-1.2 1.4-1.2h2.9c5.7 0 10.1-2.3 11.4-9 0-.2.1-.4.1-.6-.3-.2-.7-.4-1-1 0 .1 0 .2-.1.4z"/>'
			. '<path fill="#009cde" d="M17.1 4.3c-.2 1.5-.8 2.8-1.8 3.7-1.3 1.2-3.2 1.7-5.6 1.7H7.3c-.7 0-1.2.5-1.4 1.2L4.6 18.3l-.4 2.6c-.1.4.2.7.6.7h4.4c.6 0 1.1-.4 1.2-1l.1-.5.9-5.9.1-.5c.1-.6.6-1 1.2-1h.8c5 0 8.9-2 10-7.9.5-2.5.2-4.5-.9-6z"/>'
			. '</svg>'
			. '</div>';
		echo '<p class="ls-paypal-desc">'
			. esc_html__( 'You will be redirected to PayPal to complete your purchase securely.', 'learnshapes' )
			. '</p>';
		echo '<div class="ls-paypal-badges">'
			. '<span class="ls-paypal-badge">🔒 Buyer Protection</span>'
			. '<span class="ls-paypal-badge">⚡ Instant Confirmation</span>'
			. '</div>';
		echo '</div>';

		parent::render_checkout_fields();
	}
}
