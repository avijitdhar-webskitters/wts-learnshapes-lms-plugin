<?php
namespace Learnshapes\Payments;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gateway Manager.
 *
 * Central controller for all payment gateways.  Responsibilities:
 *  - Loading and registering gateway classes.
 *  - Exposing available (enabled) gateways to the checkout template.
 *  - Processing AJAX checkout submissions.
 *  - Enrolling students after a successful payment.
 *  - Exposing the orders admin sub-page with inline status management.
 *
 * All extension points are exposed via hooks so third-party code can
 * add custom gateways, modify the checkout flow, or react to events.
 */
class GatewayManager {

	/** @var AbstractGateway[] Registered gateways keyed by ID. */
	private static $gateways = [];

	// ─── Boot ─────────────────────────────────────────────────────────────────

	public static function init() {
		// Auto-enable Offline Payment on first run if no gateways are configured.
		self::maybe_enable_default_gateways();

		self::load_gateways();

		// ── Enroll button AJAX (course page → checkout redirect) ──────────────
		add_action( 'wp_ajax_learnshapes_enroll_course',        [ __CLASS__, 'ajax_enroll_course' ] );
		add_action( 'wp_ajax_nopriv_learnshapes_enroll_course', [ __CLASS__, 'ajax_enroll_course' ] );

		// ── Checkout form AJAX ─────────────────────────────────────────────────
		add_action( 'wp_ajax_learnshapes_checkout',         [ __CLASS__, 'ajax_checkout' ] );
		add_action( 'wp_ajax_nopriv_learnshapes_checkout',  [ __CLASS__, 'ajax_checkout' ] );
		add_action( 'wp_ajax_nopriv_learnshapes_ajax_login', [ __CLASS__, 'ajax_login' ] );
		add_action( 'wp_ajax_learnshapes_ajax_login',       [ __CLASS__, 'ajax_login' ] );

		// Admin: order status change.
		add_action( 'wp_ajax_learnshapes_update_order_status', [ __CLASS__, 'ajax_update_order_status' ] );

		// Admin: orders sub-menu.
		add_action( 'admin_menu', [ __CLASS__, 'register_orders_menu' ] );
	}

	/**
	 * Enable Offline Payment and PayPal (sandbox) on first run
	 * so the checkout page always shows at least one payment method.
	 * Only runs once — skipped if any gateway has already been configured.
	 */
	private static function maybe_enable_default_gateways() {
		if ( get_option( 'learnshapes_gateways_bootstrapped' ) ) {
			return;
		}

		$offline = get_option( 'learnshapes_payment_offline', [] );
		if ( empty( $offline['enabled'] ) || $offline['enabled'] !== 'yes' ) {
			update_option( 'learnshapes_payment_offline', [
				'enabled'      => 'yes',
				'instructions' => 'Please transfer the payment to our bank account and send us the payment receipt. Your enrollment will be confirmed within 24 hours.',
			] );
		}

		$paypal = get_option( 'learnshapes_payment_paypal', [] );
		if ( empty( $paypal['enabled'] ) || $paypal['enabled'] !== 'yes' ) {
			update_option( 'learnshapes_payment_paypal', [
				'enabled' => 'yes',
				'sandbox' => 'yes',
				'email'   => '',
			] );
		}

		update_option( 'learnshapes_gateways_bootstrapped', '1' );
	}

	// ─── Gateway Registry ─────────────────────────────────────────────────────

	private static function load_gateways() {
		$gateways = [
			'paypal'      => new \Learnshapes\Payments\Gateways\PayPal(),
			'stripe'      => new \Learnshapes\Payments\Gateways\Stripe(),
			'offline'     => new \Learnshapes\Payments\Gateways\Offline(),
			'woocommerce' => new \Learnshapes\Payments\Gateways\WooCommerce(),
		];

		/**
		 * Filter: learnshapes_payment_gateways
		 *
		 * Allows third-party plugins to add or remove payment gateways.
		 *
		 * @param AbstractGateway[] $gateways Keyed array of gateway instances.
		 */
		self::$gateways = apply_filters( 'learnshapes_payment_gateways', $gateways );

		// Sort gateways by their stored order value.
		uasort( self::$gateways, function ( $a, $b ) {
			return $a->order - $b->order;
		} );
	}

	/** @return AbstractGateway[] All registered gateways. */
	public static function get_gateways() {
		return self::$gateways;
	}

	/** @return AbstractGateway[] Only gateways that are enabled. */
	public static function get_available_gateways() {
		return array_filter( self::$gateways, fn( $g ) => $g->is_enabled() );
	}

	/**
	 * @param  string $id
	 * @return AbstractGateway|false
	 */
	public static function get_gateway( $id ) {
		return self::$gateways[ $id ] ?? false;
	}

	// ─── Checkout URL Helper ──────────────────────────────────────────────────

	/**
	 * Return the checkout page URL.
	 *
	 * If no checkout page is configured in settings, automatically create one,
	 * save it to settings, and return its permalink so the user experience
	 * is never interrupted by "Checkout page not configured" errors.
	 *
	 * @param  int|0 $course_id  Optional course ID to append as query arg.
	 * @return string
	 */
	public static function get_checkout_url( $course_id = 0 ) {
		$settings    = get_option( 'learnshapes_settings', [] );
		$checkout_id = isset( $settings['pages']['checkout'] ) ? intval( $settings['pages']['checkout'] ) : 0;

		// Validate the stored page still exists and is published.
		if ( $checkout_id ) {
			$page = get_post( $checkout_id );
			if ( ! $page || $page->post_status !== 'publish' ) {
				$checkout_id = 0;
			}
		}

		// Auto-create checkout page if missing.
		if ( ! $checkout_id ) {
			$checkout_id = wp_insert_post( [
				'post_title'   => __( 'Checkout', 'learnshapes' ),
				'post_content' => '[learnshapes_checkout]',
				'post_status'  => 'publish',
				'post_type'    => 'page',
			] );
			if ( ! is_wp_error( $checkout_id ) && $checkout_id ) {
				update_post_meta( $checkout_id, '_learnshapes_is_default_page', 'checkout' );
				$settings['pages']['checkout'] = $checkout_id;
				update_option( 'learnshapes_settings', $settings );
			} else {
				return home_url( '/' );
			}
		}

		$url = get_permalink( $checkout_id );
		if ( $course_id ) {
			$url = add_query_arg( 'course_id', $course_id, $url );
		}
		return $url;
	}

	// ─── AJAX: Enroll Course (course page button handler) ─────────────────────

	/**
	 * Handle the "Enroll Now" button click from the single course page.
	 *
	 * This is the gateway between the course CTA button and the checkout page.
	 * It handles:
	 *  - Login state checks
	 *  - Already-enrolled detection
	 *  - Free course instant enrollment
	 *  - Paid course redirect to checkout
	 *
	 * Response actions:
	 *  - 'redirect'  → redirect_url (checkout page)
	 *  - 'enrolled'  → redirect_url (course page, free course)
	 *  - 'login'     → redirect_url (login page)
	 */
	public static function ajax_enroll_course() {
		check_ajax_referer( 'learnshapes_frontend_nonce', 'nonce' );

		$course_id = isset( $_POST['course_id'] ) ? intval( $_POST['course_id'] ) : 0;

		if ( ! $course_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid course.', 'learnshapes' ) ] );
		}

		$course = get_post( $course_id );
		if ( ! $course || $course->post_type !== 'learnshapes_course' ) {
			wp_send_json_error( [ 'message' => __( 'Course not found.', 'learnshapes' ) ] );
		}

		$user_id  = get_current_user_id();
		$settings = get_option( 'learnshapes_settings', [] );

		// ── Check: already enrolled ────────────────────────────────────────────
		if ( $user_id ) {
			global $wpdb;
			$enrolled = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id = %d AND course_id = %d AND status = 'active'",
				$user_id,
				$course_id
			) );
			if ( $enrolled ) {
				wp_send_json_success( [
					'action'  => 'enrolled',
					'message' => __( 'You are already enrolled. Redirecting…', 'learnshapes' ),
					'url'     => get_permalink( $course_id ),
				] );
			}
		}

		$price = floatval( get_post_meta( $course_id, '_learnshapes_price', true ) ?: 0 );

		// ── Free course: instant enrollment ───────────────────────────────────
		if ( $price <= 0 ) {
			if ( $user_id ) {
				self::enroll_student( $user_id, $course_id, 'free', 'FREE-' . time(), 0 );
				do_action( 'learnshapes_after_checkout', 0, null );
				wp_send_json_success( [
					'action'  => 'enrolled',
					'message' => __( '🎉 Enrolled successfully! Redirecting to course…', 'learnshapes' ),
					'url'     => get_permalink( $course_id ),
				] );
			} else {
				// Not logged in: redirect to checkout for free course (handles login)
				wp_send_json_success( [
					'action'  => 'redirect',
					'message' => __( 'Redirecting to enrollment…', 'learnshapes' ),
					'url'     => self::get_checkout_url( $course_id ),
				] );
			}
		}

		// ── Paid course: redirect to checkout ─────────────────────────────────
		if ( ! $user_id ) {
			$guest_checkout = ! empty( $settings['payment']['guest_checkout'] );
			$account_login  = ! empty( $settings['payment']['account_login'] );

			if ( ! $guest_checkout && ! $account_login ) {
				// Must log in — redirect to WP login page, come back after
				wp_send_json_success( [
					'action'  => 'login',
					'message' => __( 'Please log in to purchase this course.', 'learnshapes' ),
					'url'     => wp_login_url( get_permalink( $course_id ) ),
				] );
			}
		}

		// Check for pending order for this user + course
		if ( $user_id ) {
			global $wpdb;
			$pending_order_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}learnshapes_orders WHERE user_id = %d AND course_id = %d AND status IN ('pending','processing') ORDER BY id DESC LIMIT 1",
				$user_id,
				$course_id
			) );
			if ( $pending_order_id ) {
				wp_send_json_success( [
					'action'  => 'redirect',
					'message' => __( 'You have a pending order. Redirecting to checkout…', 'learnshapes' ),
					'url'     => self::get_checkout_url( $course_id ),
				] );
			}
		}

		wp_send_json_success( [
			'action'  => 'redirect',
			'message' => __( 'Redirecting to checkout…', 'learnshapes' ),
			'url'     => self::get_checkout_url( $course_id ),
		] );
	}

	// ─── AJAX: Login ──────────────────────────────────────────────────────────

	public static function ajax_login() {
		check_ajax_referer( 'learnshapes_frontend_nonce', 'nonce' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$creds = [
			'user_login'    => sanitize_text_field( wp_unslash( $_POST['log'] ?? '' ) ),
			'user_password' => wp_unslash( $_POST['pwd'] ?? '' ),
			'remember'      => true,
		];

		$user = wp_signon( $creds, is_ssl() );
		if ( is_wp_error( $user ) ) {
			wp_send_json_error( [ 'message' => $user->get_error_message() ] );
		}

		wp_send_json_success( [ 'message' => __( 'Logged in successfully.', 'learnshapes' ) ] );
	}

	// ─── AJAX: Checkout ───────────────────────────────────────────────────────

	public static function ajax_checkout() {
		check_ajax_referer( 'learnshapes_frontend_nonce', 'nonce' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$course_id  = isset( $_POST['course_id'] )    ? intval( $_POST['course_id'] )    : 0;
		$gateway_id = isset( $_POST['payment_method'] ) ? sanitize_text_field( wp_unslash( $_POST['payment_method'] ) ) : '';

		if ( ! $course_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid course.', 'learnshapes' ) ] );
		}

		$course = get_post( $course_id );
		if ( ! $course || $course->post_type !== 'learnshapes_course' ) {
			wp_send_json_error( [ 'message' => __( 'Course not found.', 'learnshapes' ) ] );
		}

		$settings         = get_option( 'learnshapes_settings', [] );
		$guest_checkout   = ! empty( $settings['payment']['guest_checkout'] );
		$account_creation = ! empty( $settings['payment']['account_creation'] );
		$currency         = $settings['payment']['currency'] ?? 'USD';

		// ── User resolution ───────────────────────────────────────────────────
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			if ( $account_creation && ! empty( $_POST['billing_email'] ) ) {
				// Create account from billing email.
				$email = sanitize_email( wp_unslash( $_POST['billing_email'] ) );
				if ( ! is_email( $email ) ) {
					wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'learnshapes' ) ] );
				}
				if ( email_exists( $email ) ) {
					wp_send_json_error( [ 'message' => __( 'An account with this email already exists. Please log in.', 'learnshapes' ) ] );
				}

				$first_name = sanitize_text_field( wp_unslash( $_POST['billing_first_name'] ?? '' ) );
				$last_name  = sanitize_text_field( wp_unslash( $_POST['billing_last_name']  ?? '' ) );
				$username   = sanitize_user( current( explode( '@', $email ) ), true );
				$username   = ! username_exists( $username ) ? $username : $email;
				$password   = wp_generate_password( 12, false );

				$user_id = wp_create_user( $username, $password, $email );
				if ( is_wp_error( $user_id ) ) {
					wp_send_json_error( [ 'message' => $user_id->get_error_message() ] );
				}
				wp_update_user( [
					'ID'           => $user_id,
					'first_name'   => $first_name,
					'last_name'    => $last_name,
					'display_name' => trim( "$first_name $last_name" ) ?: $username,
				] );
				wp_set_current_user( $user_id );
				wp_set_auth_cookie( $user_id, true );

				// Send auto-generated password email.
				wp_new_user_notification( $user_id, null, 'both' );

			} elseif ( $guest_checkout ) {
				$user_id = 0; // Guest.
			} else {
				wp_send_json_error( [ 'message' => __( 'Please log in or create an account to continue.', 'learnshapes' ) ] );
			}
		}

		$price = floatval( get_post_meta( $course_id, '_learnshapes_price', true ) ?: 0 );

		do_action( 'learnshapes_before_checkout', $course_id, $user_id, $gateway_id );

		// ── Free course: direct enroll ─────────────────────────────────────────
		if ( $price <= 0 ) {
			if ( $user_id ) {
				self::enroll_student( $user_id, $course_id, 'free', 'FREE-' . time(), 0 );
			}
			wp_send_json_success( [
				'result'       => 'success',
				'redirect_url' => $user_id
					? get_permalink( $course_id )
					: add_query_arg( [ 'ls_enrolled' => 1 ], self::get_checkout_url( $course_id ) ),
				'message'      => __( 'Enrolled successfully!', 'learnshapes' ),
			] );
		}

		// ── Paid course: gateway required ─────────────────────────────────────
		if ( empty( $gateway_id ) ) {
			wp_send_json_error( [ 'message' => __( 'Please select a payment method.', 'learnshapes' ) ] );
		}

		$gateway = self::get_gateway( $gateway_id );
		if ( ! $gateway || ! $gateway->is_enabled() ) {
			wp_send_json_error( [ 'message' => __( 'The selected payment method is not available.', 'learnshapes' ) ] );
		}

		// Validate any gateway-specific checkout fields.
		$valid = $gateway->validate_checkout_fields();
		if ( is_wp_error( $valid ) ) {
			wp_send_json_error( [ 'message' => $valid->get_error_message() ] );
		}

		// Collect extra billing data to store on the order.
		$extra = [];
		if ( ! empty( $_POST['billing_email'] ) ) {
			$extra['billing_email'] = sanitize_email( wp_unslash( $_POST['billing_email'] ) );
		}

		do_action( 'learnshapes_before_order_create', $course_id, $user_id, $gateway_id, $extra );

		// Create the order.
		$order = Order::create( $user_id, $course_id, $price, $currency, $gateway_id, $extra );

		do_action( 'learnshapes_after_order_create', $order->get_id(), $order );

		// Process payment via gateway.
		$result = $gateway->process_payment( $order->get_id() );

		if ( is_wp_error( $result ) ) {
			$order->update_status( 'failed' );
			do_action( 'learnshapes_payment_failure', $order->get_id(), $result->get_error_message() );
			wp_send_json_error( [ 'message' => $result->get_error_message() ] );
		}

		do_action( 'learnshapes_after_checkout', $order->get_id(), $order );

		wp_send_json_success( $result );
	}

	// ─── Enrollment ───────────────────────────────────────────────────────────

	/**
	 * Enroll a user into a course, preventing duplicates.
	 *
	 * Fires:
	 *   - learnshapes_before_enrollment
	 *   - learnshapes_after_enrollment  (only on new enrollment)
	 *   - learnshapes_payment_success
	 *   - learnshapes_after_course_enroll
	 *
	 * @param int    $user_id
	 * @param int    $course_id
	 * @param string $gateway     Gateway ID.
	 * @param string $tx_id       Transaction / reference ID.
	 * @param float  $amount
	 */
	public static function enroll_student( $user_id, $course_id, $gateway, $tx_id, $amount ) {
		global $wpdb;

		if ( ! $user_id ) {
			return; // Cannot enroll guests.
		}

		do_action( 'learnshapes_before_enrollment', $user_id, $course_id, $gateway );

		$table  = $wpdb->prefix . 'learnshapes_enrollments';
		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE user_id = %d AND course_id = %d AND status = 'active'",
			$user_id,
			$course_id
		) );

		if ( ! $exists ) {
			$wpdb->insert( $table, [
				'user_id'          => $user_id,
				'course_id'        => $course_id,
				'status'           => 'active',
				'progress_percent' => 0.00,
				'enrolled_at'      => current_time( 'mysql' ),
			] );

			do_action( 'learnshapes_after_enrollment', $user_id, $course_id, $gateway );
		}

		do_action( 'learnshapes_payment_success', $user_id, $course_id, $amount, $gateway );
		do_action( 'learnshapes_after_course_enroll', $user_id, $course_id );
	}

	// ─── Admin: Orders Menu ───────────────────────────────────────────────────

	public static function register_orders_menu() {
		add_submenu_page(
			'edit.php?post_type=learnshapes_course',
			__( 'Orders', 'learnshapes' ),
			__( 'Orders', 'learnshapes' ),
			'manage_options',
			'learnshapes-orders',
			[ __CLASS__, 'render_orders_page' ]
		);
	}

	// ─── AJAX: Update Order Status (Admin) ────────────────────────────────────

	public static function ajax_update_order_status() {
		check_ajax_referer( 'learnshapes_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Permission denied.' ] );
		}

		$order_id = intval( $_POST['order_id'] ?? 0 );
		$status   = sanitize_text_field( $_POST['status'] ?? '' );

		if ( ! $order_id || ! $status ) {
			wp_send_json_error( [ 'message' => 'Invalid request.' ] );
		}

		$order = new Order( $order_id );
		$order->update_status( $status );

		wp_send_json_success( [
			'message' => sprintf( __( 'Order #%d updated to %s.', 'learnshapes' ), $order_id, $status ),
			'status'  => $status,
		] );
	}

	// ─── Admin: Orders Page Renderer ─────────────────────────────────────────

	public static function render_orders_page() {
		$status_filter = isset( $_GET['status'] ) ? sanitize_text_field( $_GET['status'] ) : '';
		$paged         = max( 1, intval( $_GET['paged'] ?? 1 ) );
		$per_page      = 20;

		$args = [
			'status' => $status_filter,
			'limit'  => $per_page,
			'offset' => ( $paged - 1 ) * $per_page,
		];
		$orders = Order::get_orders( $args );
		$total  = Order::count_orders( [ 'status' => $status_filter ] );
		$pages  = ceil( $total / $per_page );

		$statuses = [ '', 'pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded' ];

		$admin_nonce = wp_create_nonce( 'learnshapes_admin_nonce' );
		?>
		<div class="wrap">
			<hr class="wp-header-end">
			<div class="learnshapes-admin-wrap">
				<div class="learnshapes-header">
					<div class="learnshapes-logo-area">
						<h1 style="margin: 0; padding: 0;"><?php esc_html_e( 'Learnshapes Orders', 'learnshapes' ); ?></h1>
					</div>
				</div>

			<ul class="subsubsub" style="margin-bottom:15px;">
				<?php foreach ( $statuses as $s ) :
					$label = $s ? ucfirst( $s ) : 'All';
					$cnt   = Order::count_orders( $s ? [ 'status' => $s ] : [] );
					$url   = add_query_arg( [ 'page' => 'learnshapes-orders', 'status' => $s ], admin_url( 'edit.php?post_type=learnshapes_course' ) );
				?>
				<li>
					<a href="<?php echo esc_url( $url ); ?>" <?php echo $status_filter === $s ? 'class="current"' : ''; ?>>
						<?php echo esc_html( $label ); ?> <span class="count">(<?php echo (int) $cnt; ?>)</span>
					</a>
					<?php echo $s !== end( $statuses ) ? ' |' : ''; ?>
				</li>
				<?php endforeach; ?>
			</ul>

			<table class="wp-list-table widefat fixed striped" id="ls-orders-table">
				<thead>
					<tr>
						<th width="60"><?php esc_html_e( 'Order', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Student', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Course', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Amount', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Gateway', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Status', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Date', 'learnshapes' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'learnshapes' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $orders ) ) : ?>
					<tr><td colspan="8" style="text-align:center; padding:30px;"><?php esc_html_e( 'No orders found.', 'learnshapes' ); ?></td></tr>
					<?php else : ?>
					<?php foreach ( $orders as $row ) :
						$o         = new Order( $row['id'] );
						$status_cls = [
							'completed'  => '#16a34a',
							'pending'    => '#ca8a04',
							'processing' => '#2563eb',
							'failed'     => '#dc2626',
							'cancelled'  => '#6b7280',
							'refunded'   => '#7c3aed',
						][ $row['status'] ] ?? '#6b7280';
					?>
					<tr id="ls-order-row-<?php echo (int) $row['id']; ?>">
						<td><strong>#<?php echo esc_html( $o->get_order_number() ); ?></strong></td>
						<td>
							<?php echo esc_html( $row['user_name'] ?? '—' ); ?><br>
							<small><?php echo esc_html( $row['user_email'] ?? '' ); ?></small>
						</td>
						<td><?php echo esc_html( $row['course_title'] ?? '—' ); ?></td>
						<td><?php echo esc_html( number_format( (float) $row['amount'], 2 ) . ' ' . $row['currency'] ); ?></td>
						<td><?php echo esc_html( ucfirst( $row['payment_gateway'] ) ); ?></td>
						<td>
							<span class="ls-order-status-badge ls-order-<?php echo esc_attr( $row['status'] ); ?>"
								  style="display:inline-block; padding:3px 10px; border-radius:12px; color:#fff; background:<?php echo esc_attr( $status_cls ); ?>; font-size:12px; font-weight:600;">
								<?php echo esc_html( ucfirst( $row['status'] ) ); ?>
							</span>
						</td>
						<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $row['created_at'] ) ) ); ?></td>
						<td>
							<select class="ls-order-status-select" data-order-id="<?php echo (int) $row['id']; ?>" style="width:120px;">
								<?php foreach ( [ 'pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded' ] as $st ) : ?>
								<option value="<?php echo esc_attr( $st ); ?>" <?php selected( $row['status'], $st ); ?>>
									<?php echo esc_html( ucfirst( $st ) ); ?>
								</option>
								<?php endforeach; ?>
							</select>
							<button class="button ls-update-order-btn" data-order-id="<?php echo (int) $row['id']; ?>" style="margin-left:5px;">
								<?php esc_html_e( 'Update', 'learnshapes' ); ?>
							</button>
						</td>
					</tr>
					<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>

			<?php if ( $pages > 1 ) : ?>
			<div class="tablenav bottom" style="margin-top:10px;">
				<div class="tablenav-pages">
					<?php
					echo paginate_links( [
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					] );
					?>
				</div>
			<?php endif; ?>
			</div>
		</div>

		<script>
		jQuery(document).ready(function($) {
			var nonce = '<?php echo esc_js( $admin_nonce ); ?>';

			$('.ls-update-order-btn').on('click', function() {
				var $btn      = $(this);
				var orderId   = $btn.data('order-id');
				var newStatus = $('#ls-orders-table').find('[data-order-id="' + orderId + '"].ls-order-status-select').val();

				$btn.prop('disabled', true).text('<?php echo esc_js( __( 'Saving…', 'learnshapes' ) ); ?>');

				$.post(ajaxurl, {
					action   : 'learnshapes_update_order_status',
					nonce    : nonce,
					order_id : orderId,
					status   : newStatus
				}, function(res) {
					$btn.prop('disabled', false).text('<?php echo esc_js( __( 'Update', 'learnshapes' ) ); ?>');
					if (res.success) {
						// Update badge colour.
						var colors = {
							completed : '#16a34a',
							pending   : '#ca8a04',
							processing: '#2563eb',
							failed    : '#dc2626',
							cancelled : '#6b7280',
							refunded  : '#7c3aed'
						};
						var row  = $('#ls-order-row-' + orderId);
						var badge = row.find('.ls-order-status-badge');
						badge.text(newStatus.charAt(0).toUpperCase() + newStatus.slice(1))
							 .css('background', colors[newStatus] || '#6b7280');

						// Briefly flash success.
						row.css('background', '#f0fdf4');
						setTimeout(function() { row.css('background', ''); }, 1500);
					} else {
						alert(res.data.message || '<?php echo esc_js( __( 'Update failed.', 'learnshapes' ) ); ?>');
					}
				});
			});
		});
		</script>
		<?php
	}
}
