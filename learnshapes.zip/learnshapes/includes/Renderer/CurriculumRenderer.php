<?php
namespace Learnshapes\Renderer;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Renders the curriculum accordion for a given course based on the saved
 * `_learnshapes_course_structure` meta.
 */
class CurriculumRenderer {

    /**
     * Output the HTML for the curriculum.
     *
     * @param int  $course_id   Course post ID.
     * @param bool $is_enrolled Whether the current user is enrolled.
     * @param int  $course_id   Used to build the enroll link.
     */
    public static function render( $course_id, $is_enrolled = false ) {
        $structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
        if ( ! is_array( $structure ) || empty( $structure ) ) {
            echo '<p>' . esc_html__( 'No curriculum defined yet.', 'learnshapes' ) . '</p>';
            return;
        }

        // SVG lock icon (inline, no external dependency)
        $lock_svg = '<svg class="ls-lock-svg" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
        $lock_svg_lg = '<svg class="ls-lock-svg-lg" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';

        // Doc icon SVG
        $doc_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';

        // Quiz icon SVG
        $quiz_svg = '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>';

        echo '<div class="ls-curriculum-accordion' . ( ! $is_enrolled ? ' ls-curriculum-locked' : '' ) . '">';

        foreach ( $structure as $module ) {
            $module_id    = intval( $module['id'] ?? 0 );
            $module_title = esc_html( $module['title'] ?? __( 'Module', 'learnshapes' ) );
            $items_count  = ! empty( $module['items'] ) ? count( $module['items'] ) : 0;

            echo '<div class="ls-accordion-item' . ( ! $is_enrolled ? ' ls-item-locked' : '' ) . '">';

            // Module header
            echo '<button class="ls-accordion-toggle" type="button" data-target="module-' . $module_id . '">';
            echo '<div class="ls-toggle-left">';
            if ( ! $is_enrolled ) {
                echo '<span class="ls-module-lock-icon">' . $lock_svg_lg . '</span>';
            } else {
                echo '<span class="ls-icon-plus-minus dashicons dashicons-plus-alt2"></span> ';
            }
            echo '<span class="ls-module-title">' . $module_title . '</span>';
            echo '</div>';
            echo '<div class="ls-toggle-right">';
            echo '<span class="ls-progress-fraction">0 / ' . $items_count . '</span>';
            if ( ! $is_enrolled ) {
                echo '<span class="ls-module-lock-badge">' . $lock_svg . '</span>';
            } else {
                echo '<span class="ls-circle-icon"></span>';
            }
            echo '</div>';
            echo '</button>';

            // Lessons list
            echo '<div id="module-' . $module_id . '" class="ls-accordion-content" style="display:none;">';
            if ( ! empty( $module['items'] ) && is_array( $module['items'] ) ) {
                echo '<ul class="ls-lesson-list">';
                foreach ( $module['items'] as $lesson ) {
                    $lesson_id    = intval( $lesson['id'] ?? 0 );
                    $lesson_title = esc_html( $lesson['title'] ?? __( 'Lesson', 'learnshapes' ) );
                    $lesson_type  = strtolower( $lesson['type'] ?? 'lesson' );
                    $lesson_link  = get_permalink( $lesson_id );

                    // Detect icon by type
                    if ( strpos( $lesson_type, 'quiz' ) !== false ) {
                        $item_icon      = $quiz_svg;
                        $item_meta      = '10 questions';
                        $item_meta_icon = '';
                    } else {
                        $item_icon      = $doc_svg;
                        $item_meta      = '5 min';
                        $item_meta_icon = '';
                    }

                    echo '<li class="ls-lesson-item' . ( ! $is_enrolled ? ' ls-lesson-locked' : '' ) . '">';

                    if ( $is_enrolled ) {
                        echo '<a href="' . esc_url( $lesson_link ) . '" class="ls-lesson-link">';
                    } else {
                        echo '<div class="ls-lesson-link ls-lesson-link-locked">';
                    }

                    echo '<div class="ls-lesson-left">';
                    echo '<span class="ls-lesson-type-icon">' . $item_icon . '</span>';
                    echo '<span class="ls-lesson-title">' . $lesson_title . '</span>';
                    echo '</div>';
                    echo '<div class="ls-lesson-right">';

                    if ( ! $is_enrolled ) {
                        echo '<span class="ls-lesson-locked-badge">LOCKED</span>';
                    }

                    echo '<span class="ls-lesson-time">' . esc_html( $item_meta ) . '</span>';

                    if ( ! $is_enrolled ) {
                        echo '<span class="ls-lesson-lock-icon">' . $lock_svg . '</span>';
                    } else {
                        echo '<span class="dashicons dashicons-yes-alt ls-check-icon"></span>';
                    }

                    echo '</div>';

                    if ( $is_enrolled ) {
                        echo '</a>';
                    } else {
                        echo '</div>';
                    }

                    echo '</li>';
                }
                echo '</ul>';
            } else {
                echo '<p class="ls-no-items">' . esc_html__( 'No lessons in this module.', 'learnshapes' ) . '</p>';
            }
            echo '</div>'; // accordion content
            echo '</div>'; // accordion item
        }

        echo '</div>'; // accordion wrapper

        // ── "This content is locked" banner (non-enrolled only) ───────────
        if ( ! $is_enrolled ) {
            $checkout_url = \Learnshapes\Payments\GatewayManager::get_checkout_url( $course_id );
            echo '<div class="ls-locked-banner">';
            echo '<div class="ls-locked-banner-left">';
            echo '<div class="ls-locked-banner-icon">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
            echo '</div>';
            echo '<div>';
            echo '<strong>' . esc_html__( 'This content is locked', 'learnshapes' ) . '</strong>';
            echo '<p>' . esc_html__( 'Enroll in this course to access all lessons, quizzes, and course materials.', 'learnshapes' ) . '</p>';
            echo '</div>';
            echo '</div>';
            echo '<a href="' . esc_url( $checkout_url ) . '" class="ls-locked-banner-btn">' . esc_html__( 'Enroll Now', 'learnshapes' ) . '</a>';
            echo '</div>'; // banner
        }

        // ── Accordion toggle script ───────────────────────────────────────
        wp_add_inline_script( 'learnshapes-frontend-js', "
            document.addEventListener('DOMContentLoaded', function(){
                const toggles = document.querySelectorAll('.ls-accordion-toggle');
                toggles.forEach(toggle => {
                    toggle.addEventListener('click', function(){
                        const targetId = this.getAttribute('data-target');
                        const content  = document.getElementById(targetId);
                        if (!content) return;
                        const isVisible = content.style.display !== 'none';
                        content.style.display = isVisible ? 'none' : 'block';
                        const icon = this.querySelector('.ls-icon-plus-minus');
                        const item = this.closest('.ls-accordion-item');
                        if (item) item.classList.toggle('ls-active', !isVisible);
                        if (icon) {
                            icon.classList.toggle('dashicons-plus-alt2', isVisible);
                            icon.classList.toggle('dashicons-minus', !isVisible);
                        }
                    });
                });
                const expandAll   = document.querySelector('.ls-expand-all');
                const collapseAll = document.querySelector('.ls-collapse-all');
                if (expandAll) expandAll.addEventListener('click', function(e){
                    e.preventDefault();
                    document.querySelectorAll('.ls-accordion-content').forEach(c => c.style.display = 'block');
                    document.querySelectorAll('.ls-icon-plus-minus').forEach(i => { i.classList.remove('dashicons-plus-alt2'); i.classList.add('dashicons-minus'); });
                });
                if (collapseAll) collapseAll.addEventListener('click', function(e){
                    e.preventDefault();
                    document.querySelectorAll('.ls-accordion-content').forEach(c => c.style.display = 'none');
                    document.querySelectorAll('.ls-icon-plus-minus').forEach(i => { i.classList.remove('dashicons-minus'); i.classList.add('dashicons-plus-alt2'); });
                });
            });
        " );
    }
}
