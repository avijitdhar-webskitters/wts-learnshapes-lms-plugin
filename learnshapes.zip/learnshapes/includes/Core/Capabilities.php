<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Capabilities {

	/**
	 * Initialize capabilities system.
	 */
	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_roles' ] );
	}

	/**
	 * Register Custom Roles and Capabilities.
	 */
	public static function register_roles() {
		// Register LMS Student Role.
		if ( ! get_role( 'learnshapes_student' ) ) {
			add_role( 'learnshapes_student', __( 'LMS Student', 'learnshapes' ), [
				'read'                           => true,
				'learnshapes_view_player'        => true,
				'learnshapes_submit_quizzes'     => true,
				'learnshapes_submit_assignments' => true,
				'learnshapes_view_dashboard'     => true,
			] );
		}

		// Register LMS Instructor Role.
		if ( ! get_role( 'learnshapes_instructor' ) ) {
			// Get editor capabilities as base.
			$editor = get_role( 'editor' );
			$instructor_caps = $editor ? $editor->capabilities : [ 'read' => true ];

			$lms_caps = [
				'learnshapes_create_courses'     => true,
				'learnshapes_edit_courses'       => true,
				'learnshapes_publish_courses'    => true,
				'learnshapes_manage_lessons'     => true,
				'learnshapes_grade_assignments' => true,
				'learnshapes_view_reports'       => true,
				'learnshapes_view_dashboard'     => true,
				'upload_files'                   => true,
			];

			add_role( 'learnshapes_instructor', __( 'LMS Instructor', 'learnshapes' ), array_merge( $instructor_caps, $lms_caps ) );
		}

		// Add LMS capabilities to administrator role.
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'learnshapes_create_courses' );
			$admin->add_cap( 'learnshapes_edit_courses' );
			$admin->add_cap( 'learnshapes_publish_courses' );
			$admin->add_cap( 'learnshapes_manage_lessons' );
			$admin->add_cap( 'learnshapes_grade_assignments' );
			$admin->add_cap( 'learnshapes_view_reports' );
			$admin->add_cap( 'learnshapes_view_dashboard' );
		}
	}
}
