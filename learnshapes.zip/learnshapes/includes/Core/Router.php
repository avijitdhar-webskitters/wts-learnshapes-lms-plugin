<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Router {

	/**
	 * Initialize template router.
	 */
	public static function init() {
		add_filter( 'template_include', [ __CLASS__, 'template_loader' ] );
	}

	/**
	 * Dynamic template loader with theme override support.
	 *
	 * @param string $template Current template file path.
	 * @return string Modified template file path.
	 */
	public static function template_loader( $template ) {
		if ( isset( $_GET['ls_certificate'] ) ) {
			return self::locate_template( 'dashboard/certificate-view.php' );
		}

		if ( isset( $_GET['ls_order_received'] ) ) {
			return self::locate_template( 'checkout/order-received.php' );
		}

		if ( is_singular( 'learnshapes_course' ) ) {
			return self::locate_template( 'course/single-course.php' );
		}

		if (
			is_singular( 'learnshapes_lesson' ) ||
			is_singular( 'learnshapes_topic' ) ||
			is_singular( 'learnshapes_quiz' ) ||
			is_singular( 'ls_assignment' )
		) {
			// Redirect all course content steps to the distraction-free player layout.
			return self::locate_template( 'course/player.php' );
		}

		return $template;
	}

	/**
	 * Locate template file in theme or fallback to plugin.
	 *
	 * @param string $template_name Template name (e.g. 'course/single-course.php').
	 * @return string File path.
	 */
	public static function locate_template( $template_name ) {
		// 1. Check in the current child/parent theme folder under /learnshapes/
		$theme_file = locate_template( 'learnshapes/' . $template_name );
		if ( $theme_file ) {
			return $theme_file;
		}

		// 2. Fallback to plugin templates directory
		$plugin_file = LEARNSHAPES_PATH . 'templates/' . $template_name;
		if ( file_exists( $plugin_file ) ) {
			return $plugin_file;
		}

		// 3. Fallback to default WordPress query resolution if files aren't found
		return locate_template( 'single.php' );
	}
}
