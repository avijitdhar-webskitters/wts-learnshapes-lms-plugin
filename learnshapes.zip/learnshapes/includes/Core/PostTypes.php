<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PostTypes {

	/**
	 * Initialize Custom Post Types.
	 */
	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_post_types' ], 5 );
		add_action( 'init', [ __CLASS__, 'register_taxonomies' ], 5 );
	}

	/**
	 * Register CPTs.
	 */
	public static function register_post_types() {
		// 1. Courses CPT
		register_post_type( 'learnshapes_course', [
			'labels'              => [
				'name'               => __( 'Courses', 'learnshapes' ),
				'singular_name'      => __( 'Course', 'learnshapes' ),
				'add_new'            => __( 'Add New Course', 'learnshapes' ),
				'add_new_item'       => __( 'Add New Course', 'learnshapes' ),
				'edit_item'          => __( 'Edit Course', 'learnshapes' ),
				'new_item'           => __( 'New Course', 'learnshapes' ),
				'view_item'          => __( 'View Course', 'learnshapes' ),
				'search_items'       => __( 'Search Courses', 'learnshapes' ),
				'not_found'          => __( 'No courses found', 'learnshapes' ),
				'not_found_in_trash' => __( 'No courses found in trash', 'learnshapes' ),
				'all_items'          => __( 'All Courses', 'learnshapes' ),
			],
			'public'              => true,
			'has_archive'         => true,
			'show_in_rest'        => true,
			'supports'            => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'author' ],
			'rewrite'             => [ 'slug' => 'course' ],
			'menu_position'       => 20,
			'menu_icon'           => 'dashicons-welcome-learn-more',
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
		] );

		// Helper parent menu slug
		$parent_menu = 'edit.php?post_type=learnshapes_course';

		// 1b. Modules CPT (curriculum sections inside a course)
		register_post_type( 'learnshapes_module', [
			'labels'          => [
				'name'          => __( 'Modules', 'learnshapes' ),
				'singular_name' => __( 'Module', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Module', 'learnshapes' ),
				'edit_item'     => __( 'Edit Module', 'learnshapes' ),
				'all_items'     => __( 'Modules', 'learnshapes' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => $parent_menu,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields', 'page-attributes' ],
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 2. Lessons CPT
		register_post_type( 'learnshapes_lesson', [
			'labels'          => [
				'name'          => __( 'Lessons', 'learnshapes' ),
				'singular_name' => __( 'Lesson', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Lesson', 'learnshapes' ),
				'edit_item'     => __( 'Edit Lesson', 'learnshapes' ),
				'all_items'     => __( 'Lessons', 'learnshapes' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'thumbnail', 'custom-fields', 'page-attributes' ],
			'rewrite'         => [ 'slug' => 'lessons' ],
			'show_in_menu'    => $parent_menu,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 3. Topics CPT
		register_post_type( 'learnshapes_topic', [
			'labels'          => [
				'name'          => __( 'Topics', 'learnshapes' ),
				'singular_name' => __( 'Topic', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Topic', 'learnshapes' ),
				'edit_item'     => __( 'Edit Topic', 'learnshapes' ),
				'all_items'     => __( 'Topics', 'learnshapes' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields', 'page-attributes' ],
			'rewrite'         => [ 'slug' => 'topics' ],
			'show_in_menu'    => $parent_menu,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 4. Quizzes CPT
		register_post_type( 'learnshapes_quiz', [
			'labels'          => [
				'name'          => __( 'Quizzes', 'learnshapes' ),
				'singular_name' => __( 'Quiz', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Quiz', 'learnshapes' ),
				'edit_item'     => __( 'Edit Quiz', 'learnshapes' ),
				'all_items'     => __( 'Quizzes', 'learnshapes' ),
			],
			'public'          => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields' ],
			'rewrite'         => [ 'slug' => 'quizzes' ],
			'show_in_menu'    => $parent_menu,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 4b. Questions CPT (for Quiz Builder & Question Bank)
		register_post_type( 'learnshapes_question', [
			'labels'          => [
				'name'          => __( 'Questions', 'learnshapes' ),
				'singular_name' => __( 'Question', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Question', 'learnshapes' ),
				'edit_item'     => __( 'Edit Question', 'learnshapes' ),
				'all_items'     => __( 'Question Bank', 'learnshapes' ),
			],
			'public'          => false,
			'show_ui'         => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields' ],
			'show_in_menu'    => $parent_menu,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 5. Assignments CPT
		register_post_type( 'ls_assignment', [
			'labels'          => [
				'name'          => __( 'Assignments', 'learnshapes' ),
				'singular_name' => __( 'Assignment', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Assignment', 'learnshapes' ),
				'edit_item'     => __( 'Edit Assignment', 'learnshapes' ),
				'all_items'     => __( 'Assignments', 'learnshapes' ),
			],
			'public'          => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'custom-fields' ],
			'rewrite'         => [ 'slug' => 'assignments' ],
			'show_in_menu'    => false,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );

		// 6. Certificates CPT
		register_post_type( 'ls_certificate', [
			'labels'          => [
				'name'          => __( 'Certificates', 'learnshapes' ),
				'singular_name' => __( 'Certificate Template', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Certificate Template', 'learnshapes' ),
				'edit_item'     => __( 'Edit Certificate Template', 'learnshapes' ),
				'all_items'     => __( 'Certificates', 'learnshapes' ),
			],
			'public'          => true,
			'publicly_queryable' => false,
			'exclude_from_search' => true,
			'show_ui'         => true,
			'show_in_rest'    => true,
			'supports'        => [ 'title', 'editor', 'thumbnail' ],
			'show_in_menu'    => false,
			'capability_type' => 'post',
			'map_meta_cap'    => true,
		] );
	}

	/**
	 * Register Custom Taxonomies.
	 */
	public static function register_taxonomies() {
		// Course Categories
		register_taxonomy( 'learnshapes_category', [ 'learnshapes_course' ], [
			'hierarchical'      => true,
			'labels'            => [
				'name'              => __( 'Course Categories', 'learnshapes' ),
				'singular_name'     => __( 'Category', 'learnshapes' ),
				'search_items'      => __( 'Search Categories', 'learnshapes' ),
				'all_items'         => __( 'All Categories', 'learnshapes' ),
				'parent_item'       => __( 'Parent Category', 'learnshapes' ),
				'parent_item_colon' => __( 'Parent Category:', 'learnshapes' ),
				'edit_item'         => __( 'Edit Category', 'learnshapes' ),
				'update_item'       => __( 'Update Category', 'learnshapes' ),
				'add_new_item'      => __( 'Add New Category', 'learnshapes' ),
				'new_item_name'     => __( 'New Category Name', 'learnshapes' ),
				'menu_name'         => __( 'Categories', 'learnshapes' ),
			],
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'course-category' ],
		] );

		// Course Tags
		register_taxonomy( 'learnshapes_tag', [ 'learnshapes_course' ], [
			'hierarchical'      => false,
			'labels'            => [
				'name'          => __( 'Course Tags', 'learnshapes' ),
				'singular_name' => __( 'Tag', 'learnshapes' ),
				'search_items'  => __( 'Search Tags', 'learnshapes' ),
				'all_items'     => __( 'All Tags', 'learnshapes' ),
				'edit_item'     => __( 'Edit Tag', 'learnshapes' ),
				'update_item'   => __( 'Update Tag', 'learnshapes' ),
				'add_new_item'  => __( 'Add New Tag', 'learnshapes' ),
				'menu_name'     => __( 'Tags', 'learnshapes' ),
			],
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'course-tag' ],
		] );

		// Course Difficulty
		register_taxonomy( 'learnshapes_difficulty', [ 'learnshapes_course' ], [
			'hierarchical'      => true,
			'labels'            => [
				'name'          => __( 'Course Difficulty', 'learnshapes' ),
				'singular_name' => __( 'Difficulty', 'learnshapes' ),
				'menu_name'     => __( 'Difficulty', 'learnshapes' ),
			],
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'query_var'         => true,
			'rewrite'           => [ 'slug' => 'course-difficulty' ],
		] );
	}
}
