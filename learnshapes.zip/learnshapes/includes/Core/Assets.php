<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	/**
	 * Initialize assets hooks.
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_frontend_assets' ] );
	}

	/**
	 * Enqueue Admin Assets.
	 */
	public static function enqueue_admin_assets( $hook ) {
		// Register Admin Stylesheet.
		wp_register_style(
			'learnshapes-admin-css',
			LEARNSHAPES_URL . 'assets/css/learnshapes-admin.css',
			[],
			time()
		);

		// Register Admin JS.
		wp_register_script(
			'learnshapes-admin-js',
			LEARNSHAPES_URL . 'assets/js/learnshapes-admin.js',
			[ 'jquery' ],
			LEARNSHAPES_VERSION,
			true
		);

		// Register Chart.js for reports
		wp_register_script(
			'learnshapes-chartjs',
			'https://cdn.jsdelivr.net/npm/chart.js',
			[],
			'3.9.1',
			true
		);

		// Localize parameters for script.
		wp_localize_script( 'learnshapes-admin-js', 'learnshapesAdmin', [
			'ajaxurl'   => admin_url( 'admin-ajax.php' ),
			'resturl'   => esc_url_raw( rest_url( 'learnshapes/v1' ) ),
			'nonce'     => wp_create_nonce( 'learnshapes_admin_nonce' ),
			'restNonce' => wp_create_nonce( 'wp_rest' ),
		] );

		// Load assets on our custom admin pages or our custom post types.
		$screen = get_current_screen();
		if (
			( $screen && in_array( $screen->post_type, [ 'learnshapes_course', 'learnshapes_lesson', 'learnshapes_topic', 'learnshapes_quiz', 'ls_assignment', 'ls_certificate' ] ) ) ||
			( isset( $_GET['page'] ) && strpos( $_GET['page'], 'learnshapes' ) !== false )
		) {
			wp_enqueue_style( 'learnshapes-admin-css' );
			wp_enqueue_script( 'learnshapes-admin-js' );
			if ( isset( $_GET['page'] ) && $_GET['page'] === 'learnshapes-reports' ) {
				wp_enqueue_script( 'learnshapes-chartjs' );
			}
			wp_enqueue_media(); // Load WP media library support
		}
	}

	/**
	 * Enqueue Frontend Assets.
	 */
	public static function enqueue_frontend_assets() {
		// Register Frontend CSS.
		wp_register_style(
			'learnshapes-frontend-css',
			LEARNSHAPES_URL . 'assets/css/learnshapes-frontend.css',
			[],
			LEARNSHAPES_VERSION
		);

		// Register Frontend JS.
		wp_register_script(
			'learnshapes-frontend-js',
			LEARNSHAPES_URL . 'assets/js/learnshapes-frontend.js',
			[ 'jquery' ],
			LEARNSHAPES_VERSION,
			true
		);

		// Get checkout page URL
		$settings         = get_option( 'learnshapes_settings', [] );
		$checkout_page_id = isset( $settings['pages']['checkout'] ) ? intval( $settings['pages']['checkout'] ) : 0;
		$checkout_url     = $checkout_page_id ? get_permalink( $checkout_page_id ) : '';

		// Localize frontend variables.
		wp_localize_script( 'learnshapes-frontend-js', 'learnshapes', [
			'ajaxurl'         => admin_url( 'admin-ajax.php' ),
			'resturl'         => esc_url_raw( rest_url( 'learnshapes/v1' ) ),
			'nonce'           => wp_create_nonce( 'learnshapes_frontend_nonce' ),
			'restNonce'       => wp_create_nonce( 'wp_rest' ),
			'is_logged_in'    => is_user_logged_in(),
			'current_user_id' => get_current_user_id(),
			'checkoutUrl'     => $checkout_url,
			'courseUrl'       => is_singular( 'learnshapes_course' ) ? get_permalink() : '',
		] );

		// Load dynamically on LMS related pages, or everywhere if we have widgets/shortcodes.
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_script( 'learnshapes-chartjs' );
		wp_enqueue_style( 'learnshapes-frontend-css' );
		wp_enqueue_script( 'learnshapes-frontend-js' );
	}
}
