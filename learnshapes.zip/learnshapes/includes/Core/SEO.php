<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * SEO integration for Learnshapes.
 * Outputs title, description, and Open Graph tags based on the current post.
 */
class SEO {
    /**
     * Initialize SEO actions.
     */
    public static function init() {
        add_action( 'wp_head', [ __CLASS__, 'output_meta_tags' ] );
    }

    /**
     * Output meta tags in the head section.
     */
    public static function output_meta_tags() {
        if ( is_singular( 'learnshapes_course' ) ) {
            $post = get_queried_object();
            $title = get_the_title( $post );
            $description = get_the_excerpt( $post );
        } elseif ( is_singular( [ 'learnshapes_lesson', 'learnshapes_topic', 'learnshapes_quiz', 'ls_assignment' ] ) ) {
            $post = get_queried_object();
            $title = get_the_title( $post );
            $description = wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
        } else {
            $title = get_bloginfo( 'name' );
            $description = get_bloginfo( 'description' );
            $post = null;
        }

        $title = esc_attr( $title );
        $description = esc_attr( $description );

        echo "<title>{$title}</title>";
        echo "<meta name=\"description\" content=\"{$description}\" />";

        // Open Graph tags for richer sharing.
        if ( $post && has_post_thumbnail( $post ) ) {
            $og_image = esc_url( get_the_post_thumbnail_url( $post, 'large' ) );
            echo "<meta property=\"og:image\" content=\"{$og_image}\" />";
        }
        $url = esc_url( get_permalink( $post ) );
        echo "<meta property=\"og:title\" content=\"{$title}\" />";
        echo "<meta property=\"og:description\" content=\"{$description}\" />";
        echo "<meta property=\"og:url\" content=\"{$url}\" />";
        echo "<meta property=\"og:type\" content=\"website\" />";
    }
}
?>
