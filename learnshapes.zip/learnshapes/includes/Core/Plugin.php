<?php
namespace Learnshapes\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin
	 */
	private static $instance = null;

	/**
	 * Get class instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init();
	}

	/**
	 * Initialize plugin modules.
	 */
	private function init() {
		// Run DB schema upgrades if needed (idempotent) on init so WP is fully loaded.
		add_action( 'init', [ '\Learnshapes\Database\Schema', 'upgrade' ] );

		// Core capabilities and database verification
		\Learnshapes\Core\Capabilities::init();
		\Learnshapes\Core\PostTypes::init();
		\Learnshapes\Core\Router::init();
		\Learnshapes\Core\Assets::init();
		\Learnshapes\Core\SEO::init();

		// Shortcodes and Blocks
		\Learnshapes\Shortcodes\Shortcodes::init();
\Learnshapes\Blocks\BlockRegistry::init();

		// REST API
		\Learnshapes\REST\API::init();
		\Learnshapes\REST\Curriculum::init();
		\Learnshapes\REST\Quiz::init();

		// Admin systems
		if ( is_admin() ) {
			add_filter( 'plugin_row_meta', [ __CLASS__, 'plugin_row_meta' ], 10, 2 );
			add_action( 'admin_footer', [ '\Learnshapes\Admin\DocumentationPopup', 'render' ] );

			\Learnshapes\Admin\Dashboard::init();
			\Learnshapes\Admin\CurriculumBuilder::init();
			\Learnshapes\Admin\CourseSettings::init();
			\Learnshapes\Admin\QuizBuilder::init();
			\Learnshapes\Admin\QuestionBuilder::init();
			\Learnshapes\Admin\CertificateBuilder::init();
			\Learnshapes\Admin\Settings::init();
			\Learnshapes\Admin\DeveloperTools::init();
		}

		// Payments Architecture
		\Learnshapes\Payments\GatewayManager::init();

		// Mail and notifications
		\Learnshapes\Emails\Mailer::init();
	}

	/**
	 * Customize the plugin meta row links.
	 *
	 * @param array  $links Default plugin meta links.
	 * @param string $file  Plugin file.
	 * @return array
	 */
	public static function plugin_row_meta( $links, $file ) {
		if ( strpos( $file, 'learnshapes.php' ) !== false ) {
			// Remove the default "Visit plugin site" link
			foreach ( $links as $key => $link ) {
				if ( strpos( $link, 'learnshapes.com' ) !== false && strpos( $link, 'Visit plugin site' ) !== false ) {
					unset( $links[ $key ] );
				}
			}

			add_thickbox();

			// Add single professional Documentation link that opens a thickbox popup
			$custom_links = [
				'<a href="#TB_inline?width=1000&height=700&inlineId=learnshapes-readme-popup" class="thickbox" style="color: #2563eb; font-weight: 600;">' . esc_html__( 'Documentation', 'learnshapes' ) . '</a>',
			];

			$links = array_merge( $links, $custom_links );
		}
		return $links;
	}
}
