<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CertificateBuilder {

    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_action( 'save_post_ls_certificate', [ __CLASS__, 'save_certificate_data' ] );
    }

    public static function add_meta_box() {
        add_meta_box(
            'ls_certificate_builder',
            __( 'Certificate Builder', 'learnshapes' ),
            [ __CLASS__, 'render_meta_box' ],
            'ls_certificate',
            'normal',
            'high'
        );
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'learnshapes_cert_nonce', 'learnshapes_cert_nonce_val' );
        
        $bg_image_id = get_post_meta( $post->ID, '_ls_cert_bg_id', true );
        $bg_image_url = $bg_image_id ? wp_get_attachment_url( $bg_image_id ) : '';
        $elements_json = get_post_meta( $post->ID, '_ls_cert_elements', true );
        if ( ! $elements_json ) $elements_json = '[]';

        ?>
        <div id="ls-cert-builder">
            <div class="ls-cert-toolbar">
                <div class="ls-cert-btn-group">
                    <button type="button" class="button ls-cert-add-el" data-type="course_name"><span class="dashicons dashicons-welcome-learn-more"></span> Course name</button>
                    <button type="button" class="button ls-cert-add-el" data-type="student_name"><span class="dashicons dashicons-admin-users"></span> Student name</button>
                    <button type="button" class="button ls-cert-add-el" data-type="course_start_date"><span class="dashicons dashicons-calendar-alt"></span> Course start date</button>
                    <button type="button" class="button ls-cert-add-el" data-type="course_end_date"><span class="dashicons dashicons-calendar-alt"></span> Course end date</button>
                    <button type="button" class="button ls-cert-add-el" data-type="current_time"><span class="dashicons dashicons-clock"></span> Current time</button>
                    <button type="button" class="button ls-cert-add-el" data-type="qr_code"><span class="dashicons dashicons-yes"></span> QR code</button>
                    <button type="button" class="button ls-cert-add-el" data-type="custom_text"><span class="dashicons dashicons-editor-textcolor"></span> Custom</button>
                </div>
                <div style="margin-top: 15px;">
                    <button type="button" class="button button-primary" id="ls-cert-btn-bg">Choose background image</button>
                    <button type="button" class="button" id="ls-cert-btn-remove-bg" style="<?php echo $bg_image_id ? '' : 'display:none;'; ?>">Remove background</button>
                </div>
            </div>
            
            <div class="ls-cert-canvas-wrap">
                <div class="ls-cert-ruler-top">
                    <span>25%</span><span>50%</span><span>75%</span>
                </div>
                <div class="ls-cert-ruler-left">
                    <span>25%</span><span>50%</span><span>75%</span>
                </div>
                <div id="ls-cert-canvas" style="background-image: url('<?php echo esc_url($bg_image_url); ?>');">
                    <!-- Elements will be injected here via JS -->
                </div>
            </div>

            <!-- Hidden Inputs -->
            <input type="hidden" name="ls_cert_bg_id" id="ls_cert_bg_id" value="<?php echo esc_attr( $bg_image_id ); ?>">
            <input type="hidden" name="ls_cert_elements" id="ls_cert_elements" value="<?php echo esc_attr( $elements_json ); ?>">
        </div>
        <?php
    }

    public static function save_certificate_data( $post_id ) {
        if ( ! isset( $_POST['learnshapes_cert_nonce_val'] ) || ! wp_verify_nonce( $_POST['learnshapes_cert_nonce_val'], 'learnshapes_cert_nonce' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( isset( $_POST['ls_cert_bg_id'] ) ) {
            update_post_meta( $post_id, '_ls_cert_bg_id', sanitize_text_field( $_POST['ls_cert_bg_id'] ) );
        }
        if ( isset( $_POST['ls_cert_elements'] ) ) {
            // Validate JSON
            $elements = json_decode( stripslashes( $_POST['ls_cert_elements'] ), true );
            if ( json_last_error() === JSON_ERROR_NONE ) {
                update_post_meta( $post_id, '_ls_cert_elements', wp_slash( json_encode( $elements ) ) );
            }
        }
    }

    public static function enqueue_assets( $hook ) {
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
            return;
        }
        $screen = get_current_screen();
        if ( ! $screen || 'ls_certificate' !== $screen->post_type ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style( 'learnshapes-cert-css', plugins_url( '../../assets/css/certificate-builder.css', __FILE__ ), [], time() );
        wp_enqueue_script( 'learnshapes-cert-js', plugins_url( '../../assets/js/certificate-builder.js', __FILE__ ), [ 'jquery', 'jquery-ui-draggable', 'jquery-ui-resizable' ], time(), true );
    }
}
