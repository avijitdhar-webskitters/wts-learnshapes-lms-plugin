<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QuestionBuilder {

    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
        add_action( 'save_post_learnshapes_question', [ __CLASS__, 'save_meta_box' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function add_meta_box() {
        add_meta_box(
            'learnshapes_question_options',
            esc_html__( 'Questions Options', 'learnshapes' ),
            [ __CLASS__, 'render_meta_box' ],
            'learnshapes_question',
            'normal',
            'high'
        );
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'learnshapes_question_nonce', 'ls_question_nonce' );

        $options     = get_post_meta( $post->ID, '_ls_question_options', true );
        if ( ! is_array( $options ) || empty( $options ) ) {
            $options = [
                [ 'title' => 'First option', 'is_correct' => true ],
                [ 'title' => 'Second option', 'is_correct' => false ],
                [ 'title' => 'Third option', 'is_correct' => false ],
            ];
        }
        $points      = get_post_meta( $post->ID, '_ls_question_points', true );
        if ( $points === '' ) $points = '1';
        $hint        = get_post_meta( $post->ID, '_ls_question_hint', true );
        $explanation = get_post_meta( $post->ID, '_ls_question_explanation', true );
        ?>
        <div class="ls-question-builder-wrap">
            <div class="ls-qb-left">
                <div class="ls-qb-header">
                    <span class="ls-qb-title"><?php esc_html_e( 'Config Your Answer', 'learnshapes' ); ?></span>
                    <span class="ls-qb-type"><?php esc_html_e( 'Single Choice', 'learnshapes' ); ?></span>
                </div>
                
                <div class="ls-qb-list-header">
                    <span class="ls-qb-col-answers"><?php esc_html_e( 'Answers', 'learnshapes' ); ?></span>
                    <span class="ls-qb-col-corrects"><?php esc_html_e( 'Corrects', 'learnshapes' ); ?></span>
                </div>

                <ul id="ls-qb-options-list" class="ls-qb-options-list">
                    <?php foreach ( $options as $index => $opt ) : ?>
                    <li class="ls-qb-option-item">
                        <span class="dashicons dashicons-menu ls-qb-drag-handle"></span>
                        <input type="text" name="ls_q_options[<?php echo $index; ?>][title]" value="<?php echo esc_attr( $opt['title'] ); ?>" class="ls-qb-option-input" />
                        <label class="ls-qb-option-radio">
                            <input type="radio" name="ls_q_correct" value="<?php echo $index; ?>" <?php checked( ! empty( $opt['is_correct'] ) ); ?> />
                        </label>
                        <span class="dashicons dashicons-trash ls-qb-delete-opt"></span>
                    </li>
                    <?php endforeach; ?>
                </ul>

                <button type="button" id="ls-qb-add-option" class="button"><span class="dashicons dashicons-plus"></span> <?php esc_html_e( 'Add Option', 'learnshapes' ); ?></button>
            </div>

            <div class="ls-qb-right">
                <div class="ls-qb-header">
                    <span class="ls-qb-title"><?php esc_html_e( 'Option Details', 'learnshapes' ); ?></span>
                </div>

                <div class="ls-qb-field">
                    <label><?php esc_html_e( 'Points', 'learnshapes' ); ?></label>
                    <input type="number" name="ls_q_points" value="<?php echo esc_attr( $points ); ?>" step="1" min="0" class="widefat" />
                    <p class="description"><?php esc_html_e( 'Points for choosing the correct answer.', 'learnshapes' ); ?></p>
                </div>

                <div class="ls-qb-field">
                    <label><?php esc_html_e( 'Hint', 'learnshapes' ); ?></label>
                    <?php 
                    wp_editor( $hint, 'ls_q_hint', [
                        'textarea_name' => 'ls_q_hint',
                        'media_buttons' => true,
                        'textarea_rows' => 4,
                        'teeny'         => false,
                    ] );
                    ?>
                    <p class="description"><?php esc_html_e( 'The instructions for the user to select the right answer. The text will be shown when users click the "Hint" button.', 'learnshapes' ); ?></p>
                </div>

                <div class="ls-qb-field">
                    <label><?php esc_html_e( 'Explanation', 'learnshapes' ); ?></label>
                    <?php 
                    wp_editor( $explanation, 'ls_q_explanation', [
                        'textarea_name' => 'ls_q_explanation',
                        'media_buttons' => true,
                        'textarea_rows' => 4,
                        'teeny'         => false,
                    ] );
                    ?>
                    <p class="description"><?php esc_html_e( 'The explanation will be displayed when students click the "Check Answer" button.', 'learnshapes' ); ?></p>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // Sortable
            if ($.fn.sortable) {
                $('#ls-qb-options-list').sortable({
                    handle: '.ls-qb-drag-handle',
                    axis: 'y',
                    update: function(event, ui) {
                        lsUpdateOptionIndexes();
                    }
                });
            }

            // Add Option
            $('#ls-qb-add-option').on('click', function(e) {
                e.preventDefault();
                var count = $('#ls-qb-options-list li').length;
                var html = '<li class="ls-qb-option-item">' +
                    '<span class="dashicons dashicons-menu ls-qb-drag-handle"></span>' +
                    '<input type="text" name="ls_q_options[' + count + '][title]" value="" class="ls-qb-option-input" placeholder="New option" />' +
                    '<label class="ls-qb-option-radio">' +
                    '<input type="radio" name="ls_q_correct" value="' + count + '" />' +
                    '</label>' +
                    '<span class="dashicons dashicons-trash ls-qb-delete-opt"></span>' +
                    '</li>';
                $('#ls-qb-options-list').append(html);
                lsUpdateOptionIndexes();
            });

            // Delete Option
            $(document).on('click', '.ls-qb-delete-opt', function() {
                if ($('#ls-qb-options-list li').length > 2) {
                    $(this).closest('li').remove();
                    lsUpdateOptionIndexes();
                } else {
                    alert('You must have at least two options.');
                }
            });

            function lsUpdateOptionIndexes() {
                $('#ls-qb-options-list li').each(function(index) {
                    $(this).find('input[type="text"]').attr('name', 'ls_q_options[' + index + '][title]');
                    $(this).find('input[type="radio"]').val(index);
                });
            }
        });
        </script>

        <style>
        .ls-question-builder-wrap {
            display: flex;
            gap: 24px;
            box-sizing: border-box;
        }
        .ls-question-builder-wrap * {
            box-sizing: border-box;
        }
        .ls-qb-left {
            flex: 1;
            min-width: 0;
            border: 1px solid #e2e4e7;
            background: #fff;
        }
        .ls-qb-right {
            flex: 1;
            min-width: 0;
            border: 1px solid #e2e4e7;
            background: #fff;
            padding: 0;
        }
        .ls-qb-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid #e2e4e7;
            background: #f9f9f9;
        }
        .ls-qb-title {
            font-weight: 600;
            color: #1d2327;
        }
        .ls-qb-type {
            font-size: 13px;
            color: #50575e;
            font-weight: 600;
        }
        
        /* Left Column List */
        .ls-qb-list-header {
            display: flex;
            justify-content: space-between;
            padding: 12px 42px 12px 32px;
            background: #e9ecef;
            font-size: 13px;
            font-weight: 600;
            color: #50575e;
        }
        .ls-qb-col-answers { flex: 1; }
        .ls-qb-col-corrects { width: 60px; text-align: center; }

        .ls-qb-options-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .ls-qb-option-item {
            display: flex;
            align-items: center;
            padding: 10px 16px;
            border-bottom: 1px solid #f0f0f1;
            gap: 12px;
            background: #fff;
        }
        .ls-qb-drag-handle {
            color: #a7aaad;
            cursor: move;
        }
        .ls-qb-option-input {
            flex: 1;
            box-shadow: none !important;
            border: 1px solid transparent !important;
            padding: 6px !important;
            transition: border-color 0.2s;
        }
        .ls-qb-option-input:hover, .ls-qb-option-input:focus {
            border-color: #8c8f94 !important;
        }
        .ls-qb-option-radio {
            width: 60px;
            display: flex;
            justify-content: center;
        }
        .ls-qb-delete-opt {
            color: #d63638;
            cursor: pointer;
            visibility: hidden;
        }
        .ls-qb-option-item:hover .ls-qb-delete-opt {
            visibility: visible;
        }
        #ls-qb-add-option {
            margin: 16px;
        }

        /* Right Column Fields */
        .ls-qb-right .ls-qb-field {
            padding: 16px;
            border-bottom: 1px solid #e2e4e7;
        }
        .ls-qb-right .ls-qb-field:last-child {
            border-bottom: none;
        }
        .ls-qb-right label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #1d2327;
        }
        .ls-qb-right .wp-editor-wrap {
            margin-top: 8px;
        }
        .ls-qb-right .description {
            margin-top: 8px;
            font-size: 13px;
            color: #646970;
        }
        </style>
        <?php
    }

    public static function save_meta_box( $post_id ) {
        if ( ! isset( $_POST['ls_question_nonce'] ) || ! wp_verify_nonce( $_POST['ls_question_nonce'], 'learnshapes_question_nonce' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Save Options
        if ( isset( $_POST['ls_q_options'] ) && is_array( $_POST['ls_q_options'] ) ) {
            $options = [];
            $correct = isset( $_POST['ls_q_correct'] ) ? intval( $_POST['ls_q_correct'] ) : 0;
            
            foreach ( wp_unslash( $_POST['ls_q_options'] ) as $index => $opt ) {
                $options[] = [
                    'title'      => sanitize_text_field( $opt['title'] ),
                    'is_correct' => ( $index === $correct )
                ];
            }
            update_post_meta( $post_id, '_ls_question_options', $options );
        }

        // Save Points
        if ( isset( $_POST['ls_q_points'] ) ) {
            update_post_meta( $post_id, '_ls_question_points', intval( $_POST['ls_q_points'] ) );
        }

        // Save Hint
        if ( isset( $_POST['ls_q_hint'] ) ) {
            update_post_meta( $post_id, '_ls_question_hint', wp_kses_post( wp_unslash( $_POST['ls_q_hint'] ) ) );
        }

        // Save Explanation
        if ( isset( $_POST['ls_q_explanation'] ) ) {
            update_post_meta( $post_id, '_ls_question_explanation', wp_kses_post( wp_unslash( $_POST['ls_q_explanation'] ) ) );
        }
    }

    public static function enqueue_assets( $hook ) {
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
            return;
        }
        $screen = get_current_screen();
        if ( ! $screen || 'learnshapes_question' !== $screen->post_type ) {
            return;
        }
        wp_enqueue_script( 'jquery-ui-sortable' );
    }
}
