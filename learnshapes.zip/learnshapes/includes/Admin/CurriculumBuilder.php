<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Curriculum Builder – provides a drag‑and‑drop UI on the Course edit screen
 * similar to LearnDash's curriculum editor.
 */
class CurriculumBuilder {

    /** Initialize hooks */
    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    /** Register the meta box on the Course post type */
    public static function add_meta_box() {
        add_meta_box(
            'learnshapes_curriculum_builder',
            esc_html__( 'Curriculum Builder', 'learnshapes' ),
            [ __CLASS__, 'render_meta_box' ],
            'learnshapes_course',
            'normal',
            'high'
        );
    }

    /** Render the meta box UI */
    public static function render_meta_box( $post ) {
        // Nonce for security when the JS makes REST calls.
        wp_nonce_field( 'learnshapes_curriculum', 'learnshapes_curriculum_nonce' );
        // Container that the JS will populate.
        echo '<div id="learnshapes-curriculum-builder" data-course-id="' . esc_attr( $post->ID ) . '"></div>';
        // Simple fallback message.
        echo '<p>' . esc_html__( 'Use the builder below to add Modules, Lessons and Topics.', 'learnshapes' ) . '</p>';
    }

    /** Enqueue JS & CSS for the builder */
    public static function enqueue_assets( $hook ) {
        // Only load on post edit screens for our CPT.
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
            return;
        }
        $screen = get_current_screen();
        if ( ! $screen || 'learnshapes_course' !== $screen->post_type ) {
            return;
        }
        // JS – uses WordPress’ built‑in fetch and SortableJS (bundled via CDN).
        wp_enqueue_script(
            'learnshapes-curriculum-builder-js',
            plugins_url( '../../assets/js/curriculum-builder.js', __FILE__ ),
            [ 'wp-api', 'jquery' ],
            time(),
            true
        );
        // CSS for the builder UI.
        wp_enqueue_style(
            'learnshapes-curriculum-builder-css',
            plugins_url( '../../assets/css/curriculum-builder.css', __FILE__ ),
            [],
            time()
        );
        // Localize script with REST base and nonce.
        wp_localize_script( 'learnshapes-curriculum-builder-js', 'LearnshapesCurriculum', [
            'root'     => esc_url_raw( rest_url( 'learnshapes/v1' ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'adminUrl' => esc_url_raw( admin_url( 'post.php' ) ),
            'l10n'     => [
                'confirmDelete' => __( 'Are you sure you want to delete this item?', 'learnshapes' ),
            ],
        ] );
    }
}
