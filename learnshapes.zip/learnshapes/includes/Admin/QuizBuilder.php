<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QuizBuilder {

    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function add_meta_box() {
        add_meta_box(
            'learnshapes_quiz_builder',
            esc_html__( 'Quiz Builder', 'learnshapes' ),
            [ __CLASS__, 'render_meta_box' ],
            'learnshapes_quiz',
            'normal',
            'high'
        );
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'learnshapes_quiz', 'learnshapes_quiz_nonce' );
        ?>
        <div id="ls-quiz-builder-app" data-quiz-id="<?php echo esc_attr( $post->ID ); ?>">
            <!-- React/Vue app or Vanilla JS container will render here -->
            <p><?php esc_html_e( 'Loading Quiz Builder...', 'learnshapes' ); ?></p>
        </div>
        <?php
    }

    public static function enqueue_assets( $hook ) {
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
            return;
        }
        $screen = get_current_screen();
        if ( ! $screen || 'learnshapes_quiz' !== $screen->post_type ) {
            return;
        }

        wp_enqueue_script(
            'learnshapes-quiz-builder-js',
            plugins_url( '../../assets/js/quiz-builder.js', __FILE__ ),
            [ 'jquery', 'wp-api', 'wp-util' ],
            time(),
            true
        );

        // Include wp-editor script so we can use wp.editor.initialize dynamically
        wp_enqueue_editor();

        wp_enqueue_style(
            'learnshapes-quiz-builder-css',
            plugins_url( '../../assets/css/quiz-builder.css', __FILE__ ),
            [],
            time()
        );

        wp_localize_script( 'learnshapes-quiz-builder-js', 'LearnshapesQuiz', [
            'root'  => esc_url_raw( rest_url( 'learnshapes/v1' ) ),
            'nonce' => wp_create_nonce( 'wp_rest' ),
            'l10n'  => [
                'deleteConfirm' => __( 'Are you sure you want to delete this question?', 'learnshapes' ),
            ]
        ] );
    }
}
