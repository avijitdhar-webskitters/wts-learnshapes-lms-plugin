<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	/**
	 * Initialize settings panel.
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'register_settings_page' ] );
		add_action( 'wp_ajax_learnshapes_save_payment_order', [ __CLASS__, 'ajax_save_payment_order' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'admin_enqueue_scripts' ] );
		add_action( 'wp_ajax_learnshapes_create_page', [ __CLASS__, 'ajax_create_page' ] );
		add_action( 'wp_ajax_learnshapes_save_settings', [ __CLASS__, 'ajax_save_settings' ] );
	}

	/**
	 * Enqueue admin scripts for payments ordering.
	 */
	public static function admin_enqueue_scripts( $hook ) {
		if ( 'learnshapes_page_learnshapes-settings' !== $hook ) {
			return;
		}
		wp_enqueue_script( 'learnshapes-payment-sort', LEARNSHAPES_URL . 'assets/js/payment-sort.js', [ 'jquery', 'jquery-ui-sortable' ], LEARNSHAPES_VERSION, true );
		wp_enqueue_style( 'learnshapes-payment-sort-css', LEARNSHAPES_URL . 'assets/css/payment-sort.css', [], LEARNSHAPES_VERSION );
		wp_localize_script( 'learnshapes-payment-sort', 'learnshapesPaymentSort', [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'learnshapes_payment_order' ),
		] );
	}

	public static function ajax_save_settings() {
		check_ajax_referer( 'wp_rest', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$form_data = [];
		parse_str( $_POST['form_data'], $form_data );

		// Save general settings
		if ( isset( $form_data['settings'] ) ) {
			$current = get_option( 'learnshapes_settings', [] );
			$updated = array_replace_recursive( $current, $form_data['settings'] );
			update_option( 'learnshapes_settings', $updated );
		}

		// Save specific payment gateway settings
		$gateways = [ 'paypal', 'stripe', 'offline', 'woocommerce' ];
		foreach ( $gateways as $gw ) {
			$key = 'learnshapes_payment_' . $gw;
			if ( isset( $form_data[$key] ) ) {
				update_option( $key, $form_data[$key] );
			} else {
				// Handle unchecked checkboxes
				$current_gw = get_option( $key, [] );
				$current_gw['enabled'] = 'no';
				update_option( $key, $current_gw );
			}
		}

		wp_send_json_success();
	}

	/**
	 * Register settings page under Courses.
	 */
	public static function register_settings_page() {
		add_submenu_page(
			'edit.php?post_type=learnshapes_course',
			__( 'Learnshapes Settings', 'learnshapes' ),
			__( 'Settings', 'learnshapes' ),
			'manage_options',
			'learnshapes-settings',
			[ __CLASS__, 'render_settings' ]
		);
	}

	public static function ajax_create_page() {
		check_ajax_referer( 'wp_rest', 'nonce' ); // Our JS uses wp_rest nonce from LearnshapesCurriculum or settings

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}

		$key = isset( $_POST['page_key'] ) ? sanitize_text_field( $_POST['page_key'] ) : '';
		$title = isset( $_POST['page_title'] ) ? sanitize_text_field( $_POST['page_title'] ) : 'New Page';

		if ( ! $key ) {
			wp_send_json_error( 'Invalid key.' );
		}

		$page_id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => '[learnshapes_' . str_replace( '_page', '', $key ) . ']',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		] );

		if ( is_wp_error( $page_id ) || ! $page_id ) {
			wp_send_json_error( 'Failed to create page.' );
		}

		update_post_meta( $page_id, '_learnshapes_is_default_page', $key );

		wp_send_json_success( [
			'id' => $page_id,
			'title' => get_the_title( $page_id )
		] );
	}

	/**
	 * Render Settings Screen.
	 */
	public static function render_settings() {
		// Fetch current options.
		$settings = get_option( 'learnshapes_settings', [] );

		// Defaults.
		$stripe_enabled = isset( $settings['payment']['stripe_enabled'] ) ? $settings['payment']['stripe_enabled'] : '0';
		$paypal_enabled = isset( $settings['payment']['paypal_enabled'] ) ? $settings['payment']['paypal_enabled'] : '0';
		$stripe_pk      = isset( $settings['payment']['stripe_pk'] ) ? $settings['payment']['stripe_pk'] : '';
		$stripe_sk      = isset( $settings['payment']['stripe_sk'] ) ? $settings['payment']['stripe_sk'] : '';
		$paypal_email   = isset( $settings['payment']['paypal_email'] ) ? $settings['payment']['paypal_email'] : '';
		$currency       = isset( $settings['payment']['currency'] ) ? $settings['payment']['currency'] : 'USD';

		$email_from_name  = isset( $settings['email']['from_name'] ) ? $settings['email']['from_name'] : get_bloginfo( 'name' );
		$email_from_email = isset( $settings['email']['from_email'] ) ? $settings['email']['from_email'] : get_option( 'admin_email' );

		$primary_color = isset( $settings['appearance']['primary_color'] ) ? $settings['appearance']['primary_color'] : '#4f46e5';
		$dark_mode     = isset( $settings['appearance']['dark_mode'] ) ? $settings['appearance']['dark_mode'] : '0';

		$delete_on_uninstall = isset( $settings['advanced']['delete_data_on_uninstall'] ) ? $settings['advanced']['delete_data_on_uninstall'] : '0';
		?>
		<div class="wrap">
			<hr class="wp-header-end">
			<div class="learnshapes-admin-wrap">
				<script>
					var learnshapesSettings = {
						nonce: '<?php echo wp_create_nonce( 'wp_rest' ); ?>'
					};
				</script>
				<div class="learnshapes-header">
					<div class="learnshapes-logo-area">
						<span class="dashicons dashicons-admin-settings"></span>
						<h1 style="margin: 0; padding: 0;"><?php esc_html_e( 'Learnshapes Settings', 'learnshapes' ); ?></h1>
					</div>
					<div class="learnshapes-header-actions">
						<button type="button" id="learnshapes-save-settings" class="button button-primary button-hero">
							<?php esc_html_e( 'Save Settings', 'learnshapes' ); ?>
						</button>
					</div>
				</div>

			<div class="learnshapes-settings-tabs-wrapper">
				<!-- Settings Tabs -->
				<ul class="learnshapes-settings-tabs">
					<li class="active" data-tab="general"><?php esc_html_e( 'General', 'learnshapes' ); ?></li>
					<li data-tab="courses"><?php esc_html_e( 'Courses', 'learnshapes' ); ?></li>
					<li data-tab="profile"><?php esc_html_e( 'Profile', 'learnshapes' ); ?></li>
					<li data-tab="payments"><?php esc_html_e( 'Payments', 'learnshapes' ); ?></li>
					<li data-tab="emails"><?php esc_html_e( 'Emails', 'learnshapes' ); ?></li>
					<li data-tab="permalinks"><?php esc_html_e( 'Permalinks', 'learnshapes' ); ?></li>
					<li data-tab="advanced"><?php esc_html_e( 'Advanced', 'learnshapes' ); ?></li>
					<li data-tab="certificates"><?php esc_html_e( 'Certificates', 'learnshapes' ); ?></li>
				</ul>

				<!-- Settings Content Panels -->
				<div class="learnshapes-settings-content">
					<form id="learnshapes-settings-form">
						<!-- Panel General -->
						<div class="settings-panel active" id="panel-general">
							<h2><?php esc_html_e( 'Pages setup', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<?php
								$pages_setup = [
									'all_courses' => 'All courses page',
									'instructors' => 'All instructors page',
									'single_instructor' => 'Single instructor page',
									'profile' => 'Profile page',
									'checkout' => 'Checkout page',
									'become_teacher' => 'Become an instructors page',
									'terms' => 'Terms and conditions page',
									'logout_redirect' => 'Logout Redirect',
								];
								foreach ( $pages_setup as $key => $label ) :
									$selected = isset( $settings['pages'][$key] ) ? $settings['pages'][$key] : 0;
								?>
								<tr>
									<th scope="row"><label><?php echo esc_html( $label ); ?></label></th>
									<td>
										<?php 
										wp_dropdown_pages( [
											'name' => 'settings[pages][' . $key . ']',
											'show_option_none' => 'Select Page',
											'option_none_value' => '0',
											'selected' => $selected
										] ); 
										?>
										or <button type="button" class="button ls-create-page-btn" data-key="<?php echo esc_attr($key); ?>">Create new</button>
										<?php if ( $selected ) : ?>
											<div style="margin-top: 5px;">
												<a href="<?php echo get_edit_post_link( $selected ); ?>" target="_blank">Edit page</a> | 
												<a href="<?php echo get_permalink( $selected ); ?>" target="_blank">View page</a>
											</div>
										<?php endif; ?>
									</td>
								</tr>
								<?php endforeach; ?>
							</table>

							<hr>
							<h2><?php esc_html_e( 'Currency', 'learnshapes' ); ?></h2>
							<p class="description">Setting up your currency unit and its formatting.</p>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Currency</label></th>
									<td>
										<select name="settings[payment][currency]">
											<option value="USD" <?php selected( $currency, 'USD' ); ?>>US Dollar ($) - USD</option>
											<option value="EUR" <?php selected( $currency, 'EUR' ); ?>>Euro (€) - EUR</option>
											<option value="GBP" <?php selected( $currency, 'GBP' ); ?>>Pound Sterling (£) - GBP</option>
											<option value="INR" <?php selected( $currency, 'INR' ); ?>>Indian rupee (₹) - INR</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Currency position</label></th>
									<td>
										<select name="settings[payment][currency_position]">
											<option value="left" <?php selected( isset($settings['payment']['currency_position']) ? $settings['payment']['currency_position'] : 'left', 'left' ); ?>>Left ( $69.99 )</option>
											<option value="right" <?php selected( isset($settings['payment']['currency_position']) ? $settings['payment']['currency_position'] : 'left', 'right' ); ?>>Right ( 69.99$ )</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Thousands separator</label></th>
									<td>
										<input type="text" name="settings[payment][thousands_separator]" value="<?php echo esc_attr( isset($settings['payment']['thousands_separator']) ? $settings['payment']['thousands_separator'] : ',' ); ?>" class="small-text">
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Decimal separator</label></th>
									<td>
										<input type="text" name="settings[payment][decimal_separator]" value="<?php echo esc_attr( isset($settings['payment']['decimal_separator']) ? $settings['payment']['decimal_separator'] : '.' ); ?>" class="small-text">
									</td>
								</tr>
								<tr>
									<th scope="row"><label>The number of decimals</label></th>
									<td>
										<input type="number" name="settings[payment][number_of_decimals]" value="<?php echo esc_attr( isset($settings['payment']['number_of_decimals']) ? $settings['payment']['number_of_decimals'] : '2' ); ?>" class="small-text">
									</td>
								</tr>
							</table>

							<hr>
							<h2><?php esc_html_e( 'Other', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Publish profile</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[general][publish_profile]" value="1" <?php checked( isset($settings['general']['publish_profile']) ? $settings['general']['publish_profile'] : '0', '1' ); ?>>
											Public all user profile pages (only the overview tab).
										</label>
										<p class="description">This option will add a sub-item "Privacy" under the Setting tab on the Profile page.</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Instructor registration</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[general][instructor_registration]" value="1" <?php checked( isset($settings['general']['instructor_registration']) ? $settings['general']['instructor_registration'] : '0', '1' ); ?>>
											Enable the option in all registration forms.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Store IP Guest to handle checkout</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[general][store_ip]" value="1" <?php checked( isset($settings['general']['store_ip']) ? $settings['general']['store_ip'] : '0', '1' ); ?>>
											Enable the option, IP of client is identifier user instead $_COOKIE
										</label>
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Payments -->
						<div class="settings-panel" id="panel-payments">
							<div class="learnshapes-payments-layout" style="display: flex; min-height: 400px;">
								
								<!-- Left Sidebar -->
								<div class="ls-payments-sidebar" style="width: 200px; border-right: 1px solid #c3c4c7; padding-right: 20px; margin-right: 20px; flex-shrink: 0;">
									<ul class="ls-payment-subtabs" style="margin: 0; padding: 0; list-style: none;">
										<li style="margin-bottom: 5px;"><a href="#payment-general" class="ls-sidebar-tab ls-sidebar-tab-active" style="text-decoration: none; display: block; padding: 8px 12px; color: #4f46e5; background: #f0f1ff; font-weight: 600; border-radius: 4px;">General</a></li>
										<li style="margin-bottom: 5px;"><a href="#payment-paypal" class="ls-sidebar-tab" style="text-decoration: none; display: block; padding: 8px 12px; color: #2271b1; background: transparent; border-radius: 4px;">PayPal</a></li>
										<li style="margin-bottom: 5px;"><a href="#payment-stripe" class="ls-sidebar-tab" style="text-decoration: none; display: block; padding: 8px 12px; color: #2271b1; background: transparent; border-radius: 4px;">Stripe</a></li>
										<li style="margin-bottom: 5px;"><a href="#payment-offline" class="ls-sidebar-tab" style="text-decoration: none; display: block; padding: 8px 12px; color: #2271b1; background: transparent; border-radius: 4px;">Offline Payment</a></li>
										<li style="margin-bottom: 5px;"><a href="#payment-woocommerce" class="ls-sidebar-tab" style="text-decoration: none; display: block; padding: 8px 12px; color: #2271b1; background: transparent; border-radius: 4px;">WooCommerce Payment</a></li>
									</ul>
								</div>

								<!-- Right Content Area -->
								<div class="ls-payments-content" style="flex-grow: 1;">
									
									<!-- General -->
									<div class="ls-payment-subpanel active" id="payment-general">
										<table class="form-table">
											<tr>
												<th scope="row"><label>Guest checkout</label></th>
												<td>
													<label>
														<input type="checkbox" name="settings[payment][guest_checkout]" value="1" <?php checked( isset($settings['payment']['guest_checkout']) ? $settings['payment']['guest_checkout'] : '0', '1' ); ?>>
														Allow customers to place orders without an account.
													</label>
												</td>
											</tr>
											<tr>
												<th scope="row"><label>Account Login</label></th>
												<td>
													<label>
														<input type="checkbox" name="settings[payment][account_login]" value="1" <?php checked( isset($settings['payment']['account_login']) ? $settings['payment']['account_login'] : '1', '1' ); ?>>
														Allow customers to log into an existing account during checkout.
													</label>
												</td>
											</tr>
											<tr>
												<th scope="row"><label>Account Creation</label></th>
												<td>
													<label>
														<input type="checkbox" name="settings[payment][account_creation]" value="1" <?php checked( isset($settings['payment']['account_creation']) ? $settings['payment']['account_creation'] : '1', '1' ); ?>>
														Allow customers to create an account during checkout.
													</label>
												</td>
											</tr>
											<tr>
												<th scope="row"><label>Order Slug</label></th>
												<td>
													<input type="text" name="settings[payment][order_slug]" value="<?php echo esc_attr( isset($settings['payment']['order_slug']) ? $settings['payment']['order_slug'] : 'order' ); ?>" class="regular-text">
												</td>
											</tr>
										</table>

										<hr>
										<h3><?php esc_html_e( 'Payment Methods Ordering', 'learnshapes' ); ?></h3>
										<table class="wp-list-table widefat fixed striped">
									<thead>
										<tr>
											<th>Method</th>
											<th>Enabled</th>
											<th>Description</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td><strong>PayPal</strong><br><small>paypal</small></td>
											<td><input type="checkbox" name="learnshapes_payment_paypal[enabled]" value="yes" <?php checked( get_option('learnshapes_payment_paypal', [])['enabled'] ?? 'no', 'yes' ); ?>></td>
											<td>Pay via PayPal.</td>
										</tr>
										<tr>
											<td><strong>Stripe</strong><br><small>stripe</small></td>
											<td><input type="checkbox" name="learnshapes_payment_stripe[enabled]" value="yes" <?php checked( get_option('learnshapes_payment_stripe', [])['enabled'] ?? 'no', 'yes' ); ?>></td>
											<td>Pay via Stripe.</td>
										</tr>
										<tr>
											<td><strong>Offline Payment</strong><br><small>offline</small></td>
											<td><input type="checkbox" name="learnshapes_payment_offline[enabled]" value="yes" <?php checked( get_option('learnshapes_payment_offline', [])['enabled'] ?? 'no', 'yes' ); ?>></td>
											<td>Pay via bank transfer or cash.</td>
										</tr>
										<tr>
											<td><strong>WooCommerce Payment</strong><br><small>woocommerce</small></td>
											<td><input type="checkbox" name="learnshapes_payment_woocommerce[enabled]" value="yes" <?php checked( get_option('learnshapes_payment_woocommerce', [])['enabled'] ?? 'no', 'yes' ); ?>></td>
											<td>Redirect to WooCommerce checkout.</td>
										</tr>
									</tbody>
								</table>
							</div>

							<!-- PayPal -->
							<div class="ls-payment-subpanel" id="payment-paypal" style="display:none;">
								<table class="form-table">
									<?php $pp_opts = get_option('learnshapes_payment_paypal', []); ?>
									<tr>
										<th scope="row"><label>Enable/Disable</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_paypal[enabled]" value="yes" <?php checked( $pp_opts['enabled'] ?? 'no', 'yes' ); ?>> Enable PayPal</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Sandbox mode</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_paypal[sandbox]" value="yes" <?php checked( $pp_opts['sandbox'] ?? 'yes', 'yes' ); ?>> Enable PayPal sandbox</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Client ID</label></th>
										<td>
											<input type="text" name="learnshapes_payment_paypal[client_id]" value="<?php echo esc_attr($pp_opts['client_id'] ?? ''); ?>" class="regular-text">
											<p class="description"><a href="https://developer.paypal.com/dashboard/applications/sandbox" target="_blank">How to get Client ID</a></p>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Client Secret</label></th>
										<td>
											<input type="password" name="learnshapes_payment_paypal[client_secret]" value="<?php echo esc_attr($pp_opts['client_secret'] ?? ''); ?>" class="regular-text">
											<p class="description"><a href="https://developer.paypal.com/dashboard/applications/sandbox" target="_blank">How to get Client Secret</a></p>
										</td>
									</tr>
								</table>
							</div>

							<!-- Stripe -->
							<div class="ls-payment-subpanel" id="payment-stripe" style="display:none;">
								<table class="form-table">
									<?php $stripe_opts = get_option('learnshapes_payment_stripe', []); ?>
									<tr>
										<th scope="row"><label>Enable/Disable</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_stripe[enabled]" value="yes" <?php checked( $stripe_opts['enabled'] ?? 'no', 'yes' ); ?>> Enable Stripe</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Test mode</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_stripe[testmode]" value="yes" <?php checked( $stripe_opts['testmode'] ?? 'yes', 'yes' ); ?>> Enable Stripe test mode</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Publishable Key</label></th>
										<td>
											<input type="text" name="learnshapes_payment_stripe[publishable_key]" value="<?php echo esc_attr($stripe_opts['publishable_key'] ?? ''); ?>" class="regular-text">
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Secret Key</label></th>
										<td>
											<input type="password" name="learnshapes_payment_stripe[secret_key]" value="<?php echo esc_attr($stripe_opts['secret_key'] ?? ''); ?>" class="regular-text">
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Test Publishable Key</label></th>
										<td>
											<input type="text" name="learnshapes_payment_stripe[test_publishable_key]" value="<?php echo esc_attr($stripe_opts['test_publishable_key'] ?? ''); ?>" class="regular-text">
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Test Secret Key</label></th>
										<td>
											<input type="password" name="learnshapes_payment_stripe[test_secret_key]" value="<?php echo esc_attr($stripe_opts['test_secret_key'] ?? ''); ?>" class="regular-text">
										</td>
									</tr>
								</table>
							</div>

							<!-- Offline Payment -->
							<div class="ls-payment-subpanel" id="payment-offline" style="display:none;">
								<table class="form-table">
									<?php $off_opts = get_option('learnshapes_payment_offline', []); ?>
									<tr>
										<th scope="row"><label>Enable/Disable</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_offline[enabled]" value="yes" <?php checked( $off_opts['enabled'] ?? 'no', 'yes' ); ?>> Enable Offline Payment</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Instructions</label></th>
										<td><textarea name="learnshapes_payment_offline[instructions]" rows="5" class="large-text"><?php echo esc_textarea($off_opts['instructions'] ?? 'Please transfer the money to our bank account.'); ?></textarea></td>
									</tr>
								</table>
							</div>

							<!-- WooCommerce Payment -->
							<div class="ls-payment-subpanel" id="payment-woocommerce" style="display:none;">
								<table class="form-table">
									<?php $wc_opts = get_option('learnshapes_payment_woocommerce', []); ?>
									<tr>
										<th scope="row"><label>Enable/Disable</label></th>
										<td>
											<label><input type="checkbox" name="learnshapes_payment_woocommerce[enabled]" value="yes" <?php checked( $wc_opts['enabled'] ?? 'no', 'yes' ); ?>> Enable WooCommerce Integration</label>
										</td>
									</tr>
									<tr>
										<th scope="row"><label>Integration Info</label></th>
										<td>
											<p class="description">To use WooCommerce, create a WooCommerce product and link it to your Learnshapes Course in the Course Editor Settings.</p>
										</td>
									</tr>
								</table>
							</div>

								</div> <!-- .ls-payments-content -->
							</div> <!-- .learnshapes-payments-layout -->
						</div>

						<!-- Panel Emails -->
						<div class="settings-panel" id="panel-emails">
							<h2><?php esc_html_e( 'Email System Config', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<tr>
									<th scope="row"><label><?php esc_html_e( 'Sender Name', 'learnshapes' ); ?></label></th>
									<td>
										<input type="text" name="settings[email][from_name]" value="<?php echo esc_attr( $email_from_name ); ?>" class="regular-text" />
									</td>
								</tr>
								<tr>
									<th scope="row"><label><?php esc_html_e( 'Sender Email Address', 'learnshapes' ); ?></label></th>
									<td>
										<input type="email" name="settings[email][from_email]" value="<?php echo esc_attr( $email_from_email ); ?>" class="regular-text" />
									</td>
								</tr>
							</table>
							<hr>
							<h3><?php esc_html_e( 'Email Notifications', 'learnshapes' ); ?></h3>
							<table class="form-table">
								<tr>
									<th scope="row"><label>New User Registration</label></th>
									<td>
										<label><input type="checkbox" name="settings[email][notify_registration]" value="1" <?php checked( isset($settings['email']['notify_registration']) ? $settings['email']['notify_registration'] : '1', '1' ); ?>> Enable confirmation email to new students</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Course Enrollment</label></th>
									<td>
										<label><input type="checkbox" name="settings[email][notify_enrollment]" value="1" <?php checked( isset($settings['email']['notify_enrollment']) ? $settings['email']['notify_enrollment'] : '1', '1' ); ?>> Enable course welcome email</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Order Receipt</label></th>
									<td>
										<label><input type="checkbox" name="settings[email][notify_order]" value="1" <?php checked( isset($settings['email']['notify_order']) ? $settings['email']['notify_order'] : '1', '1' ); ?>> Enable payment confirmation email</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Course Completion</label></th>
									<td>
										<label><input type="checkbox" name="settings[email][notify_completion]" value="1" <?php checked( isset($settings['email']['notify_completion']) ? $settings['email']['notify_completion'] : '1', '1' ); ?>> Enable congratulations email upon 100% completion</label>
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Courses -->
						<div class="settings-panel" id="panel-courses">
							<h2><?php esc_html_e( 'Courses Settings', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Courses per page</label></th>
									<td>
										<input type="number" name="settings[courses][per_page]" value="<?php echo esc_attr( isset($settings['courses']['per_page']) ? $settings['courses']['per_page'] : '12' ); ?>" class="small-text">
										<p class="description">Number of courses to show on the archive/grid page.</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Default View</label></th>
									<td>
										<select name="settings[courses][default_view]">
											<option value="grid" <?php selected( isset($settings['courses']['default_view']) ? $settings['courses']['default_view'] : 'grid', 'grid' ); ?>>Grid View</option>
											<option value="list" <?php selected( isset($settings['courses']['default_view']) ? $settings['courses']['default_view'] : 'grid', 'list' ); ?>>List View</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>AJAX Features</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[courses][ajax_filter]" value="1" <?php checked( isset($settings['courses']['ajax_filter']) ? $settings['courses']['ajax_filter'] : '1', '1' ); ?>>
											Enable AJAX loading for sidebar filters.
										</label><br>
										<label>
											<input type="checkbox" name="settings[courses][ajax_load_more]" value="1" <?php checked( isset($settings['courses']['ajax_load_more']) ? $settings['courses']['ajax_load_more'] : '1', '1' ); ?>>
											Enable AJAX "Load More" button instead of traditional pagination.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Course Card Display</label></th>
									<td>
										<label><input type="checkbox" name="settings[courses][show_instructor]" value="1" <?php checked( isset($settings['courses']['show_instructor']) ? $settings['courses']['show_instructor'] : '1', '1' ); ?>> Show Instructor</label><br>
										<label><input type="checkbox" name="settings[courses][show_rating]" value="1" <?php checked( isset($settings['courses']['show_rating']) ? $settings['courses']['show_rating'] : '1', '1' ); ?>> Show Rating</label><br>
										<label><input type="checkbox" name="settings[courses][show_lessons]" value="1" <?php checked( isset($settings['courses']['show_lessons']) ? $settings['courses']['show_lessons'] : '1', '1' ); ?>> Show Lesson Count</label><br>
										<label><input type="checkbox" name="settings[courses][show_level]" value="1" <?php checked( isset($settings['courses']['show_level']) ? $settings['courses']['show_level'] : '1', '1' ); ?>> Show Difficulty Level</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Excerpt Length</label></th>
									<td>
										<input type="number" name="settings[courses][excerpt_length]" value="<?php echo esc_attr( isset($settings['courses']['excerpt_length']) ? $settings['courses']['excerpt_length'] : '12' ); ?>" class="small-text"> words
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Profile -->
						<div class="settings-panel" id="panel-profile">
							<h2><?php esc_html_e( 'Profile Settings', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Profile Layout</label></th>
									<td>
										<select name="settings[profile][layout]">
											<option value="left_sidebar" <?php selected( isset($settings['profile']['layout']) ? $settings['profile']['layout'] : 'left_sidebar', 'left_sidebar' ); ?>>Left Sidebar</option>
											<option value="top_navigation" <?php selected( isset($settings['profile']['layout']) ? $settings['profile']['layout'] : 'left_sidebar', 'top_navigation' ); ?>>Top Navigation</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Profile Banner</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[profile][show_banner]" value="1" <?php checked( isset($settings['profile']['show_banner']) ? $settings['profile']['show_banner'] : '1', '1' ); ?>>
											Enable cover image on user profiles.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Profile Tabs Display</label></th>
									<td>
										<label><input type="checkbox" name="settings[profile][tab_courses]" value="1" <?php checked( isset($settings['profile']['tab_courses']) ? $settings['profile']['tab_courses'] : '1', '1' ); ?>> Enrolled Courses</label><br>
										<label><input type="checkbox" name="settings[profile][tab_certificates]" value="1" <?php checked( isset($settings['profile']['tab_certificates']) ? $settings['profile']['tab_certificates'] : '1', '1' ); ?>> Certificates</label><br>
										<label><input type="checkbox" name="settings[profile][tab_quizzes]" value="1" <?php checked( isset($settings['profile']['tab_quizzes']) ? $settings['profile']['tab_quizzes'] : '1', '1' ); ?>> Quiz Attempts</label><br>
										<label><input type="checkbox" name="settings[profile][tab_wishlist]" value="1" <?php checked( isset($settings['profile']['tab_wishlist']) ? $settings['profile']['tab_wishlist'] : '1', '1' ); ?>> Wishlist</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Avatar Size</label></th>
									<td>
										<input type="number" name="settings[profile][avatar_size]" value="<?php echo esc_attr( isset($settings['profile']['avatar_size']) ? $settings['profile']['avatar_size'] : '150' ); ?>" class="small-text"> px
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Public Profile</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[profile][is_public]" value="1" <?php checked( isset($settings['profile']['is_public']) ? $settings['profile']['is_public'] : '0', '1' ); ?>>
											Allow non-logged in users to view basic student profiles.
										</label>
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Permalinks -->
						<div class="settings-panel" id="panel-permalinks">
							<h2><?php esc_html_e( 'Permalinks', 'learnshapes' ); ?></h2>
							<p class="description">Customize the URL structure for LMS content. Saving these settings will automatically flush rewrite rules.</p>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Course Base</label></th>
									<td>
										<input type="text" name="settings[permalinks][course_base]" value="<?php echo esc_attr( isset($settings['permalinks']['course_base']) ? $settings['permalinks']['course_base'] : 'courses' ); ?>" class="regular-text">
										<p class="description">Example: yoursite.com/<strong>courses</strong>/sample-course/</p>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Lesson Base</label></th>
									<td>
										<input type="text" name="settings[permalinks][lesson_base]" value="<?php echo esc_attr( isset($settings['permalinks']['lesson_base']) ? $settings['permalinks']['lesson_base'] : 'lessons' ); ?>" class="regular-text">
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Topic Base</label></th>
									<td>
										<input type="text" name="settings[permalinks][topic_base]" value="<?php echo esc_attr( isset($settings['permalinks']['topic_base']) ? $settings['permalinks']['topic_base'] : 'topic' ); ?>" class="regular-text">
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Quiz Base</label></th>
									<td>
										<input type="text" name="settings[permalinks][quiz_base]" value="<?php echo esc_attr( isset($settings['permalinks']['quiz_base']) ? $settings['permalinks']['quiz_base'] : 'quizzes' ); ?>" class="regular-text">
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Category Base</label></th>
									<td>
										<input type="text" name="settings[permalinks][category_base]" value="<?php echo esc_attr( isset($settings['permalinks']['category_base']) ? $settings['permalinks']['category_base'] : 'course-category' ); ?>" class="regular-text">
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Certificates -->
						<div class="settings-panel" id="panel-certificates">
							<h2><?php esc_html_e( 'Certificates', 'learnshapes' ); ?></h2>
							<p class="description">Manage settings for completion certificates awarded to students.</p>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Enable Certificates</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[certificates][enabled]" value="1" <?php checked( isset($settings['certificates']['enabled']) ? $settings['certificates']['enabled'] : '1', '1' ); ?>>
											Allow courses to award certificates upon 100% completion.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Page Format</label></th>
									<td>
										<select name="settings[certificates][format]">
											<option value="A4" <?php selected( isset($settings['certificates']['format']) ? $settings['certificates']['format'] : 'A4', 'A4' ); ?>>A4 (Standard)</option>
											<option value="Letter" <?php selected( isset($settings['certificates']['format']) ? $settings['certificates']['format'] : 'A4', 'Letter' ); ?>>US Letter</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Orientation</label></th>
									<td>
										<select name="settings[certificates][orientation]">
											<option value="landscape" <?php selected( isset($settings['certificates']['orientation']) ? $settings['certificates']['orientation'] : 'landscape', 'landscape' ); ?>>Landscape</option>
											<option value="portrait" <?php selected( isset($settings['certificates']['orientation']) ? $settings['certificates']['orientation'] : 'landscape', 'portrait' ); ?>>Portrait</option>
										</select>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Allow Downloads</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[certificates][allow_download]" value="1" <?php checked( isset($settings['certificates']['allow_download']) ? $settings['certificates']['allow_download'] : '1', '1' ); ?>>
											Allow students to download their certificates as PDF.
										</label>
									</td>
								</tr>
							</table>
						</div>

						<!-- Panel Advanced -->
						<div class="settings-panel" id="panel-advanced">
							<h2><?php esc_html_e( 'Database and Diagnostics', 'learnshapes' ); ?></h2>
							<table class="form-table">
								<tr>
									<th scope="row"><label>Debug Mode</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[advanced][debug_mode]" value="1" <?php checked( isset($settings['advanced']['debug_mode']) ? $settings['advanced']['debug_mode'] : '0', '1' ); ?>>
											Enable LMS debug logging to help diagnose issues.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>Course Schema Markup</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[advanced][schema_markup]" value="1" <?php checked( isset($settings['advanced']['schema_markup']) ? $settings['advanced']['schema_markup'] : '1', '1' ); ?>>
											Enable SEO Course Schema for Google rich snippets.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><label>REST API Access</label></th>
									<td>
										<label>
											<input type="checkbox" name="settings[advanced][rest_api]" value="1" <?php checked( isset($settings['advanced']['rest_api']) ? $settings['advanced']['rest_api'] : '1', '1' ); ?>>
											Allow REST API access to LMS data.
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Clean Uninstall Cleanup', 'learnshapes' ); ?></th>
									<td>
										<label>
											<input type="checkbox" name="settings[advanced][delete_data_on_uninstall]" value="1" <?php checked( $delete_on_uninstall, '1' ); ?> />
											<span class="text-danger"><?php esc_html_e( 'Permanently delete all tables, courses, and data upon plugin deletion.', 'learnshapes' ); ?></span>
										</label>
									</td>
								</tr>
							</table>
						</div>
					</form>
				</div>
			</div>
		</div>

		<script>
		jQuery(document).ready(function($) {

			// ── Tab switching ──────────────────────────────────────────────────
			$('.learnshapes-settings-tabs li').on('click', function() {
				var tab = $(this).data('tab');
				$('.learnshapes-settings-tabs li').removeClass('active');
				$(this).addClass('active');
				$('.settings-panel').removeClass('active');
				$('#panel-' + tab).addClass('active');
			});

			// ── Payment sub-tab switching ──────────────────────────────────────
			$(document).on('click', '.ls-payment-subtabs a.ls-sidebar-tab', function(e) {
				e.preventDefault();
				var target = $(this).attr('href');
				$('.ls-payment-subtabs a.ls-sidebar-tab').removeClass('ls-sidebar-tab-active').css({'color': '#2271b1', 'background': 'transparent', 'font-weight': 'normal'});
				$(this).addClass('ls-sidebar-tab-active').css({'color': '#4f46e5', 'background': '#f0f1ff', 'font-weight': '600'});
				$('.ls-payment-subpanel').hide();
				$(target).show();
			});

			// ── Create page AJAX ───────────────────────────────────────────────
			$(document).on('click', '.ls-create-page-btn', function() {
				var $btn = $(this);
				var key  = $btn.data('key');
				var title = key.replace(/_/g, ' ').replace(/\b\w/g, function(l){ return l.toUpperCase(); });
				$btn.prop('disabled', true).text('Creating…');
				$.post(ajaxurl, {
					action     : 'learnshapes_create_page',
					nonce      : '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>',
					page_key   : key,
					page_title : title
				}, function(res) {
					$btn.prop('disabled', false).text('Create new');
					if (res.success) {
						location.reload();
					} else {
						alert('Error: ' + (res.data || 'Could not create page'));
					}
				});
			});

			// ── Save settings AJAX ─────────────────────────────────────────────
			$('#learnshapes-save-settings').on('click', function() {
				var $button      = $(this);
				var originalHtml = $button.html();
				$button.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Saving…');

				$.ajax({
					url  : ajaxurl,
					method: 'POST',
					data : {
						action    : 'learnshapes_save_settings',
						nonce     : '<?php echo esc_js( wp_create_nonce( 'wp_rest' ) ); ?>',
						form_data : $('#learnshapes-settings-form').serialize()
					},
					success: function(res) {
						$button.prop('disabled', false);
						if (res.success) {
							$button.html('Saved!');
						} else {
							$button.html('Error!');
							console.error(res.data);
						}
						setTimeout(function() { $button.html(originalHtml); }, 2500);
					},
					error: function() {
						$button.prop('disabled', false).html(originalHtml);
						alert('Failed to save settings. Please try again.');
					}
				});
			});
		});
		</script>
	<?php
	}

	/**
	 * AJAX handler to save payment method order.
	 */
	public static function ajax_save_payment_order() {
		check_ajax_referer( 'learnshapes_payment_order', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.' );
		}
		$order_data = $_POST['order'] ?? [];
		if ( ! is_array( $order_data ) ) {
			wp_send_json_error( 'Invalid data.' );
		}
		foreach ( $order_data as $gateway_id => $order ) {
			$opt_key = 'learnshapes_payment_' . sanitize_key( $gateway_id );
			$opts    = get_option( $opt_key, [] );
			$opts['order'] = intval( $order );
			update_option( $opt_key, $opts );
		}
		wp_send_json_success();
	}
}
