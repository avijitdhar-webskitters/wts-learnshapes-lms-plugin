<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DocumentationPopup {

	public static function render() {
		$readme_path = LEARNSHAPES_PATH . 'README.md';
		if ( ! file_exists( $readme_path ) ) {
			return;
		}

		$content = file_get_contents( $readme_path );
		$content = htmlspecialchars( $content, ENT_QUOTES );

		// Parse code blocks
		$content = preg_replace_callback('/```(?:.*?)\n(.*?)\n```/s', function($matches) {
			return '<pre><code>' . trim($matches[1]) . '</code></pre>';
		}, $content);

		// Basic inline formatting
		$content = preg_replace( '/\*\*(.*)\*\*/U', '<strong>$1</strong>', $content );
		$content = preg_replace( '/\`([^\`]+)\`/U', '<code>$1</code>', $content );
		$content = preg_replace( '/^[-*]\s+(.*)$/m', '<li>$1</li>', $content );
		$content = preg_replace( '/^### (.*)$/m', '<h3>$1</h3>', $content );
		$content = preg_replace( '/^> (.*)$/m', '<blockquote>$1</blockquote>', $content );

		// Split by ## headings
		$parts = explode('## ', $content);
		
		$overview_raw = array_shift($parts);
		$overview_raw = preg_replace( '/^# (.*)$/m', '', $overview_raw );
		$overview = self::format_body( $overview_raw );

		$sections = [];
		foreach ($parts as $part) {
			$lines = explode("\n", $part, 2);
			$title = trim($lines[0]);
			$body = isset($lines[1]) ? trim($lines[1]) : '';
			$sections[$title] = self::format_body( $body );
		}

		// Helper function to extract section by partial title
		$get_section = function($search) use ($sections) {
			foreach ($sections as $title => $body) {
				if (stripos($title, $search) !== false) {
					return ['title' => $title, 'body' => $body];
				}
			}
			return ['title' => $search, 'body' => ''];
		};

		$sec_features = $get_section('Features');
		$sec_installation = $get_section('Installation');
		$sec_directory = $get_section('Directory Structure');
		$sec_templates = $get_section('Template Overrides');
		$sec_shortcodes = $get_section('Shortcodes');
		$sec_developer = $get_section('Developer API');
		$sec_requirements = $get_section('Requirements');

		?>
		<div id="learnshapes-readme-popup" style="display:none;">
			<style>
				/* General Thickbox overrides */
				#TB_window { border-radius: 12px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.2) !important; border: none !important; }
				#TB_title { display: none !important; } /* Hide default title bar */
				#TB_ajaxContent { padding: 0 !important; width: 100% !important; height: 100% !important; overflow: hidden !important; }

				.ls-doc-wrapper {
					display: flex;
					height: 100%;
					font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
					background: #f8fafc;
					color: #334155;
					overflow: hidden;
				}

				/* Left Sidebar */
				.ls-doc-sidebar {
					width: 280px;
					background: #ffffff;
					border-right: 1px solid #e2e8f0;
					display: flex;
					flex-direction: column;
					flex-shrink: 0;
					padding: 24px;
				}

				.ls-doc-brand {
					display: flex;
					align-items: center;
					gap: 12px;
					margin-bottom: 30px;
				}

				.ls-doc-logo {
					background: #2563eb;
					color: white;
					width: 40px;
					height: 40px;
					border-radius: 8px;
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 20px;
				}

				.ls-doc-title strong {
					display: block;
					color: #0f172a;
					font-size: 16px;
					line-height: 1.2;
				}

				.ls-doc-title span {
					font-size: 12px;
					color: #64748b;
				}

				.ls-doc-title .badge {
					background: #eff6ff;
					color: #2563eb;
					padding: 2px 6px;
					border-radius: 4px;
					font-weight: 600;
					margin-left: 4px;
				}

				.ls-doc-nav {
					list-style: none;
					padding: 0;
					margin: 0;
					flex-grow: 1;
				}

				.ls-doc-nav li {
					margin-bottom: 4px;
				}

				.ls-doc-nav a {
					display: flex;
					align-items: center;
					gap: 10px;
					padding: 10px 14px;
					color: #475569;
					text-decoration: none;
					border-radius: 6px;
					font-weight: 500;
					font-size: 14px;
					transition: all 0.2s;
				}

				.ls-doc-nav a:hover {
					background: #f1f5f9;
					color: #0f172a;
				}

				.ls-doc-nav a.active {
					background: #2563eb;
					color: #ffffff;
				}

				.ls-doc-nav a i {
					width: 20px;
					height: 20px;
					font-size: 16px;
					display: flex;
					align-items: center;
					justify-content: center;
				}

				.ls-doc-help {
					background: #f8fafc;
					border: 1px solid #e2e8f0;
					padding: 16px;
					border-radius: 8px;
					margin-top: 20px;
				}

				.ls-doc-help strong {
					display: flex;
					align-items: center;
					gap: 6px;
					color: #2563eb;
					font-size: 14px;
					margin-bottom: 8px;
				}

				.ls-doc-help p {
					font-size: 12px;
					color: #64748b;
					margin: 0 0 12px 0;
					line-height: 1.5;
				}

				.ls-doc-help .btn {
					display: block;
					text-align: center;
					background: #2563eb;
					color: #fff;
					text-decoration: none;
					padding: 8px;
					border-radius: 6px;
					font-size: 13px;
					font-weight: 600;
				}

				/* Main Content Area */
				.ls-doc-main {
					flex-grow: 1;
					display: flex;
					flex-direction: column;
					overflow-y: auto;
					background: #f8fafc;
					position: relative;
				}

				/* Close Button */
				.ls-doc-close {
					position: absolute;
					top: 20px;
					right: 20px;
					width: 32px;
					height: 32px;
					background: #ffffff;
					border: 1px solid #e2e8f0;
					border-radius: 50%;
					display: flex;
					align-items: center;
					justify-content: center;
					cursor: pointer;
					color: #64748b;
					z-index: 10;
					transition: all 0.2s;
				}
				.ls-doc-close:hover {
					background: #f1f5f9;
					color: #0f172a;
				}

				.ls-doc-main-inner {
					padding: 40px;
					max-width: 900px;
					margin: 0 auto;
					width: 100%;
					box-sizing: border-box;
				}

				.ls-doc-header h1 {
					font-size: 32px;
					color: #0f172a;
					margin: 0 0 10px 0;
					font-weight: 800;
					line-height: 1.2;
				}

				.ls-doc-header > p {
					color: #64748b;
					font-size: 15px;
					margin: 0 0 30px 0;
				}

				.ls-doc-grid-4 {
					display: grid;
					grid-template-columns: repeat(2, 1fr);
					gap: 16px;
					margin-bottom: 40px;
				}

				.ls-doc-card {
					background: #ffffff;
					border: 1px solid #e2e8f0;
					border-radius: 10px;
					padding: 20px 15px;
					text-align: center;
					box-shadow: 0 2px 4px rgba(0,0,0,0.02);
					display: flex;
					flex-direction: column;
					align-items: center;
				}

				.ls-doc-card i {
					font-size: 28px;
					width: 28px;
					height: 28px;
					margin-bottom: 12px;
					display: inline-block;
				}

				.ls-doc-card strong {
					display: block;
					color: #0f172a;
					font-size: 15px;
					margin-bottom: 8px;
					white-space: nowrap;
				}

				.ls-doc-card p {
					color: #64748b;
					font-size: 13px;
					margin: 0;
					line-height: 1.5;
				}

				/* Section Content */
				.ls-doc-section {
					display: none;
					background: #ffffff;
					border: 1px solid #e2e8f0;
					border-radius: 12px;
					padding: 30px;
					margin-bottom: 30px;
					box-shadow: 0 4px 6px rgba(0,0,0,0.02);
				}

				.ls-doc-section.active {
					display: block;
				}

				.ls-doc-section h2 {
					font-size: 20px;
					color: #0f172a;
					margin: 0 0 20px 0;
					font-weight: 600;
					display: flex;
					align-items: center;
					gap: 10px;
				}

				.ls-doc-section p {
					line-height: 1.6;
					margin-bottom: 16px;
				}

				.ls-doc-section ul {
					padding-left: 20px;
					margin-bottom: 20px;
				}

				.ls-doc-section li {
					margin-bottom: 10px;
					line-height: 1.5;
				}

				.ls-doc-section pre {
					background: #0f172a;
					color: #f8fafc;
					padding: 20px;
					border-radius: 8px;
					overflow-x: auto;
					margin: 20px 0;
					font-size: 13px;
					line-height: 1.5;
				}

				.ls-doc-section code {
					background: #f1f5f9;
					padding: 3px 6px;
					border-radius: 4px;
					color: #db2777;
					font-size: 13px;
					font-family: Consolas, Monaco, monospace;
				}

				.ls-doc-section pre code {
					background: transparent;
					padding: 0;
					color: inherit;
				}

				.ls-doc-section blockquote {
					background: #eff6ff;
					border-left: 4px solid #3b82f6;
					padding: 15px 20px;
					margin: 20px 0;
					color: #1e3a8a;
					border-radius: 0 8px 8px 0;
				}

				.ls-doc-section blockquote p {
					margin: 0 0 10px 0;
				}
				.ls-doc-section blockquote p:last-child {
					margin: 0;
				}

				/* Footer Cards */
				.ls-doc-footer {
					display: grid;
					grid-template-columns: repeat(3, 1fr);
					gap: 20px;
					margin-top: 20px;
					padding-top: 30px;
				}

				.ls-doc-fcard {
					background: #ffffff;
					border: 1px solid #e2e8f0;
					border-radius: 10px;
					padding: 20px;
					display: flex;
					gap: 16px;
				}

				.ls-doc-fcard i {
					font-size: 24px;
					color: #64748b;
				}

				.ls-doc-fcard-content strong {
					display: block;
					color: #0f172a;
					font-size: 14px;
					margin-bottom: 4px;
				}

				.ls-doc-fcard-content p {
					color: #64748b;
					font-size: 12px;
					margin: 0 0 10px 0;
				}

				.ls-doc-fcard-content a {
					color: #2563eb;
					font-size: 13px;
					font-weight: 600;
					text-decoration: none;
				}
			</style>

			<div class="ls-doc-wrapper">
				<!-- Sidebar -->
				<div class="ls-doc-sidebar">
					<div class="ls-doc-brand">
						<div class="ls-doc-logo"><span class="dashicons dashicons-welcome-learn-more" style="color:white; font-size: 24px; width: 24px; height: 24px;"></span></div>
						<div class="ls-doc-title">
							<strong>Learnshapes</strong>
							<span>LMS Plugin <span class="badge">v1.0.0</span></span>
						</div>
					</div>
					<ul class="ls-doc-nav" id="ls-doc-nav">
						<li><a href="#" class="active" data-target="overview"><i class="dashicons dashicons-admin-home"></i> Overview</a></li>
						<li><a href="#" data-target="features"><i class="dashicons dashicons-admin-generic"></i> Features</a></li>
						<li><a href="#" data-target="installation"><i class="dashicons dashicons-download"></i> Installation</a></li>
						<li><a href="#" data-target="directory"><i class="dashicons dashicons-category"></i> Directory Structure</a></li>
						<li><a href="#" data-target="templates"><i class="dashicons dashicons-admin-appearance"></i> Templates</a></li>
						<li><a href="#" data-target="shortcodes"><i class="dashicons dashicons-shortcode"></i> Shortcodes</a></li>
						<li><a href="#" data-target="developer"><i class="dashicons dashicons-editor-code"></i> Hooks & Filters</a></li>
						<li><a href="#" data-target="requirements"><i class="dashicons dashicons-info"></i> Requirements</a></li>
					</ul>
				</div>

				<!-- Main Content -->
				<div class="ls-doc-main">
					<div class="ls-doc-close" onclick="tb_remove();"><span class="dashicons dashicons-no-alt"></span></div>
					
					<div class="ls-doc-main-inner">
						<div class="ls-doc-header">
							<h1>Learnshapes Documentation</h1>
							<p>Everything you need to know about the Learnshapes LMS Plugin for WordPress.</p>
							
							<div class="ls-doc-grid-4">
								<div class="ls-doc-card">
									<i class="dashicons dashicons-media-document" style="color: #6366f1;"></i>
									<strong>Modern LMS</strong>
									<p>Complete learning management system</p>
								</div>
								<div class="ls-doc-card">
									<i class="dashicons dashicons-groups" style="color: #10b981;"></i>
									<strong>Student & Instructor</strong>
									<p>Powerful dashboards for both users</p>
								</div>
								<div class="ls-doc-card">
									<i class="dashicons dashicons-cart" style="color: #f59e0b;"></i>
									<strong>Monetize Courses</strong>
									<p>WooCommerce & payment support</p>
								</div>
								<div class="ls-doc-card">
									<i class="dashicons dashicons-editor-code" style="color: #3b82f6;"></i>
									<strong>Developer Friendly</strong>
									<p>Hooks, filters and REST API support</p>
								</div>
							</div>
						</div>

						<div class="ls-doc-content-area" id="ls-doc-content-area">
							<div id="ls-sec-overview" class="ls-doc-section active">
								<h2>👋 Overview</h2>
								<?php echo wp_kses_post($overview); ?>
							</div>
							<div id="ls-sec-features" class="ls-doc-section">
								<h2><?php echo esc_html($sec_features['title']); ?></h2>
								<?php echo wp_kses_post($sec_features['body']); ?>
							</div>
							<div id="ls-sec-installation" class="ls-doc-section">
								<h2><?php echo esc_html($sec_installation['title']); ?></h2>
								<?php echo wp_kses_post($sec_installation['body']); ?>
							</div>
							<div id="ls-sec-directory" class="ls-doc-section">
								<h2><?php echo esc_html($sec_directory['title']); ?></h2>
								<?php echo wp_kses_post($sec_directory['body']); ?>
							</div>
							<div id="ls-sec-templates" class="ls-doc-section">
								<h2><?php echo esc_html($sec_templates['title']); ?></h2>
								<?php echo wp_kses_post($sec_templates['body']); ?>
							</div>
							<div id="ls-sec-shortcodes" class="ls-doc-section">
								<h2><?php echo esc_html($sec_shortcodes['title']); ?></h2>
								<?php echo wp_kses_post($sec_shortcodes['body']); ?>
							</div>
							<div id="ls-sec-developer" class="ls-doc-section">
								<h2><?php echo esc_html($sec_developer['title']); ?></h2>
								<?php echo wp_kses_post($sec_developer['body']); ?>
							</div>
							<div id="ls-sec-requirements" class="ls-doc-section">
								<h2><?php echo esc_html($sec_requirements['title']); ?></h2>
								<?php echo wp_kses_post($sec_requirements['body']); ?>
							</div>
						</div>
					</div>
				</div>
			</div>

			<script>
				jQuery(document).ready(function($) {
					$('#ls-doc-nav a').on('click', function(e) {
						e.preventDefault();
						var target = $(this).data('target');
						
						// Update active nav state
						$('#ls-doc-nav a').removeClass('active');
						$(this).addClass('active');

						// Show target section
						$('.ls-doc-section').removeClass('active');
						$('#ls-sec-' + target).addClass('active');

						// Scroll to top of main area
						$('.ls-doc-main').scrollTop(0);
					});
				});
			</script>
		</div>
		<?php
	}

	private static function format_body( $text ) {
		$text = nl2br(trim($text));
		$text = preg_replace('/<\/h3>\s*<br \/>/i', '</h3>', $text);
		$text = preg_replace('/<\/pre>\s*<br \/>/i', '</pre>', $text);
		$text = preg_replace('/<\/li>\s*<br \/>/i', '</li>', $text);
		$text = preg_replace('/<\/blockquote>\s*<br \/>/i', '</blockquote>', $text);
		return $text;
	}
}
