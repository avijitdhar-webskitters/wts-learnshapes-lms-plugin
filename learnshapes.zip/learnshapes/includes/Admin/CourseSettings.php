<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CourseSettings {

    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'add_meta_box' ] );
        add_action( 'save_post_learnshapes_course', [ __CLASS__, 'save_meta_box' ] );
    }



    public static function add_meta_box() {
        add_meta_box(
            'learnshapes_course_settings',
            __( 'Course Settings', 'learnshapes' ),
            [ __CLASS__, 'render_meta_box' ],
            'learnshapes_course',
            'normal',
            'high'
        );
    }

    public static function render_meta_box( $post ) {
        wp_nonce_field( 'learnshapes_course_settings_nonce', 'learnshapes_course_settings_nonce_val' );
        
        $meta = get_post_meta( $post->ID );
        $get_meta = function( $key, $default = '' ) use ( $meta ) {
            return isset( $meta[$key][0] ) ? $meta[$key][0] : $default;
        };

        $certificates = get_posts([
            'post_type'      => 'ls_certificate',
            'posts_per_page' => -1,
            'post_status'    => 'publish'
        ]);
        ?>
        <style>
            .ls-settings-wrap {
                display: flex;
                border: 1px solid #ccd0d4;
                background: #fff;
                margin-top: 15px;
            }
            .ls-settings-tabs {
                width: 220px;
                background: #f9f9f9;
                border-right: 1px solid #ccd0d4;
                margin: 0;
                padding: 0;
            }
            .ls-settings-tabs li {
                margin: 0;
            }
            .ls-settings-tabs li a {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 12px 15px;
                text-decoration: none;
                color: #2271b1;
                border-bottom: 1px solid #eee;
                font-weight: 500;
            }
            .ls-settings-tabs li.active a {
                background: #fff;
                border-right: 1px solid #fff;
                margin-right: -1px;
                color: #1d2327;
                font-weight: 600;
            }
            .ls-settings-content {
                flex: 1;
                padding: 20px 30px;
            }
            .ls-tab-pane {
                display: none;
            }
            .ls-tab-pane.active {
                display: block;
            }
            .ls-form-group {
                display: flex;
                margin-bottom: 25px;
                align-items: flex-start;
            }
            .ls-form-group > label {
                width: 220px;
                font-weight: 600;
                padding-top: 5px;
            }
            .ls-form-field {
                flex: 1;
            }
            .ls-form-field input[type="text"],
            .ls-form-field input[type="number"],
            .ls-form-field select,
            .ls-form-field textarea {
                width: 100%;
                max-width: 400px;
            }
            .ls-form-field textarea {
                min-height: 100px;
            }
            .ls-form-field .description {
                display: block;
                color: #646970;
                margin-top: 6px;
                font-style: normal;
                font-size: 13px;
            }
            .ls-form-field label {
                display: block;
                margin-bottom: 8px;
            }
            .ls-form-field label input[type="radio"],
            .ls-form-field label input[type="checkbox"] {
                margin-right: 8px;
            }
        </style>
        <script>
            jQuery(document).ready(function($) {
                $('.ls-settings-tabs a').on('click', function(e) {
                    e.preventDefault();
                    $('.ls-settings-tabs li').removeClass('active');
                    $(this).parent().addClass('active');
                    var target = $(this).attr('href');
                    $('.ls-tab-pane').removeClass('active');
                    $(target).addClass('active');
                });
            });
        </script>
        
        <div class="ls-settings-wrap">
            <ul class="ls-settings-tabs">
                <li class="active"><a href="#tab-general"><span class="dashicons dashicons-admin-generic"></span> General</a></li>
                <li><a href="#tab-offline"><span class="dashicons dashicons-desktop"></span> Offline Course</a></li>
                <li><a href="#tab-pricing"><span class="dashicons dashicons-cart"></span> Pricing</a></li>
                <li><a href="#tab-extra"><span class="dashicons dashicons-media-text"></span> Extra Information</a></li>
                <li><a href="#tab-assessment"><span class="dashicons dashicons-clipboard"></span> Assessment</a></li>
                <li><a href="#tab-author"><span class="dashicons dashicons-admin-users"></span> Author</a></li>
                <li><a href="#tab-certificates"><span class="dashicons dashicons-awards"></span> Certificates</a></li>
            </ul>

            <div class="ls-settings-content">
                <!-- General Tab -->
                <div id="tab-general" class="ls-tab-pane active">
                    <div class="ls-form-group">
                        <label>Duration</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_duration" value="<?php echo esc_attr( $get_meta( '_ls_duration', '10' ) ); ?>" style="width:100px;">
                            <select name="ls_duration_type" style="width:120px;">
                                <option value="week" <?php selected($get_meta('_ls_duration_type'), 'week'); ?>>Week(s)</option>
                                <option value="day" <?php selected($get_meta('_ls_duration_type'), 'day'); ?>>Day(s)</option>
                                <option value="hour" <?php selected($get_meta('_ls_duration_type'), 'hour'); ?>>Hour(s)</option>
                            </select>
                            <span class="description">Set to 0 for the lifetime access.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Block content</label>
                        <div class="ls-form-field">
                            <label><input type="checkbox" name="ls_block_expire" value="1" <?php checked($get_meta('_ls_block_expire'), '1'); ?>> When the duration expires, the course is blocked.</label>
                            <label><input type="checkbox" name="ls_block_finish" value="1" <?php checked($get_meta('_ls_block_finish'), '1'); ?>> Block the course after the student finished this course.</label>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Allow Repurchase</label>
                        <div class="ls-form-field">
                            <label><input type="checkbox" name="ls_allow_repurchase" value="1" <?php checked($get_meta('_ls_allow_repurchase'), '1'); ?>> Allow users to repurchase this course after it has been finished or blocked.</label>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Repurchase action</label>
                        <div class="ls-form-field">
                            <select name="ls_repurchase_action">
                                <option value="reset" <?php selected($get_meta('_ls_repurchase_action'), 'reset'); ?>>Reset course progress</option>
                                <option value="keep" <?php selected($get_meta('_ls_repurchase_action'), 'keep'); ?>>Keep course progress</option>
                            </select>
                            <span class="description">What happens to student data upon repurchase.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Level</label>
                        <div class="ls-form-field">
                            <select name="ls_level">
                                <option value="all" <?php selected($get_meta('_ls_level'), 'all'); ?>>All levels</option>
                                <option value="beginner" <?php selected($get_meta('_ls_level'), 'beginner'); ?>>Beginner</option>
                                <option value="intermediate" <?php selected($get_meta('_ls_level'), 'intermediate'); ?>>Intermediate</option>
                                <option value="expert" <?php selected($get_meta('_ls_level'), 'expert'); ?>>Expert</option>
                            </select>
                            <span class="description">Choose a difficulty level.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Fake Students Enrolled</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_fake_students" value="<?php echo esc_attr( $get_meta( '_ls_fake_students', '0' ) ); ?>">
                            <span class="description">Fake students enrolled for the course. It only to display, not calculate.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Max student</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_max_students" value="<?php echo esc_attr( $get_meta( '_ls_max_students', '0' ) ); ?>">
                            <span class="description">The maximum number of students that can join a course. Set 0 for unlimited.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Re-take Course</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_retake_course" value="<?php echo esc_attr( $get_meta( '_ls_retake_course', '0' ) ); ?>">
                            <span class="description">The number of times a user can learn again from this course. To disable, set to 0.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Finish button</label>
                        <div class="ls-form-field">
                            <label><input type="checkbox" name="ls_finish_button" value="1" <?php checked($get_meta('_ls_finish_button'), '1'); ?>> Allow showing the Finish button when the student has completed all items.</label>
                        </div>
                    </div>
                </div>

                <!-- Offline Course Tab -->
                <div id="tab-offline" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Enable offline course</label>
                        <div class="ls-form-field">
                            <label><input type="checkbox" name="ls_offline_enable" value="1" <?php checked($get_meta('_ls_offline_enable'), '1'); ?>> When you enable the offline course feature, the system will disable certain online functions.</label>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Lessons</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_offline_lessons" value="<?php echo esc_attr( $get_meta( '_ls_offline_lessons', '10' ) ); ?>">
                            <span class="description">Total offline lessons of the course.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Delivery Type</label>
                        <div class="ls-form-field">
                            <select name="ls_offline_delivery">
                                <option value="private" <?php selected($get_meta('_ls_offline_delivery'), 'private'); ?>>Private 1-1</option>
                                <option value="group" <?php selected($get_meta('_ls_offline_delivery'), 'group'); ?>>Group Training</option>
                                <option value="classroom" <?php selected($get_meta('_ls_offline_delivery'), 'classroom'); ?>>Classroom</option>
                                <option value="workshop" <?php selected($get_meta('_ls_offline_delivery'), 'workshop'); ?>>Workshop</option>
                                <option value="seminar" <?php selected($get_meta('_ls_offline_delivery'), 'seminar'); ?>>Seminar</option>
                                <option value="webinar" <?php selected($get_meta('_ls_offline_delivery'), 'webinar'); ?>>Webinar</option>
                                <option value="zoom" <?php selected($get_meta('_ls_offline_delivery'), 'zoom'); ?>>Zoom Live</option>
                                <option value="google_meet" <?php selected($get_meta('_ls_offline_delivery'), 'google_meet'); ?>>Google Meet</option>
                                <option value="hybrid" <?php selected($get_meta('_ls_offline_delivery'), 'hybrid'); ?>>Hybrid</option>
                                <option value="self_paced" <?php selected($get_meta('_ls_offline_delivery'), 'self_paced'); ?>>Self-Paced Offline</option>
                            </select>
                            <span class="description">How your content is conveyed to students.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Address</label>
                        <div class="ls-form-field">
                            <input type="text" name="ls_offline_address" value="<?php echo esc_attr( $get_meta( '_ls_offline_address', '' ) ); ?>">
                            <span class="description">You can enter the physical address of your class or specify the meeting method (e.g., Zoom).</span>
                        </div>
                    </div>
                </div>

                <!-- Pricing Tab -->
                <div id="tab-pricing" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Regular price</label>
                        <div class="ls-form-field">
                            <input type="text" name="learnshapes_price" value="<?php echo esc_attr( $get_meta( '_learnshapes_price', '' ) ); ?>">
                            <span class="description">Set a regular price. Leave it blank for Free.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Sale price</label>
                        <div class="ls-form-field">
                            <input type="text" name="ls_sale_price" value="<?php echo esc_attr( $get_meta( '_ls_sale_price', '' ) ); ?>">
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Price prefix</label>
                        <div class="ls-form-field">
                            <input type="text" name="ls_price_prefix" value="<?php echo esc_attr( $get_meta( '_ls_price_prefix', '' ) ); ?>">
                            <span class="description">Show additional information placed before the price.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Price Suffix</label>
                        <div class="ls-form-field">
                            <input type="text" name="ls_price_suffix" value="<?php echo esc_attr( $get_meta( '_ls_price_suffix', '' ) ); ?>">
                            <span class="description">Show additional information placed after the price.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>No enrollment requirement</label>
                        <div class="ls-form-field">
                            <label><input type="checkbox" name="ls_no_enrollment" value="1" <?php checked($get_meta('_ls_no_enrollment'), '1'); ?>> Students can see the content of all course items without logging in.</label>
                        </div>
                    </div>
                </div>

                <!-- Extra Information Tab -->
                <div id="tab-extra" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Requirements</label>
                        <div class="ls-form-field">
                            <textarea name="ls_requirements"><?php echo esc_textarea( $get_meta( '_ls_requirements', '' ) ); ?></textarea>
                            <span class="description">One per line.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Target Audience</label>
                        <div class="ls-form-field">
                            <textarea name="ls_target_audience"><?php echo esc_textarea( $get_meta( '_ls_target_audience', '' ) ); ?></textarea>
                            <span class="description">One per line.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Key Features</label>
                        <div class="ls-form-field">
                            <textarea name="ls_key_features"><?php echo esc_textarea( $get_meta( '_ls_key_features', '' ) ); ?></textarea>
                            <span class="description">One per line.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>FAQs</label>
                        <div class="ls-form-field">
                            <textarea name="ls_faqs"><?php echo esc_textarea( $get_meta( '_ls_faqs', '' ) ); ?></textarea>
                            <span class="description">Format: Q: Question | A: Answer (One per line)</span>
                        </div>
                    </div>
                </div>

                <!-- Assessment Tab -->
                <div id="tab-assessment" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Evaluation</label>
                        <div class="ls-form-field">
                            <label><input type="radio" name="ls_evaluation_type" value="lessons" <?php checked($get_meta('_ls_evaluation_type', 'lessons'), 'lessons'); ?>> Evaluate via lessons</label>
                            <label><input type="radio" name="ls_evaluation_type" value="final_quiz" <?php checked($get_meta('_ls_evaluation_type'), 'final_quiz'); ?>> Evaluate via results of the final quiz</label>
                            <label><input type="radio" name="ls_evaluation_type" value="passed_quizzes" <?php checked($get_meta('_ls_evaluation_type'), 'passed_quizzes'); ?>> Evaluate via passed quizzes</label>
                            <label><input type="radio" name="ls_evaluation_type" value="questions" <?php checked($get_meta('_ls_evaluation_type'), 'questions'); ?>> Evaluate via questions</label>
                            <label><input type="radio" name="ls_evaluation_type" value="mark" <?php checked($get_meta('_ls_evaluation_type'), 'mark'); ?>> Evaluate via mark</label>
                            <span class="description" style="color:#d63638;">Note: changing the evaluation type will affect the assessment results of student learning.</span>
                        </div>
                    </div>
                    <div class="ls-form-group">
                        <label>Passing Grade(%)</label>
                        <div class="ls-form-field">
                            <input type="number" name="ls_passing_grade" value="<?php echo esc_attr( $get_meta( '_ls_passing_grade', '80' ) ); ?>">
                            <span class="description">The conditions that must be achieved to finish the course.</span>
                        </div>
                    </div>
                </div>

                <!-- Author Tab -->
                <div id="tab-author" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Course Author</label>
                        <div class="ls-form-field">
                            <?php wp_dropdown_users(['name' => 'post_author_override', 'selected' => $post->post_author]); ?>
                            <span class="description">Change the assigned author of this course.</span>
                        </div>
                    </div>
                </div>

                <!-- Certificates Tab -->
                <div id="tab-certificates" class="ls-tab-pane">
                    <div class="ls-form-group">
                        <label>Completion Certificate</label>
                        <div class="ls-form-field">
                            <select name="ls_assigned_certificate">
                                <option value=""><?php _e('-- No Certificate --', 'learnshapes'); ?></option>
                                <?php foreach ( $certificates as $cert ) : ?>
                                    <option value="<?php echo esc_attr( $cert->ID ); ?>" <?php selected( $get_meta('_ls_assigned_certificate'), $cert->ID ); ?>>
                                        <?php echo esc_html( $cert->post_title ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <span class="description"><?php _e('Awarded to student upon 100% course completion.', 'learnshapes'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function save_meta_box( $post_id ) {
        if ( ! isset( $_POST['learnshapes_course_settings_nonce_val'] ) || ! wp_verify_nonce( $_POST['learnshapes_course_settings_nonce_val'], 'learnshapes_course_settings_nonce' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // Define all fields to save
        $fields = [
            'ls_duration', 'ls_duration_type', 'ls_repurchase_action', 'ls_level',
            'ls_fake_students', 'ls_max_students', 'ls_retake_course', 
            'ls_offline_lessons', 'ls_offline_delivery', 'ls_offline_address',
            'learnshapes_price', 'ls_sale_price', 'ls_price_prefix', 'ls_price_suffix',
            'ls_evaluation_type', 'ls_passing_grade', 'ls_assigned_certificate'
        ];

        // Checkbox fields
        $checkboxes = [
            'ls_block_expire', 'ls_block_finish', 'ls_allow_repurchase', 'ls_finish_button',
            'ls_offline_enable', 'ls_no_enrollment'
        ];

        foreach ( $fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                $val = is_string($_POST[$field]) ? sanitize_text_field( $_POST[$field] ) : $_POST[$field];
                update_post_meta( $post_id, '_' . $field, $val );
            }
        }

        foreach ( $checkboxes as $cb ) {
            $val = isset( $_POST[$cb] ) ? '1' : '0';
            update_post_meta( $post_id, '_' . $cb, $val );
        }

        // Special handling for extra text areas allowing basic HTML or newlines
        foreach (['ls_requirements', 'ls_target_audience', 'ls_key_features', 'ls_faqs'] as $textarea) {
            if ( isset( $_POST[$textarea] ) ) {
                update_post_meta( $post_id, '_' . $textarea, sanitize_textarea_field( $_POST[$textarea] ) );
            }
        }
    }
}
