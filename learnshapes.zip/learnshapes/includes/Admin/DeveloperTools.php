<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DeveloperTools {

	/**
	 * Initialize developer tools page.
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'register_developer_page' ] );
	}

	/**
	 * Register developer page in admin menu.
	 */
	public static function register_developer_page() {
		add_submenu_page(
			'edit.php?post_type=learnshapes_course',
			__( 'Learnshapes Developer Console', 'learnshapes' ),
			__( 'Developer Tools', 'learnshapes' ),
			'manage_options',
			'learnshapes-developer',
			[ __CLASS__, 'render_developer_page' ]
		);
	}

	/**
	 * Render Developer Screen.
	 */
	public static function render_developer_page() {
		?>
		<div class="wrap">
			<hr class="wp-header-end">
			<div class="learnshapes-admin-wrap">
				<div class="learnshapes-header">
					<div class="learnshapes-logo-area">
						<h1 style="margin: 0; padding: 0;"><?php esc_html_e( 'Learnshapes Developer Console', 'learnshapes' ); ?></h1>
					</div>
				</div>

			<div class="learnshapes-settings-tabs-wrapper">
				<ul class="learnshapes-settings-tabs">
					<li class="active" data-tab="hooks"><?php esc_html_e( 'Hooks & Filters Reference', 'learnshapes' ); ?></li>
					<li data-tab="shortcodes"><?php esc_html_e( 'Shortcodes Browser', 'learnshapes' ); ?></li>
					<li data-tab="api"><?php esc_html_e( 'REST API Endpoints', 'learnshapes' ); ?></li>
					<li data-tab="status"><?php esc_html_e( 'System & DB Status', 'learnshapes' ); ?></li>
				</ul>

				<div class="learnshapes-settings-content">
					<!-- Tab: Hooks -->
					<div class="settings-panel active" id="panel-hooks">
						<h2><?php esc_html_e( 'Action & Filter Hook Directory', 'learnshapes' ); ?></h2>
						<p><?php esc_html_e( 'Use these developer-native hooks to extend the Learnshapes LMS from plugins or theme functions.', 'learnshapes' ); ?></p>
						<input type="text" id="hook-search" placeholder="Search hooks..." class="regular-text" style="margin-bottom: 20px;" />

						<div class="hook-directory-list">
							<!-- Hook 1 -->
							<div class="hook-card" data-name="learnshapes_before_course_enroll">
								<div class="hook-card-header">
									<span class="hook-badge action">Action</span>
									<code class="hook-name">learnshapes_before_course_enroll</code>
									<button class="button button-small copy-hook" data-code="add_action( 'learnshapes_before_course_enroll', 'callback', 10, 2 );">Copy Call</button>
								</div>
								<div class="hook-card-body">
									<p><strong>Parameters:</strong> <code>$user_id</code> (int), <code>$course_id</code> (int)</p>
									<p><strong>Fires:</strong> Immediately before a student is enrolled in a course.</p>
								</div>
							</div>

							<!-- Hook 2 -->
							<div class="hook-card" data-name="learnshapes_after_course_complete">
								<div class="hook-card-header">
									<span class="hook-badge action">Action</span>
									<code class="hook-name">learnshapes_after_course_complete</code>
									<button class="button button-small copy-hook" data-code="add_action( 'learnshapes_after_course_complete', 'callback', 10, 2 );">Copy Call</button>
								</div>
								<div class="hook-card-body">
									<p><strong>Parameters:</strong> <code>$user_id</code> (int), <code>$course_id</code> (int)</p>
									<p><strong>Fires:</strong> Immediately after a student completes 100% of a course outline steps.</p>
								</div>
							</div>

							<!-- Hook 3 -->
							<div class="hook-card" data-name="learnshapes_course_price">
								<div class="hook-card-header">
									<span class="hook-badge filter">Filter</span>
									<code class="hook-name">learnshapes_course_price</code>
									<button class="button button-small copy-hook" data-code="add_filter( 'learnshapes_course_price', 'callback', 10, 2 );">Copy Call</button>
								</div>
								<div class="hook-card-body">
									<p><strong>Parameters:</strong> <code>$price</code> (float), <code>$course_id</code> (int)</p>
									<p><strong>Fires:</strong> Before displaying a course price on public grids/details pages.</p>
								</div>
							</div>

							<!-- Hook 4 -->
							<div class="hook-card" data-name="learnshapes_quiz_pass_score">
								<div class="hook-card-header">
									<span class="hook-badge filter">Filter</span>
									<code class="hook-name">learnshapes_quiz_pass_score</code>
									<button class="button button-small copy-hook" data-code="add_filter( 'learnshapes_quiz_pass_score', 'callback', 10, 2 );">Copy Call</button>
								</div>
								<div class="hook-card-body">
									<p><strong>Parameters:</strong> <code>$score</code> (float), <code>$quiz_id</code> (int)</p>
									<p><strong>Fires:</strong> During quiz scoring to determine passing thresholds dynamically.</p>
								</div>
							</div>

							<!-- Hook 5 -->
							<div class="hook-card" data-name="learnshapes_after_quiz_submit">
								<div class="hook-card-header">
									<span class="hook-badge action">Action</span>
									<code class="hook-name">learnshapes_after_quiz_submit</code>
									<button class="button button-small copy-hook" data-code="add_action( 'learnshapes_after_quiz_submit', 'callback', 10, 4 );">Copy Call</button>
								</div>
								<div class="hook-card-body">
									<p><strong>Parameters:</strong> <code>$user_id</code> (int), <code>$quiz_id</code> (int), <code>$attempt_id</code> (int), <code>$status</code> (string)</p>
									<p><strong>Fires:</strong> Right after a student submits a quiz and attempts are processed in DB.</p>
								</div>
							</div>
						</div>
					</div>

					<!-- Tab: Shortcodes -->
					<div class="settings-panel" id="panel-shortcodes">
						<h2><?php esc_html_e( 'Shortcodes Reference & Parameters', 'learnshapes' ); ?></h2>
						<p><?php esc_html_e( 'Add these shortcodes to any standard WordPress page or post to render frontend user experiences.', 'learnshapes' ); ?></p>
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th>Shortcode Name</th>
									<th>Description</th>
									<th>Available Parameters</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><code>[learnshapes_courses]</code></td>
									<td>Displays a grid of all active courses.</td>
									<td><code>limit</code> (int), <code>category</code> (slug), <code>columns</code> (1-4)</td>
									<td><button class="button copy-code" data-code="[learnshapes_courses columns=&quot;3&quot; limit=&quot;9&quot;]">Copy Shortcode</button></td>
								</tr>
								<tr>
									<td><code>[learnshapes_student_dashboard]</code></td>
									<td>Renders the student learning portal portal (my courses, completions, certificate links).</td>
									<td>None</td>
									<td><button class="button copy-code" data-code="[learnshapes_student_dashboard]">Copy Shortcode</button></td>
								</tr>
								<tr>
									<td><code>[learnshapes_instructor_dashboard]</code></td>
									<td>Renders instructor portal containing reports, course lists, and grading pages.</td>
									<td>None</td>
									<td><button class="button copy-code" data-code="[learnshapes_instructor_dashboard]">Copy Shortcode</button></td>
								</tr>
							</tbody>
						</table>
					</div>

					<!-- Tab: API -->
					<div class="settings-panel" id="panel-api">
						<h2><?php esc_html_e( 'REST API Endpoints', 'learnshapes' ); ?></h2>
						<p><?php esc_html_e( 'All data operations can be invoked via the WordPress REST API under namespace `learnshapes/v1`.', 'learnshapes' ); ?></p>
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th>Endpoint URI</th>
									<th>Method</th>
									<th>Authentication</th>
									<th>Purpose</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><code>/wp-json/learnshapes/v1/courses</code></td>
									<td>GET</td>
									<td>None (Public)</td>
									<td>Retrieves list of courses and structural layouts.</td>
								</tr>
								<tr>
									<td><code>/wp-json/learnshapes/v1/course/builder</code></td>
									<td>POST</td>
									<td>WP Nonce (Instructors/Admins)</td>
									<td>Saves frontend course builder outline.</td>
								</tr>
								<tr>
									<td><code>/wp-json/learnshapes/v1/progress/mark</code></td>
									<td>POST</td>
									<td>WP Nonce (Logged-in Student)</td>
									<td>Logs completion for course steps.</td>
								</tr>
								<tr>
									<td><code>/wp-json/learnshapes/v1/quiz/submit</code></td>
									<td>POST</td>
									<td>WP Nonce (Logged-in Student)</td>
									<td>Checks and registers quiz attempts.</td>
								</tr>
							</tbody>
						</table>
					</div>

					<!-- Tab: Status -->
					<div class="settings-panel" id="panel-status">
						<h2><?php esc_html_e( 'System & Custom Tables Diagnostics', 'learnshapes' ); ?></h2>
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th>Check Component</th>
									<th>Required Version / Status</th>
									<th>Current Server State</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>PHP Version</td>
									<td>PHP 8.1+</td>
									<td><code><?php echo esc_html( PHP_VERSION ); ?></code> (OK)</td>
								</tr>
								<tr>
									<td>Database Version</td>
									<td>1.0.0</td>
									<td><code><?php echo esc_html( get_option( 'learnshapes_db_version', 'Not Found' ) ); ?></code></td>
								</tr>
								<tr>
									<td>Custom Table Verification</td>
									<td>All tables created</td>
									<td>
										<?php
										global $wpdb;
										$tables = [
											'learnshapes_enrollments',
											'learnshapes_progress',
											'learnshapes_quiz_attempts',
											'learnshapes_quiz_answers',
											'ls_assignment_submissions',
											'ls_certificates',
											'learnshapes_orders',
											'learnshapes_activity_logs',
											'learnshapes_notifications'
										];
										$all_verified = true;
										foreach ( $tables as $table ) {
											$t_name = $wpdb->prefix . $table;
											if ( $wpdb->get_var( "SHOW TABLES LIKE '$t_name'" ) !== $t_name ) {
												$all_verified = false;
												echo '<span class="text-danger">Missing: ' . esc_html( $t_name ) . '</span><br>';
											}
										}
										if ( $all_verified ) {
											echo '<span class="text-success" style="color: green; font-weight: bold;">Verified (9/9 tables active)</span>';
										}
										?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			</div>
		</div>

		<script>
			jQuery(document).ready(function($) {
				// Manage tabs.
				$('.learnshapes-settings-tabs li').on('click', function() {
					let tab = $(this).data('tab');
					$('.learnshapes-settings-tabs li').removeClass('active');
					$(this).addClass('active');

					$('.settings-panel').removeClass('active');
					$('#panel-' + tab).addClass('active');
				});

				// Copy code logic.
				$('.copy-hook, .copy-code').on('click', function() {
					let code = $(this).data('code');
					let button = $(this);
					let orig = button.text();

					navigator.clipboard.writeText(code).then(() => {
						button.text('Copied!');
						setTimeout(() => button.text(orig), 1500);
					});
				});

				// Search hooks directory.
				$('#hook-search').on('keyup', function() {
					let query = $(this).val().toLowerCase();
					$('.hook-card').each(function() {
						let name = $(this).data('name').toLowerCase();
						if (name.indexOf(query) > -1) {
							$(this).show();
						} else {
							$(this).hide();
						}
					});
				});
			});
		</script>
		<?php
	}
}
