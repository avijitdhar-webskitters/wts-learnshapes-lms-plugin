<?php
namespace Learnshapes\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dashboard {

	/**
	 * Initialize admin dashboard.
	 */
	public static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'register_admin_pages' ] );
	}

	/**
	 * Register submenu pages under Course CPT.
	 */
	public static function register_admin_pages() {
		$parent_slug = 'edit.php?post_type=learnshapes_course';

		// 1. Dashboard Submenu
		add_submenu_page(
			$parent_slug,
			__( 'Learnshapes Dashboard', 'learnshapes' ),
			__( 'Dashboard', 'learnshapes' ),
			'manage_options',
			'learnshapes-dashboard',
			[ __CLASS__, 'render_dashboard' ]
		);

		// 2. Assignments Submenu (Force visibility)
		add_submenu_page(
			$parent_slug,
			__( 'Assignments', 'learnshapes' ),
			__( 'Assignments', 'learnshapes' ),
			'edit_posts',
			'edit.php?post_type=ls_assignment'
		);

		// 3. Certificates Submenu (Force visibility)
		add_submenu_page(
			$parent_slug,
			__( 'Certificates', 'learnshapes' ),
			__( 'Certificates', 'learnshapes' ),
			'edit_posts',
			'edit.php?post_type=ls_certificate'
		);



		// 5. Reports Submenu
		add_submenu_page(
			$parent_slug,
			__( 'Learnshapes Reports', 'learnshapes' ),
			__( 'Reports', 'learnshapes' ),
			'learnshapes_view_reports',
			'learnshapes-reports',
			[ __CLASS__, 'render_reports' ]
		);
	}



	/**
	 * Render Admin Dashboard.
	 */
	public static function render_dashboard() {
		global $wpdb;

		// Fetch database metrics
		$students_count = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}learnshapes_enrollments" ) ?: 0;
		$courses_count = wp_count_posts( 'learnshapes_course' )->publish ?: 0;
		$completions_count = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}learnshapes_enrollments WHERE status = 'completed'" ) ?: 0;
		$revenue = $wpdb->get_var( "SELECT SUM(amount) FROM {$wpdb->prefix}learnshapes_orders WHERE status = 'completed'" ) ?: 0;

		$recent_logs = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}learnshapes_activity_logs ORDER BY created_at DESC LIMIT 5" );
		?>
		<div class="wrap">
			<hr class="wp-header-end">
			<div class="learnshapes-admin-wrap">
				<div class="learnshapes-header">
					<div class="learnshapes-logo-area">
						<h1 style="margin: 0; padding: 0;"><?php esc_html_e( 'Learnshapes Dashboard', 'learnshapes' ); ?></h1>
					</div>
				<div class="learnshapes-header-actions">
					<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=learnshapes_course' ) ); ?>" class="button button-primary button-hero">
						<span class="dashicons dashicons-plus-alt"></span> <?php esc_html_e( 'Create New Course', 'learnshapes' ); ?>
					</a>
				</div>
			</div>

			<!-- Onboarding / Quick Start Wizard Card -->
			<div class="learnshapes-card learnshapes-onboarding-card">
				<div class="onboarding-text">
					<h2><?php esc_html_e( 'Welcome to Learnshapes LMS! 🚀', 'learnshapes' ); ?></h2>
					<p><?php esc_html_e( 'Learnshapes is active and ready to deliver beautiful learning portals. Set up core settings, configure payments, and customize your templates in minutes.', 'learnshapes' ); ?></p>
				</div>
				<div class="onboarding-actions">
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=learnshapes_course&page=learnshapes-settings' ) ); ?>" class="button button-secondary">
						<span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'Configure Settings', 'learnshapes' ); ?>
					</a>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=learnshapes_course&page=learnshapes-developer' ) ); ?>" class="button button-secondary">
						<span class="dashicons dashicons-editor-code"></span> <?php esc_html_e( 'Developer Console', 'learnshapes' ); ?>
					</a>
				</div>
			</div>

			<!-- Stats Grid -->
			<div class="learnshapes-stats-grid">
				<div class="stats-card">
					<div class="stats-icon text-blue">
						<span class="dashicons dashicons-welcome-learn-more"></span>
					</div>
					<div class="stats-info">
						<h3><?php echo esc_html( $courses_count ); ?></h3>
						<p><?php esc_html_e( 'Active Courses', 'learnshapes' ); ?></p>
					</div>
				</div>
				<div class="stats-card">
					<div class="stats-icon text-green">
						<span class="dashicons dashicons-groups"></span>
					</div>
					<div class="stats-info">
						<h3><?php echo esc_html( $students_count ); ?></h3>
						<p><?php esc_html_e( 'Enrolled Students', 'learnshapes' ); ?></p>
					</div>
				</div>
				<div class="stats-card">
					<div class="stats-icon text-purple">
						<span class="dashicons dashicons-awards"></span>
					</div>
					<div class="stats-info">
						<h3><?php echo esc_html( $completions_count ); ?></h3>
						<p><?php esc_html_e( 'Course Completions', 'learnshapes' ); ?></p>
					</div>
				</div>
				<div class="stats-card">
					<div class="stats-icon text-gold">
						<span class="dashicons dashicons-chart-area"></span>
					</div>
					<div class="stats-info">
						<h3>$<?php echo esc_html( number_format( $revenue, 2 ) ); ?></h3>
						<p><?php esc_html_e( 'Total Revenue', 'learnshapes' ); ?></p>
					</div>
				</div>
			</div>

			<div class="learnshapes-two-col">
				<!-- Quick Actions -->
				<div class="learnshapes-card col-6">
					<h2><?php esc_html_e( 'Quick Actions', 'learnshapes' ); ?></h2>
					<ul class="quick-actions-list">
						<li>
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=learnshapes_lesson' ) ); ?>">
								<span class="dashicons dashicons-welcome-write-blog"></span> <?php esc_html_e( 'Create Lesson', 'learnshapes' ); ?>
							</a>
						</li>
						<li>
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=learnshapes_quiz' ) ); ?>">
								<span class="dashicons dashicons-welcome-edit-page"></span> <?php esc_html_e( 'Build a Quiz', 'learnshapes' ); ?>
							</a>
						</li>
						<li>
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=ls_assignment' ) ); ?>">
								<span class="dashicons dashicons-portfolio"></span> <?php esc_html_e( 'Add Assignment', 'learnshapes' ); ?>
							</a>
						</li>
						<li>
							<a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=ls_certificate' ) ); ?>">
								<span class="dashicons dashicons-awards"></span> <?php esc_html_e( 'Design Certificate', 'learnshapes' ); ?>
							</a>
						</li>
					</ul>
				</div>

				<!-- Activity Log -->
				<div class="learnshapes-card col-6">
					<h2><?php esc_html_e( 'Recent System Activity', 'learnshapes' ); ?></h2>
					<?php if ( empty( $recent_logs ) ) : ?>
						<p class="empty-text"><?php esc_html_e( 'No recent events recorded.', 'learnshapes' ); ?></p>
					<?php else : ?>
						<ul class="activity-log-list">
							<?php foreach ( $recent_logs as $log ) :
								$data = json_decode( $log->event_data, true );
								$user = get_userdata( $log->user_id );
								$username = $user ? $user->display_name : __( 'System', 'learnshapes' );
								?>
								<li>
									<span class="log-time"><?php echo esc_html( date( 'M d, H:i', strtotime( $log->created_at ) ) ); ?></span>
									<span class="log-desc">
										<strong><?php echo esc_html( $username ); ?></strong> 
										<?php
										if ( $log->event_type === 'course_enrolled' ) {
											printf( esc_html__( 'enrolled in course %s', 'learnshapes' ), '<em>' . esc_html( get_the_title( $data['course_id'] ) ) . '</em>' );
										} else {
											echo esc_html( $log->event_type );
										}
										?>
									</span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}

	public static function render_reports() {
		?>
		<style>
			/* Reset WP Admin specific conflicts */
			#wpcontent { background: #f3f4f6; }
			.lms-analytics-wrap {
				padding: 20px;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
				color: #111827;
			}
			.lms-header-row {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 24px;
			}
			.lms-header-row h1 {
				margin: 0;
				font-size: 24px;
				font-weight: 600;
				color: #111827;
			}
			.lms-date-picker {
				background: #ffffff;
				border: 1px solid #e5e7eb;
				border-radius: 6px;
				padding: 8px 16px;
				font-size: 14px;
				color: #4b5563;
				display: flex;
				align-items: center;
				gap: 8px;
				box-shadow: 0 1px 2px rgba(0,0,0,0.05);
			}
			.lms-stats-grid {
				display: grid;
				grid-template-columns: repeat(5, 1fr);
				gap: 20px;
				margin-bottom: 24px;
			}
			.lms-stat-card {
				background: #ffffff;
				border: 1px solid #f3f4f6;
				border-radius: 12px;
				padding: 20px;
				box-shadow: 0 1px 3px rgba(0,0,0,0.05);
				display: flex;
				flex-direction: column;
				justify-content: space-between;
			}
			.stat-top {
				display: flex;
				align-items: center;
				gap: 16px;
				margin-bottom: 20px;
			}
			.icon-circle {
				width: 48px;
				height: 48px;
				border-radius: 50%;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			.stat-info h4 {
				margin: 0 0 4px 0;
				font-size: 13px;
				font-weight: 500;
				color: #6b7280;
			}
			.stat-info .num {
				margin: 0;
				font-size: 24px;
				font-weight: 600;
				color: #111827;
			}
			.stat-bottom {
				font-size: 13px;
				color: #6b7280;
			}
			.stat-bottom strong {
				color: #111827;
			}
			
			.lms-charts-row {
				display: grid;
				grid-template-columns: 2fr 1fr;
				gap: 20px;
				margin-bottom: 24px;
			}
			.lms-panel {
				background: #ffffff;
				border: 1px solid #f3f4f6;
				border-radius: 12px;
				padding: 24px;
				box-shadow: 0 1px 3px rgba(0,0,0,0.05);
			}
			.panel-header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				margin-bottom: 24px;
			}
			.panel-header h3 {
				margin: 0;
				font-size: 16px;
				font-weight: 600;
			}
			
			.lms-tables-row {
				display: grid;
				grid-template-columns: 1fr 1fr;
				gap: 20px;
			}
			.lms-table {
				width: 100%;
				border-collapse: collapse;
			}
			.lms-table th {
				text-align: left;
				padding-bottom: 12px;
				border-bottom: 1px solid #e5e7eb;
				color: #111827;
				font-weight: 600;
				font-size: 14px;
			}
			.lms-table td {
				padding: 16px 0;
				border-bottom: 1px solid #f3f4f6;
				color: #4b5563;
				font-size: 14px;
			}
			.lms-table tr:last-child td {
				border-bottom: none;
			}
			.view-all-link {
				display: inline-block;
				margin-top: 16px;
				color: #2563eb;
				font-weight: 600;
				font-size: 14px;
				text-decoration: none;
			}
			.view-all-link:hover {
				text-decoration: underline;
			}
		</style>
		<div class="lms-analytics-wrap" id="learnshapes-reports-app">
			<div class="lms-header-row">
				<h1>LMS Analytics</h1>
				<div class="lms-date-picker">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
					May 30, 2025 - Jun 5, 2025
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
				</div>
			</div>
			<p>Loading analytics data...</p>
		</div>

		<script>
			jQuery(document).ready(function($) {
				$.ajax({
					url: learnshapesAdmin.resturl + '/reports',
					method: 'GET',
					beforeSend: function(xhr) {
						xhr.setRequestHeader('X-WP-Nonce', learnshapesAdmin.restNonce);
					},
					success: function(response) {
						if (response.success) {
							let stats = response.stats;
							let status = response.course_status;
							let chart = response.chart;
							let popular = response.popular;
							let recent = response.recent;

							let totalCourses = status.published + status.draft + status.pending;
							let pPub = totalCourses ? Math.round((status.published / totalCourses)*100) : 0;
							let pDra = totalCourses ? Math.round((status.draft / totalCourses)*100) : 0;
							let pPen = totalCourses ? Math.round((status.pending / totalCourses)*100) : 0;

							let html = `
								<div class="lms-header-row">
									<h1>LMS Analytics</h1>
									<div class="lms-date-picker">
										<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
										May 30, 2025 - Jun 5, 2025
										<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
									</div>
								</div>

								<div class="lms-stats-grid">
									<!-- Total Students -->
									<div class="lms-stat-card">
										<div class="stat-top">
											<div class="icon-circle" style="background:#f3e8ff; color:#a855f7;">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
											</div>
											<div class="stat-info">
												<h4>Total Students</h4>
												<div class="num">${stats.students}</div>
											</div>
										</div>
										<div class="stat-bottom"><strong>0%</strong> vs last 7 days</div>
									</div>
									
									<!-- Courses Published -->
									<div class="lms-stat-card">
										<div class="stat-top">
											<div class="icon-circle" style="background:#e0f2fe; color:#38bdf8;">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>
											</div>
											<div class="stat-info">
												<h4>Courses Published</h4>
												<div class="num">${stats.courses}</div>
											</div>
										</div>
										<div class="stat-bottom"><strong>0%</strong> vs last 7 days</div>
									</div>
									
									<!-- Completions -->
									<div class="lms-stat-card">
										<div class="stat-top">
											<div class="icon-circle" style="background:#dcfce7; color:#22c55e;">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
											</div>
											<div class="stat-info">
												<h4>Course Completions</h4>
												<div class="num">${stats.completions}</div>
											</div>
										</div>
										<div class="stat-bottom"><strong>0%</strong> vs last 7 days</div>
									</div>

									<!-- Revenue -->
									<div class="lms-stat-card">
										<div class="stat-top">
											<div class="icon-circle" style="background:#ffedd5; color:#f97316;">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
											</div>
											<div class="stat-info">
												<h4>Revenue Earned</h4>
												<div class="num">$${stats.revenue.toFixed(2)}</div>
											</div>
										</div>
										<div class="stat-bottom"><strong>0%</strong> vs last 7 days</div>
									</div>

									<!-- New Students -->
									<div class="lms-stat-card">
										<div class="stat-top">
											<div class="icon-circle" style="background:#fce7f3; color:#ec4899;">
												<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
											</div>
											<div class="stat-info">
												<h4>New Students</h4>
												<div class="num">${stats.new_students}</div>
											</div>
										</div>
										<div class="stat-bottom"><strong>0%</strong> vs last 7 days</div>
									</div>
								</div>

								<div class="lms-charts-row">
									<div class="lms-panel">
										<div class="panel-header">
											<h3>Enrollment Trend (Past 7 Days)</h3>
											<select style="border:1px solid #e5e7eb; border-radius:6px; padding:4px 8px; color:#4b5563;"><option>Daily</option></select>
										</div>
										<div style="position:relative; height:250px; width:100%;">
											<canvas id="ls-trend-chart"></canvas>
										</div>
									</div>

									<div class="lms-panel">
										<div class="panel-header">
											<h3>Course Status</h3>
										</div>
										<div style="display:flex; align-items:center; gap:30px; margin-top:20px;">
											<div style="width:140px; height:140px; position:relative;">
												<canvas id="ls-donut-chart"></canvas>
											</div>
											<div class="status-legend" style="flex:1;">
												<div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:13px; color:#4b5563;">
													<span><span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#a855f7; margin-right:8px;"></span>Published</span>
													<span>${status.published} (${pPub}%)</span>
												</div>
												<div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:13px; color:#4b5563;">
													<span><span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#fb923c; margin-right:8px;"></span>Draft</span>
													<span>${status.draft} (${pDra}%)</span>
												</div>
												<div style="display:flex; justify-content:space-between; font-size:13px; color:#4b5563;">
													<span><span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#38bdf8; margin-right:8px;"></span>Pending Review</span>
													<span>${status.pending} (${pPen}%)</span>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="lms-tables-row">
									<div class="lms-panel">
										<h3 style="margin:0 0 20px 0; font-size:16px;">Popular Courses</h3>
										<table class="lms-table">
											<thead><tr><th>Course</th><th style="text-align:right;">Enrollments</th></tr></thead>
											<tbody>
												${popular.length === 0 ? '<tr><td colspan="2">No courses found.</td></tr>' : popular.map((p, i) => `
													<tr>
														<td>${i+1}. ${p.title}</td>
														<td style="text-align:right;">${p.count}</td>
													</tr>
												`).join('')}
											</tbody>
										</table>
										<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=learnshapes_course' ) ); ?>" class="view-all-link">View All Courses</a>
									</div>

									<div class="lms-panel">
										<h3 style="margin:0 0 20px 0; font-size:16px;">Recent Enrollments</h3>
										<table class="lms-table">
											<thead><tr><th>Student</th><th>Course</th><th style="text-align:right;">Date</th></tr></thead>
											<tbody>
												${recent.length === 0 ? '<tr><td colspan="3" style="text-align:center; padding:30px 0;">No enrollments found.</td></tr>' : recent.map((r) => `
													<tr>
														<td>${r.student}</td>
														<td>${r.course}</td>
														<td style="text-align:right;">${r.date}</td>
													</tr>
												`).join('')}
											</tbody>
										</table>
										<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=learnshapes_course&page=learnshapes-reports' ) ); ?>" class="view-all-link">View All Enrollments</a>
									</div>
								</div>
							`;
							$('#learnshapes-reports-app').html(html);

							if (typeof Chart !== 'undefined') {
								// Line Chart
								const ctxLine = document.getElementById('ls-trend-chart').getContext('2d');
								new Chart(ctxLine, {
									type: 'line',
									data: {
										labels: chart.map(c => c.date),
										datasets: [{
											label: 'Enrollments',
											data: chart.map(c => c.count),
											borderColor: '#a855f7',
											backgroundColor: 'transparent',
											pointBackgroundColor: '#a855f7',
											pointBorderColor: '#fff',
											pointBorderWidth: 2,
											pointRadius: 4,
											borderWidth: 2,
											fill: false,
											tension: 0
										}]
									},
									options: {
										responsive: true,
										maintainAspectRatio: false,
										plugins: { legend: { display: false } },
										scales: {
											y: {
												beginAtZero: true,
												ticks: { stepSize: 1, color: '#9ca3af' },
												grid: { color: '#f3f4f6', drawBorder: false }
											},
											x: {
												ticks: { color: '#9ca3af' },
												grid: { display: false, drawBorder: false }
											}
										}
									}
								});

								// Donut Chart
								const ctxDonut = document.getElementById('ls-donut-chart').getContext('2d');
								new Chart(ctxDonut, {
									type: 'doughnut',
									data: {
										labels: ['Published', 'Draft', 'Pending Review'],
										datasets: [{
											data: [status.published || 1, status.draft || 0, status.pending || 0],
											backgroundColor: ['#a855f7', '#fb923c', '#38bdf8'],
											borderWidth: 0,
											hoverOffset: 4
										}]
									},
									options: {
										responsive: true,
										maintainAspectRatio: false,
										cutout: '70%',
										plugins: { legend: { display: false } }
									}
								});
							}
						}
					},
					error: function() {
						$('#learnshapes-reports-app').html('<p style="color:red;">Failed to fetch analytics data.</p>');
					}
				});
			});
		</script>
		<?php
	}
}
