<?php
namespace Learnshapes\Shortcodes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Learnshapes\Core\Router;

class Shortcodes {

	/**
	 * Initialize shortcodes.
	 */
	public static function init() {
		add_shortcode( 'learnshapes_courses', [ __CLASS__, 'render_courses_grid' ] );
		add_shortcode( 'learnshapes_my_courses', [ __CLASS__, 'render_my_courses' ] );
		add_shortcode( 'learnshapes_student_dashboard', [ __CLASS__, 'render_student_dashboard' ] );
		add_shortcode( 'learnshapes_instructor_dashboard', [ __CLASS__, 'render_instructor_dashboard' ] );
		add_shortcode( 'learnshapes_checkout', [ __CLASS__, 'render_checkout' ] );
		add_shortcode( 'learnshapes_become_teacher', [ __CLASS__, 'render_become_teacher' ] );
	}

	/**
	 * Render [learnshapes_courses]
	 */
	public static function render_courses_grid( $atts ) {
		$parsed_atts = shortcode_atts( [
			'columns'  => '3',
			'limit'    => '9',
			'category' => '',
		], $atts );

		ob_start();
		// Load template and pass attributes
		$template_file = Router::locate_template( 'course/courses-grid.php' );
		if ( file_exists( $template_file ) ) {
			// Extract variables for the template view
			$columns  = intval( $parsed_atts['columns'] );
			$limit    = intval( $parsed_atts['limit'] );
			$category = sanitize_text_field( $parsed_atts['category'] );
			include $template_file;
		}
		return ob_get_clean();
	}

	/**
	 * Render [learnshapes_student_dashboard]
	 */
	public static function render_student_dashboard() {
		if ( ! is_user_logged_in() ) {
			ob_start();
			$login_template = Router::locate_template( 'dashboard/login-form.php' );
			if ( file_exists( $login_template ) ) {
				include $login_template;
			}
			return ob_get_clean();
		}

		ob_start();
		$dashboard_template = Router::locate_template( 'dashboard/student-dashboard.php' );
		if ( file_exists( $dashboard_template ) ) {
			include $dashboard_template;
		}
		return ob_get_clean();
	}

    /**
     * Render [learnshapes_my_courses] – Student My Courses page.
     */
    public static function render_my_courses() {
        $my_courses_template = Router::locate_template( 'dashboard/student-my-courses.php' );
        if ( file_exists( $my_courses_template ) ) {
            ob_start();
            include $my_courses_template;
            return ob_get_clean();
        }
        return '';
    }

	/**
	 * Render [learnshapes_instructor_dashboard]
	 */
	public static function render_instructor_dashboard() {
		if ( ! current_user_can( 'learnshapes_create_courses' ) && ! current_user_can( 'manage_options' ) ) {
			return '<p class="error-msg">' . esc_html__( 'You do not have permission to view the instructor dashboard.', 'learnshapes' ) . '</p>';
		}

		ob_start();
		$instructor_template = Router::locate_template( 'dashboard/instructor-dashboard.php' );
		if ( file_exists( $instructor_template ) ) {
			include $instructor_template;
		}
		return ob_get_clean();
	}

	public static function render_checkout() {
		ob_start();
		$checkout_template = Router::locate_template( 'checkout/checkout.php' );
		if ( file_exists( $checkout_template ) ) {
			include $checkout_template;
		} else {
			echo '<p>Checkout template not found.</p>';
		}
		return ob_get_clean();
	}

	/**
	 * Render [learnshapes_become_teacher]
	 */
	public static function render_become_teacher() {
		ob_start();
		$template = Router::locate_template( 'dashboard/become-teacher.php' );
		if ( file_exists( $template ) ) {
			include $template;
		}
		return ob_get_clean();
	}
}
