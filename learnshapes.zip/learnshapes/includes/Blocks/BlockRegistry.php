<?php
namespace Learnshapes\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Registers Gutenberg blocks for Learnshapes.
 */
class BlockRegistry {
    /**
     * Hook initialization.
     */
    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_blocks' ] );
    }

    /**
     * Register all blocks.
     */
    public static function register_blocks() {
        // Course Grid block – server‑side rendered.
        register_block_type( 'learnshapes/course-grid', [
            'render_callback' => [ __CLASS__, 'render_course_grid' ],
            'attributes'      => [
                'columns' => [
                    'type'    => 'integer',
                    'default' => 3,
                ],
                'limit' => [
                    'type'    => 'integer',
                    'default' => 9,
                ],
                'category' => [
                    'type'    => 'string',
                    'default' => '',
                ],
            ],
        ] );
    }

    /**
     * Render callback for the Course Grid block.
     *
     * @param array $attributes Block attributes.
     * @return string Rendered HTML.
     */
    public static function render_course_grid( $attributes ) {
        $columns  = isset( $attributes['columns'] ) ? intval( $attributes['columns'] ) : 3;
        $limit    = isset( $attributes['limit'] ) ? intval( $attributes['limit'] ) : 9;
        $category = isset( $attributes['category'] ) ? sanitize_text_field( $attributes['category'] ) : '';

        $shortcode = sprintf(
            '[learnshapes_courses columns="%d" limit="%d" category="%s"]',
            $columns,
            $limit,
            esc_attr( $category )
        );

        return do_shortcode( $shortcode );
    }
}
?>
