<?php
namespace Learnshapes\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Schema {

	/**
	 * Activate plugin - Create custom tables.
	 */
	public static function activate() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Table Names
		$table_enrollments = $wpdb->prefix . 'learnshapes_enrollments';
		$table_progress    = $wpdb->prefix . 'learnshapes_progress';
		$table_attempts    = $wpdb->prefix . 'learnshapes_quiz_attempts';
		$table_answers     = $wpdb->prefix . 'learnshapes_quiz_answers';
		$table_submissions = $wpdb->prefix . 'ls_assignment_submissions';
		$table_certs       = $wpdb->prefix . 'ls_certificates';
		$table_orders      = $wpdb->prefix . 'learnshapes_orders';
		$table_logs        = $wpdb->prefix . 'learnshapes_activity_logs';
		$table_notifs      = $wpdb->prefix . 'learnshapes_notifications';

		$sql = [];

		// 1. Enrollments Table
		$sql[] = "CREATE TABLE $table_enrollments (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			status varchar(50) NOT NULL DEFAULT 'active',
			progress_percent decimal(5,2) NOT NULL DEFAULT '0.00',
			enrolled_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			completed_at datetime DEFAULT NULL,
			expires_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY user_course (user_id,course_id)
		) $charset_collate;";

		// 2. Progress Table
		$sql[] = "CREATE TABLE $table_progress (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			item_id bigint(20) unsigned NOT NULL,
			item_type varchar(50) NOT NULL,
			status varchar(50) NOT NULL DEFAULT 'completed',
			completed_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_course_item (user_id,course_id,item_id)
		) $charset_collate;";

		// 3. Quiz Attempts Table
		$sql[] = "CREATE TABLE $table_attempts (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			quiz_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			score decimal(5,2) NOT NULL DEFAULT '0.00',
			passing_score decimal(5,2) NOT NULL DEFAULT '0.00',
			status varchar(50) NOT NULL DEFAULT 'failed',
			started_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			submitted_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY user_quiz (user_id,quiz_id)
		) $charset_collate;";

		// 4. Quiz Answers Table
		$sql[] = "CREATE TABLE $table_answers (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			attempt_id bigint(20) unsigned NOT NULL,
			question_id bigint(20) unsigned NOT NULL,
			answer_data longtext NOT NULL,
			is_correct tinyint(1) NOT NULL DEFAULT '0',
			points_earned decimal(5,2) NOT NULL DEFAULT '0.00',
			PRIMARY KEY  (id),
			KEY attempt_question (attempt_id,question_id)
		) $charset_collate;";

		// 5. Assignment Submissions Table
		$sql[] = "CREATE TABLE $table_submissions (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			assignment_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			submission_text longtext DEFAULT NULL,
			file_url varchar(255) DEFAULT NULL,
			status varchar(50) NOT NULL DEFAULT 'pending',
			grade varchar(50) DEFAULT NULL,
			feedback longtext DEFAULT NULL,
			graded_by bigint(20) unsigned DEFAULT NULL,
			submitted_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			graded_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY user_assignment (user_id,assignment_id)
		) $charset_collate;";

		// 6. Certificates Table
		$sql[] = "CREATE TABLE $table_certs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			certificate_code varchar(100) NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			template_id bigint(20) unsigned DEFAULT NULL,
			issued_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			verification_key varchar(100) NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY certificate_code (certificate_code),
			KEY user_course (user_id,course_id)
		) $charset_collate;";

		// 7. Orders Table
		$sql[] = "CREATE TABLE $table_orders (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT '0',
			course_id bigint(20) unsigned NOT NULL,
			amount decimal(10,2) NOT NULL DEFAULT '0.00',
			currency varchar(10) NOT NULL DEFAULT 'USD',
			payment_gateway varchar(50) NOT NULL,
			transaction_id varchar(100) DEFAULT NULL,
			order_key varchar(100) DEFAULT NULL,
			billing_email varchar(200) DEFAULT NULL,
			status varchar(50) NOT NULL DEFAULT 'pending',
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			updated_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY user_course (user_id,course_id),
			KEY order_key (order_key)
		) $charset_collate;";

		// 8. Activity Logs Table
		$sql[] = "CREATE TABLE $table_logs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			event_type varchar(100) NOT NULL,
			event_data longtext DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_event (user_id,event_type)
		) $charset_collate;";

		// 9. Notifications Table
		$sql[] = "CREATE TABLE $table_notifs (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			title varchar(255) NOT NULL,
			message text NOT NULL,
			is_read tinyint(1) NOT NULL DEFAULT '0',
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id),
			KEY user_notifications (user_id,is_read)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( $sql as $query ) {
			dbDelta( $query );
		}

		add_option( 'learnshapes_db_version', '1.0.0' );

		// Create sample course, lessons, and quiz
		self::create_sample_data();

		// Create default pages
		self::create_default_pages();

		// Flush rewrite rules on activation
		flush_rewrite_rules();
	}

	/**
	 * Run any pending schema upgrades (safe to run on every load).
	 * Uses ADD COLUMN IF NOT EXISTS so it is idempotent.
	 */
	public static function upgrade() {
		global $wpdb;

		$table = $wpdb->prefix . 'learnshapes_orders';

		// Check if table exists at all first.
		$table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( ! $table_exists ) {
			self::activate();
			return;
		}

		// Add order_key column if missing.
		$col = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}` LIKE 'order_key'" );
		if ( empty( $col ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `order_key` varchar(100) DEFAULT NULL" );
			$wpdb->query( "ALTER TABLE `{$table}` ADD INDEX `order_key` (`order_key`)" );
		}

		// Add billing_email column if missing.
		$col = $wpdb->get_results( "SHOW COLUMNS FROM `{$table}` LIKE 'billing_email'" );
		if ( empty( $col ) ) {
			$wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `billing_email` varchar(200) DEFAULT NULL" );
		}

		// Allow guest orders (user_id = 0).
		$col_def = $wpdb->get_row( "SHOW COLUMNS FROM `{$table}` LIKE 'user_id'", ARRAY_A );
		if ( $col_def && strpos( $col_def['Default'] ?? '', '0' ) === false ) {
			$wpdb->query( "ALTER TABLE `{$table}` MODIFY COLUMN `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'" );
		}

		// Ensure default pages exist on every load in case they were deleted or plugin was just updated
		self::create_default_pages();

		update_option( 'learnshapes_db_version', '1.0.1' );
	}

	/**
	 * Create default LMS pages on install.
	 * Creates all required pages automatically; only "terms" and "logout_redirect"
	 * are left for the admin to configure manually since they are site-specific.
	 */
	public static function create_default_pages() {
		$settings = get_option( 'learnshapes_settings', [] );
		if ( ! isset( $settings['pages'] ) ) {
			$settings['pages'] = [];
		}

		// Pages to auto-create on activation.
		// Keys: settings key => [ title, shortcode/content ].
		$pages_to_create = [
			'all_courses'       => [ 'title' => 'All Courses',          'content' => '[learnshapes_courses]' ],
			'instructors'       => [ 'title' => 'Instructors',           'content' => '[learnshapes_instructor_dashboard]' ],
			'single_instructor' => [ 'title' => 'Instructor Profile',    'content' => '[learnshapes_instructor_dashboard]' ],
			'profile'           => [ 'title' => 'My Profile',            'content' => '[learnshapes_student_dashboard]' ],
			'checkout'          => [ 'title' => 'Checkout',              'content' => '[learnshapes_checkout]' ],
			'become_teacher'    => [ 'title' => 'Become an Instructor',  'content' => '[learnshapes_become_teacher]' ],
			// 'terms'          => intentionally skipped – site-specific
			// 'logout_redirect'=> intentionally skipped – site-specific
		];

		foreach ( $pages_to_create as $key => $page_data ) {
			// Skip if we already have a valid page set.
			if ( ! empty( $settings['pages'][ $key ] ) && get_post( $settings['pages'][ $key ] ) ) {
				continue;
			}
			$page_id = wp_insert_post( [
				'post_title'   => $page_data['title'],
				'post_content' => $page_data['content'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_author'  => get_current_user_id() ?: 1,
			] );
			if ( $page_id && ! is_wp_error( $page_id ) ) {
				$settings['pages'][ $key ] = $page_id;
				update_post_meta( $page_id, '_learnshapes_is_default_page', $key );
			}
		}

		update_option( 'learnshapes_settings', $settings );
	}

	/**
	 * Seed two full demo courses with curriculum (lessons, topics, quizzes, assignments).
	 * Idempotent — skips if demo courses already exist.
	 */
	private static function create_sample_data() {
		// Guard: skip if already seeded.
		$existing = get_posts( [
			'post_type'   => 'learnshapes_course',
			'post_status' => 'any',
			'numberposts' => 1,
			'meta_key'    => '_learnshapes_is_demo',
			'meta_value'  => '1',
		] );
		if ( ! empty( $existing ) ) {
			return;
		}

		// Ensure taxonomy terms exist.
		$beginner_term     = wp_insert_term( 'Beginner',     'learnshapes_difficulty' );
		$intermediate_term = wp_insert_term( 'Intermediate', 'learnshapes_difficulty' );
		$dev_cat           = wp_insert_term( 'Development',  'learnshapes_category' );
		$design_cat        = wp_insert_term( 'Design',       'learnshapes_category' );

		$beginner_slug     = is_wp_error( $beginner_term )     ? 'beginner'     : get_term( $beginner_term['term_id'], 'learnshapes_difficulty' )->slug;
		$intermediate_slug = is_wp_error( $intermediate_term ) ? 'intermediate' : get_term( $intermediate_term['term_id'], 'learnshapes_difficulty' )->slug;

		// ── Course 1: Web Design ──────────────────────────────────────────────
		$c1 = wp_insert_post( [
			'post_title'   => 'Modern Web Design from Scratch',
			'post_content' => '<p>Learn the complete foundation of modern web design in this hands-on course. From understanding visual hierarchy to building polished UI components, you will gain the skills to design beautiful, accessible, and responsive websites from the ground up.</p><p>This course is ideal for beginners who want to enter the field of web design with a strong, practical foundation.</p>',
			'post_excerpt' => 'Master the fundamentals of UI/UX, colour systems, typography, and responsive layouts to build beautiful modern websites.',
			'post_status'  => 'publish',
			'post_type'    => 'learnshapes_course',
			'post_author'  => 1,
		] );
		if ( is_wp_error( $c1 ) || ! $c1 ) return;

		update_post_meta( $c1, '_learnshapes_price',        '29.99' );
		update_post_meta( $c1, '_learnshapes_is_demo',      '1' );
		update_post_meta( $c1, '_learnshapes_duration',     '6 hours' );
		update_post_meta( $c1, '_learnshapes_students',     '1240' );
		update_post_meta( $c1, '_learnshapes_rating',       '4.8' );
		update_post_meta( $c1, '_learnshapes_rating_count', '98' );
		wp_set_object_terms( $c1, $intermediate_slug, 'learnshapes_difficulty' );
		if ( ! is_wp_error( $design_cat ) ) {
			wp_set_object_terms( $c1, (int) $design_cat['term_id'], 'learnshapes_category' );
		}

		// Section 1 lessons
		$c1_l1 = self::make_lesson( 'Introduction to Visual Design Principles', '<p>Visual design is the foundation of every great website. In this lesson we explore the core principles that guide how users perceive and interact with digital interfaces.</p><h3>What you will learn</h3><ul><li>The 7 principles of visual design</li><li>How proximity and alignment create structure</li><li>The role of contrast in guiding attention</li></ul><p>By the end of this lesson you will be able to identify these principles in any design you encounter online.</p>', $c1 );
		$c1_t1 = self::make_topic( 'Colour Theory for the Web', '<p>Colour is one of the most powerful tools a designer has. This topic dives into the colour wheel, complementary palettes, and how to use HSL colour values to build a flexible, brand-consistent design system.</p><h3>Key concepts</h3><ul><li>RGB vs HSL colour models</li><li>Creating primary, secondary, and accent palettes</li><li>Accessibility contrast requirements (WCAG 2.1)</li></ul>', $c1 );
		$c1_t2 = self::make_topic( 'Typography Systems and Scales', '<p>Great typography is invisible — it guides the reader without drawing attention to itself. This topic covers how to choose typefaces, build a modular type scale, and pair fonts effectively.</p><ul><li>Choosing between serif, sans-serif, and display fonts</li><li>Building a type scale (8pt grid system)</li><li>Line height, letter spacing, and readability</li></ul>', $c1 );

		// Section 2 lessons
		$c1_l2 = self::make_lesson( 'Responsive Design and Grid Systems', '<p>Modern websites must work beautifully on every device. This lesson covers CSS Grid, Flexbox, and how to plan a responsive layout from mobile-first.</p><ul><li>12-column grid systems</li><li>Breakpoints and media queries</li><li>Fluid typography with clamp()</li></ul>', $c1 );
		$c1_t3 = self::make_topic( 'Building UI Components', '<p>Components are the building blocks of modern interfaces. In this topic you will design and build cards, buttons, navigation bars, and form elements that are both beautiful and functional.</p>', $c1 );

		// Quiz
		$c1_q1 = self::make_quiz( 'Design Principles Assessment', '<p>Test your knowledge of visual design principles, colour theory, and typography.</p>', $c1, [
			[ 'type' => 'single_choice', 'question' => 'What WCAG 2.1 contrast ratio is required for normal body text?', 'options' => [ '3:1', '4.5:1', '7:1', '2:1' ], 'correct' => '1', 'points' => 1 ],
			[ 'type' => 'true_false',    'question' => 'HSL stands for Hue, Saturation, Lightness.', 'options' => [ 'True', 'False' ], 'correct' => '0', 'points' => 1 ],
			[ 'type' => 'single_choice', 'question' => 'Which CSS property creates a 12-column layout grid?', 'options' => [ 'display:flex', 'display:grid', 'float:left', 'position:relative' ], 'correct' => '1', 'points' => 1 ],
			[ 'type' => 'fill_in_the_blank', 'question' => 'The CSS function used for fluid typography is ___().', 'correct' => 'clamp', 'points' => 1 ],
		] );

		// Assignment
		$c1_a1 = self::make_assignment( 'Design a Landing Page Hero Section', '<p>Using Figma or any design tool of your choice, create a complete landing page hero section. Your design must include:</p><ul><li>A clear headline and subheadline</li><li>A primary call-to-action button</li><li>A hero image or illustration</li><li>Consistent use of a colour palette</li></ul><p>Submit a link to your Figma file or export a PNG/PDF.</p>', $c1 );

		// Course structure
		update_post_meta( $c1, '_learnshapes_course_structure', [
			[ 'title' => 'Design Foundations',    'items' => [
				[ 'id' => $c1_l1, 'type' => 'lesson', 'title' => 'Introduction to Visual Design Principles' ],
				[ 'id' => $c1_t1, 'type' => 'topic',  'title' => 'Colour Theory for the Web' ],
				[ 'id' => $c1_t2, 'type' => 'topic',  'title' => 'Typography Systems and Scales' ],
			] ],
			[ 'title' => 'Building for the Web',  'items' => [
				[ 'id' => $c1_l2, 'type' => 'lesson', 'title' => 'Responsive Design and Grid Systems' ],
				[ 'id' => $c1_t3, 'type' => 'topic',  'title' => 'Building UI Components' ],
			] ],
			[ 'title' => 'Assessment & Project',  'items' => [
				[ 'id' => $c1_q1, 'type' => 'quiz',       'title' => 'Design Principles Assessment' ],
				[ 'id' => $c1_a1, 'type' => 'assignment',  'title' => 'Design a Landing Page Hero Section' ],
			] ],
		] );


		// ── Course 2: WordPress Development ──────────────────────────────────
		$c2 = wp_insert_post( [
			'post_title'   => 'WordPress Development from Zero to Hero',
			'post_content' => '<p>This comprehensive course takes you from a complete beginner to a confident WordPress developer. You will learn how to build custom themes, create plugins, work with the REST API, and deploy production-ready WordPress sites.</p><p>Whether you want to build client sites, launch a freelance career, or create your own digital products, this course gives you everything you need.</p>',
			'post_excerpt' => 'Build professional WordPress themes and plugins from scratch. Learn the REST API, custom post types, and deployment workflows.',
			'post_status'  => 'publish',
			'post_type'    => 'learnshapes_course',
			'post_author'  => 1,
		] );
		if ( is_wp_error( $c2 ) || ! $c2 ) return;

		update_post_meta( $c2, '_learnshapes_price',        '49.99' );
		update_post_meta( $c2, '_learnshapes_is_demo',      '1' );
		update_post_meta( $c2, '_learnshapes_duration',     '12 hours' );
		update_post_meta( $c2, '_learnshapes_students',     '3450' );
		update_post_meta( $c2, '_learnshapes_rating',       '4.9' );
		update_post_meta( $c2, '_learnshapes_rating_count', '210' );
		wp_set_object_terms( $c2, $beginner_slug, 'learnshapes_difficulty' );
		if ( ! is_wp_error( $dev_cat ) ) {
			wp_set_object_terms( $c2, (int) $dev_cat['term_id'], 'learnshapes_category' );
		}

		// Section 1
		$c2_l1 = self::make_lesson( 'WordPress Architecture & the Loop', '<p>Before you write a single line of code it is important to understand how WordPress is structured. This lesson covers the template hierarchy, the WordPress Loop, and how themes and plugins fit together.</p><h3>Topics covered</h3><ul><li>The WordPress template hierarchy</li><li>Understanding the WP_Query object</li><li>Using the Loop to display posts</li><li>Hooks: actions and filters explained</li></ul>', $c2 );
		$c2_t1 = self::make_topic( 'Setting Up a Local Development Environment', '<p>Professional WordPress development starts with a solid local setup. We will install Local by Flywheel, configure Xdebug, and connect VS Code for a seamless development workflow.</p><ul><li>Installing Local WP</li><li>Configuring PHP Xdebug</li><li>Using VS Code with PHP Intelephense</li></ul>', $c2 );
		$c2_t2 = self::make_topic( 'Creating a Custom WordPress Theme', '<p>Learn how to build a WordPress theme from an empty folder. We start with style.css and index.php and build up to a fully structured theme with header, footer, sidebar, and page templates.</p>', $c2 );

		// Section 2
		$c2_l2 = self::make_lesson( 'Custom Post Types & Taxonomies', '<p>One of WordPress\'s most powerful features is the ability to create custom data structures. In this lesson you will register Custom Post Types (CPTs) and Taxonomies using both code and the register_post_type() API.</p>', $c2 );
		$c2_t3 = self::make_topic( 'Building a WordPress Plugin from Scratch', '<p>Plugins extend WordPress functionality. In this topic you will create a plugin with its own admin page, AJAX handlers, custom database table, and front-end shortcode — following WordPress coding standards throughout.</p>', $c2 );
		$c2_t4 = self::make_topic( 'Using the WordPress REST API', '<p>The REST API opens WordPress to modern JavaScript applications. You will register custom endpoints, add authentication, and consume the API from a React front-end.</p>', $c2 );

		// Section 3
		$c2_l3 = self::make_lesson( 'Performance, Security & Deployment', '<p>A fast, secure website is essential for user experience and SEO. This lesson covers caching strategies, security hardening, and deploying WordPress to a production server using Git and GitHub Actions.</p>', $c2 );

		// Quiz
		$c2_q1 = self::make_quiz( 'WordPress Development Quiz', '<p>Test your understanding of WordPress architecture, hooks, and the REST API.</p>', $c2, [
			[ 'type' => 'single_choice',    'question' => 'Which function registers a Custom Post Type?', 'options' => [ 'add_post_type()', 'register_post_type()', 'create_cpt()', 'wp_register_post_type()' ], 'correct' => '1', 'points' => 1 ],
			[ 'type' => 'true_false',       'question' => 'WordPress actions allow you to modify data before it is returned.', 'options' => [ 'True', 'False' ], 'correct' => '1', 'points' => 1 ],
			[ 'type' => 'single_choice',    'question' => 'What is the default WordPress REST API namespace?', 'options' => [ 'wp/v1', 'wp/v2', 'wordpress/v2', 'api/v1' ], 'correct' => '1', 'points' => 1 ],
			[ 'type' => 'fill_in_the_blank','question' => 'The WordPress function to safely output HTML attribute values is esc_____().', 'correct' => 'attr', 'points' => 1 ],
		] );

		// Assignment
		$c2_a1 = self::make_assignment( 'Build a Custom Portfolio Plugin', '<p>Create a WordPress plugin called "My Portfolio" that:</p><ul><li>Registers a "Portfolio" Custom Post Type with a "Portfolio Category" taxonomy</li><li>Provides a [portfolio] shortcode that displays a responsive grid of portfolio items</li><li>Includes an admin settings page with at least two configurable options</li><li>Follows WordPress coding standards (phpcs with WordPress ruleset)</li></ul><p>Submit a link to your GitHub repository.</p>', $c2 );

		update_post_meta( $c2, '_learnshapes_course_structure', [
			[ 'title' => 'WordPress Foundations', 'items' => [
				[ 'id' => $c2_t1, 'type' => 'topic',  'title' => 'Setting Up a Local Development Environment' ],
				[ 'id' => $c2_l1, 'type' => 'lesson', 'title' => 'WordPress Architecture & the Loop' ],
				[ 'id' => $c2_t2, 'type' => 'topic',  'title' => 'Creating a Custom WordPress Theme' ],
			] ],
			[ 'title' => 'Extending WordPress',   'items' => [
				[ 'id' => $c2_l2, 'type' => 'lesson', 'title' => 'Custom Post Types & Taxonomies' ],
				[ 'id' => $c2_t3, 'type' => 'topic',  'title' => 'Building a WordPress Plugin from Scratch' ],
				[ 'id' => $c2_t4, 'type' => 'topic',  'title' => 'Using the WordPress REST API' ],
			] ],
			[ 'title' => 'Production-Ready',      'items' => [
				[ 'id' => $c2_l3, 'type' => 'lesson',     'title' => 'Performance, Security & Deployment' ],
				[ 'id' => $c2_q1, 'type' => 'quiz',       'title' => 'WordPress Development Quiz' ],
				[ 'id' => $c2_a1, 'type' => 'assignment',  'title' => 'Build a Custom Portfolio Plugin' ],
			] ],
		] );
	}

	/** Helper: insert a lesson and link it to a course. */
	private static function make_lesson( string $title, string $content, int $course_id ): int {
		$id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
			'post_type'    => 'learnshapes_lesson',
			'post_author'  => 1,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_learnshapes_parent_course', $course_id );
		}
		return (int) ( is_wp_error( $id ) ? 0 : $id );
	}

	/** Helper: insert a topic and link it to a course. */
	private static function make_topic( string $title, string $content, int $course_id ): int {
		$id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
			'post_type'    => 'learnshapes_topic',
			'post_author'  => 1,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_learnshapes_parent_course', $course_id );
		}
		return (int) ( is_wp_error( $id ) ? 0 : $id );
	}

	/** Helper: insert a quiz with questions and link to course. */
	private static function make_quiz( string $title, string $content, int $course_id, array $questions ): int {
		$id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
			'post_type'    => 'learnshapes_quiz',
			'post_author'  => 1,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_learnshapes_parent_course', $course_id );
			update_post_meta( $id, '_learnshapes_questions',     $questions );
			update_post_meta( $id, '_learnshapes_passing_score', '70' );
		}
		return (int) ( is_wp_error( $id ) ? 0 : $id );
	}

	/** Helper: insert an assignment and link to course. */
	private static function make_assignment( string $title, string $content, int $course_id ): int {
		$id = wp_insert_post( [
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
			'post_type'    => 'ls_assignment',
			'post_author'  => 1,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_learnshapes_parent_course', $course_id );
		}
		return (int) ( is_wp_error( $id ) ? 0 : $id );
	}


	/**
	 * Deactivate plugin.
	 */
	public static function deactivate() {
		flush_rewrite_rules();
	}

	/**
	 * Drop custom tables (uninstall cleanup).
	 */
	public static function drop_tables() {
		global $wpdb;

		// 1. Delete generated default pages.
		$settings = get_option( 'learnshapes_settings', [] );
		if ( ! empty( $settings['pages'] ) && is_array( $settings['pages'] ) ) {
			foreach ( $settings['pages'] as $key => $page_id ) {
				if ( $page_id ) {
					// Force delete page (skip trash)
					wp_delete_post( $page_id, true );
				}
			}
		}

		// 2. Drop tables.
		$tables = [
			'learnshapes_enrollments',
			'learnshapes_progress',
			'learnshapes_quiz_attempts',
			'learnshapes_quiz_answers',
			'ls_assignment_submissions',
			'ls_certificates',
			'learnshapes_orders',
			'learnshapes_activity_logs',
			'learnshapes_notifications'
		];

		foreach ( $tables as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . $table );
		}

		delete_option( 'learnshapes_db_version' );
		delete_option( 'learnshapes_settings' );
	}
}
