<?php
namespace Learnshapes\Emails;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Mailer {

	/**
	 * Initialize Mailer actions.
	 */
	public static function init() {
		add_action( 'learnshapes_after_course_enroll', [ __CLASS__, 'send_enrollment_email' ], 10, 2 );
		add_action( 'ls_certificate_issued',           [ __CLASS__, 'send_certificate_email' ], 10, 3 );
		add_action( 'ls_assignment_graded',            [ __CLASS__, 'send_assignment_graded_email' ], 10, 4 );
		// Fires from Order::create() → do_action('learnshapes_order_created', $id)
		add_action( 'learnshapes_order_created',       [ __CLASS__, 'send_order_admin_notification' ], 10, 1 );
		// Fires from Order::update_status() → do_action("learnshapes_order_completed", $id, $this)
		add_action( 'learnshapes_order_completed',     [ __CLASS__, 'send_order_receipt' ], 10, 2 );
	}

	/**
	 * Send course enrollment email.
	 */
	public static function send_enrollment_email( $user_id, $course_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		$course_title = get_the_title( $course_id );
		$subject = sprintf( __( 'Welcome to your course: %s', 'learnshapes' ), $course_title );

		$body = self::get_email_template(
			__( 'Enrollment Confirmed!', 'learnshapes' ),
			sprintf( __( 'Hi %s,<br><br>You have successfully enrolled in <strong>%s</strong>. Log in to your student dashboard to resume learning.', 'learnshapes' ), esc_html( $user->display_name ), esc_html( $course_title ) ),
			get_permalink( $course_id ),
			__( 'Start Learning Now', 'learnshapes' )
		);

		self::send( $user->user_email, $subject, $body );
	}

	/**
	 * Send Certificate Issued email.
	 */
	public static function send_certificate_email( $user_id, $course_id, $code ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		$course_title = get_the_title( $course_id );
		$subject = sprintf( __( 'Congratulations! You earned a certificate for: %s', 'learnshapes' ), $course_title );

		$body = self::get_email_template(
			__( 'Certificate Issued! 🎓', 'learnshapes' ),
			sprintf( __( 'Hi %s,<br><br>Outstanding work! You have finished all steps of the course <strong>%s</strong> and a certificate has been generated for you.<br><br>Certificate Code: <strong>%s</strong>', 'learnshapes' ), esc_html( $user->display_name ), esc_html( $course_title ), esc_html( $code ) ),
			home_url( '/student-dashboard' ),
			__( 'View Earned Certificates', 'learnshapes' )
		);

		self::send( $user->user_email, $subject, $body );
	}

	/**
	 * Send Assignment Graded email.
	 */
	public static function send_assignment_graded_email( $user_id, $assignment_id, $grade, $feedback ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		$assignment_title = get_the_title( $assignment_id );
		$subject = sprintf( __( 'Your assignment "%s" has been graded', 'learnshapes' ), $assignment_title );

		$body = self::get_email_template(
			__( 'Assignment Graded', 'learnshapes' ),
			sprintf( __( 'Hi %s,<br><br>Your submission for <strong>%s</strong> has been reviewed and graded.<br><br><strong>Grade:</strong> %s<br><strong>Feedback:</strong> %s', 'learnshapes' ), esc_html( $user->display_name ), esc_html( $assignment_title ), esc_html( $grade ), wp_kses_post( wpautop( $feedback ) ) ),
			get_permalink( $assignment_id ),
			__( 'View Assignment', 'learnshapes' )
		);

		self::send( $user->user_email, $subject, $body );
	}

	public static function send_order_admin_notification( $order_id ) {
		$settings    = get_option( 'learnshapes_settings', [] );
		$admin_email = $settings['email']['from_email'] ?? get_option( 'admin_email' );

		$order = new \Learnshapes\Payments\Order( $order_id );

		$user_id   = $order->get_user_id();
		$user      = $user_id ? get_userdata( $user_id ) : null;
		$user_name = $user ? $user->display_name : __( 'Guest', 'learnshapes' );
		$user_email = $user ? $user->user_email : ( $order->get_data()['billing_email'] ?? '—' );

		$course_title = get_the_title( $order->get_course_id() );
		$amount       = number_format( $order->get_amount(), 2 ) . ' ' . $order->get_currency();

		$subject = sprintf( __( '[%s] New Order #%s Received', 'learnshapes' ), get_bloginfo( 'name' ), $order->get_order_number() );

		$message = sprintf(
			__( 'A new order has been placed.<br><br><strong>Order:</strong> %s<br><strong>Student:</strong> %s (%s)<br><strong>Course:</strong> %s<br><strong>Amount:</strong> %s<br><strong>Gateway:</strong> %s', 'learnshapes' ),
			esc_html( $order->get_order_number() ),
			esc_html( $user_name ),
			esc_html( $user_email ),
			esc_html( $course_title ),
			esc_html( $amount ),
			esc_html( ucfirst( $order->get_payment_gateway() ) )
		);

		$orders_url = admin_url( 'edit.php?post_type=learnshapes_course&page=learnshapes-orders' );
		$body = self::get_email_template(
			__( 'New Order Received 🛒', 'learnshapes' ),
			$message,
			$orders_url,
			__( 'View Orders', 'learnshapes' )
		);

		self::send( $admin_email, $subject, $body );
	}

	public static function send_order_receipt( $order_id, $order ) {
		$user = get_userdata( $order->get_user_id() );
		if ( ! $user ) return;

		$subject = sprintf( __( 'Your Order Receipt (#%d)', 'learnshapes' ), $order_id );
		$body = self::get_email_template(
			__( 'Order Completed', 'learnshapes' ),
			sprintf( __( 'Hi %s,<br><br>Your order (#%d) is complete and you have been successfully enrolled in the course.', 'learnshapes' ), esc_html( $user->display_name ), $order_id ),
			get_permalink( $order->get_course_id() ),
			__( 'Start Course', 'learnshapes' )
		);

		self::send( $user->user_email, $subject, $body );
	}

	/**
	 * Send custom HTML mail.
	 */
	private static function send( $to, $subject, $body ) {
		$settings = get_option( 'learnshapes_settings', [] );
		$from_name = isset( $settings['email']['from_name'] ) ? $settings['email']['from_name'] : get_bloginfo( 'name' );
		$from_email = isset( $settings['email']['from_email'] ) ? $settings['email']['from_email'] : get_option( 'admin_email' );

		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			"From: $from_name <$from_email>"
		];

		wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * Responsive HTML Email template skeleton wrapper.
	 */
	private static function get_email_template( $title, $message, $btn_url = '', $btn_text = '' ) {
		$settings = get_option( 'learnshapes_settings', [] );
		$accent = isset( $settings['appearance']['primary_color'] ) ? $settings['appearance']['primary_color'] : '#6366f1';

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8">
			<style>
				body { font-family: sans-serif; background: #f8fafc; color: #0f172a; margin: 0; padding: 20px; }
				.email-card { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; border: 1px solid #e2e8f0; padding: 30px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); }
				.email-header { font-size: 20px; font-weight: bold; margin-bottom: 20px; color: <?php echo esc_attr( $accent ); ?>; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }
				.email-body { font-size: 14px; line-height: 1.6; margin-bottom: 30px; }
				.email-btn { display: inline-block; background: <?php echo esc_attr( $accent ); ?>; color: #ffffff !important; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 14px; }
				.email-footer { font-size: 11px; color: #64748b; margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 15px; text-align: center; }
			</style>
		</head>
		<body>
			<div class="email-card">
				<div class="email-header"><?php echo esc_html( $title ); ?></div>
				<div class="email-body">
					<?php echo $message; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<?php if ( ! empty( $btn_url ) ) : ?>
					<div style="text-align: center;">
						<a href="<?php echo esc_url( $btn_url ); ?>" class="email-btn"><?php echo esc_html( $btn_text ); ?></a>
					</div>
				<?php endif; ?>
				<div class="email-footer">
					<?php printf( esc_html__( 'Sent automatically by %s LMS.', 'learnshapes' ), esc_html( get_bloginfo( 'name' ) ) ); ?>
				</div>
			</div>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
