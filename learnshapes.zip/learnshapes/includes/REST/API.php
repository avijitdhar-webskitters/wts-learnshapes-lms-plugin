<?php
namespace Learnshapes\REST;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class API {

	/**
	 * Initialize REST API routes.
	 */
	public static function init() {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	/**
	 * Register REST routes.
	 */
	public static function register_routes() {
		$namespace = 'learnshapes/v1';

		// Get course outline or course list.
		register_rest_route( $namespace, '/courses', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'get_courses' ],
			'permission_callback' => '__return_true',
		] );

		// Save Course Builder Structure.
		register_rest_route( $namespace, '/course/builder', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'save_course_builder' ],
			'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
		] );

		// Enroll User in a Course.
		register_rest_route( $namespace, '/course/enroll', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'enroll_user' ],
			'permission_callback' => [ __CLASS__, 'check_student_permission' ],
		] );

		// Mark Lesson/Topic Progress.
		register_rest_route( $namespace, '/progress/mark', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'mark_progress' ],
			'permission_callback' => [ __CLASS__, 'check_student_permission' ],
		] );

		// Submit Quiz.
		register_rest_route( $namespace, '/quiz/submit', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'submit_quiz' ],
			'permission_callback' => [ __CLASS__, 'check_student_permission' ],
		] );

		// Submit Assignment.
		register_rest_route( $namespace, '/assignment/submit', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'submit_assignment' ],
			'permission_callback' => [ __CLASS__, 'check_student_permission' ],
		] );

		// Grade Assignment.
		register_rest_route( $namespace, '/assignment/grade', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'grade_assignment' ],
			'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
		] );

		// Get Reports / Dashboard stats.
		register_rest_route( $namespace, '/reports', [
			'methods'             => 'GET',
			'callback'            => [ __CLASS__, 'get_reports' ],
			'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
		] );

		// Save Settings.
		register_rest_route( $namespace, '/settings', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'save_settings' ],
			'permission_callback' => [ __CLASS__, 'check_admin_permission' ],
		] );
	}

	/**
	 * Permission check for Students.
	 */
	public static function check_student_permission() {
		return is_user_logged_in();
	}

	/**
	 * Permission check for Instructors.
	 */
	public static function check_instructor_permission() {
		return current_user_can( 'learnshapes_create_courses' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Permission check for Admins.
	 */
	public static function check_admin_permission() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Get courses list.
	 */
	public static function get_courses( $request ) {
		$courses = get_posts( [
			'post_type'      => 'learnshapes_course',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		] );

		$data = [];
		foreach ( $courses as $course ) {
			$price = get_post_meta( $course->ID, '_learnshapes_price', true );
			$data[] = [
				'id'          => $course->ID,
				'title'       => $course->post_title,
				'excerpt'     => $course->post_excerpt,
				'price'       => $price ? floatval( $price ) : 0,
				'thumbnail'   => get_the_post_thumbnail_url( $course->ID, 'medium' ),
				'structure'   => get_post_meta( $course->ID, '_learnshapes_course_structure', true ),
			];
		}

		return new \WP_REST_Response( [ 'success' => true, 'courses' => $data ], 200 );
	}

	/**
	 * Save course builder structure.
	 */
	public static function save_course_builder( $request ) {
		$course_id = intval( $request->get_param( 'course_id' ) );
		$structure = $request->get_param( 'structure' ); // Array representing the outline.

		if ( ! $course_id || ! get_post( $course_id ) ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid Course ID.' ], 400 );
		}

		// Update structures & map relationships (so lessons know their parent course)
		update_post_meta( $course_id, '_learnshapes_course_structure', $structure );

		// Loop through the structure to update parent references on lessons/quizzes/assignments
		if ( is_array( $structure ) ) {
			foreach ( $structure as $section ) {
				if ( ! isset( $section['items'] ) || ! is_array( $section['items'] ) ) {
					continue;
				}
				foreach ( $section['items'] as $item ) {
					$item_id = intval( $item['id'] );
					if ( $item_id ) {
						update_post_meta( $item_id, '_learnshapes_parent_course', $course_id );
					}
				}
			}
		}

		// Fire builder action hook
		do_action( 'learnshapes_course_builder_saved', $course_id, $structure );

		return new \WP_REST_Response( [ 'success' => true, 'message' => 'Course structure saved.' ], 200 );
	}

	/**
	 * Enroll a user manually or through front action.
	 */
	public static function enroll_user( $request ) {
		global $wpdb;

		$user_id = get_current_user_id();
		$course_id = intval( $request->get_param( 'course_id' ) );

		if ( ! $course_id || ! get_post( $course_id ) ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid course' ], 400 );
		}

		// Fire developer action hook.
		do_action( 'learnshapes_before_course_enroll', $user_id, $course_id );

		$table = $wpdb->prefix . 'learnshapes_enrollments';
		$wpdb->insert( $table, [
			'user_id'          => $user_id,
			'course_id'        => $course_id,
			'status'           => 'active',
			'progress_percent' => 0.00,
			'enrolled_at'      => current_time( 'mysql' ),
		] );

		// Log activity.
		$wpdb->insert( $wpdb->prefix . 'learnshapes_activity_logs', [
			'user_id'    => $user_id,
			'event_type' => 'course_enrolled',
			'event_data' => json_encode( [ 'course_id' => $course_id ] ),
			'created_at' => current_time( 'mysql' ),
		] );

		do_action( 'learnshapes_after_course_enroll', $user_id, $course_id );

		return new \WP_REST_Response( [ 'success' => true, 'message' => 'Enrolled successfully.' ], 200 );
	}

	/**
	 * Mark Lesson/Topic progress.
	 */
	public static function mark_progress( $request ) {
		global $wpdb;

		$user_id = get_current_user_id();
		$course_id = intval( $request->get_param( 'course_id' ) );
		$item_id = intval( $request->get_param( 'item_id' ) );
		$item_type = sanitize_text_field( $request->get_param( 'item_type' ) );
		$status = sanitize_text_field( $request->get_param( 'status' ) ); // 'completed'

		$table_progress = $wpdb->prefix . 'learnshapes_progress';

		// Verify enrollment.
		$enrollment = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id = %d AND course_id = %d",
			$user_id, $course_id
		) );

		if ( ! $enrollment ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'User not enrolled.' ], 403 );
		}

		if ( $status === 'completed' ) {
			// Check if already completed.
			$exists = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM $table_progress WHERE user_id = %d AND course_id = %d AND item_id = %d",
				$user_id, $course_id, $item_id
			) );

			if ( ! $exists ) {
				$wpdb->insert( $table_progress, [
					'user_id'      => $user_id,
					'course_id'    => $course_id,
					'item_id'      => $item_id,
					'item_type'    => $item_type,
					'status'       => 'completed',
					'completed_at' => current_time( 'mysql' ),
				] );

				do_action( "learnshapes_after_{$item_type}_complete", $user_id, $item_id, $course_id );
			}
		} else {
			// Mark incomplete / remove.
			$wpdb->delete( $table_progress, [
				'user_id'   => $user_id,
				'course_id' => $course_id,
				'item_id'   => $item_id,
			] );
		}

		// Calculate total progress.
		$structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
		$total_steps = 0;
		if ( is_array( $structure ) ) {
			foreach ( $structure as $section ) {
				if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
					$total_steps += count( $section['items'] );
				}
			}
		}

		$completed_steps = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_progress WHERE user_id = %d AND course_id = %d AND status = 'completed'",
			$user_id, $course_id
		) );

		$progress_percent = 0;
		if ( $total_steps > 0 ) {
			$progress_percent = ( $completed_steps / $total_steps ) * 100;
		}

		// Update enrollment.
		$wpdb->update(
			$wpdb->prefix . 'learnshapes_enrollments',
			[
				'progress_percent' => $progress_percent,
				'completed_at'     => ( $progress_percent >= 100 ) ? current_time( 'mysql' ) : null,
				'status'           => ( $progress_percent >= 100 ) ? 'completed' : 'active',
			],
			[ 'user_id' => $user_id, 'course_id' => $course_id ]
		);

		// Handle course complete triggers (e.g. issue certificate).
		if ( $progress_percent >= 100 ) {
			self::issue_certificate( $user_id, $course_id );
			do_action( 'learnshapes_after_course_complete', $user_id, $course_id );
		}

		return new \WP_REST_Response( [
			'success'          => true,
			'progress_percent' => round( $progress_percent, 2 ),
			'completed'        => ( $progress_percent >= 100 )
		], 200 );
	}

	/**
	 * Submit Quiz.
	 */
	public static function submit_quiz( $request ) {
		global $wpdb;

		$user_id = get_current_user_id();
		$quiz_id = intval( $request->get_param( 'quiz_id' ) );
		$course_id = intval( $request->get_param( 'course_id' ) );
		$answers = $request->get_param( 'answers' ); // Key-value question_id => submitted_answers.

		if ( ! $quiz_id || ! get_post( $quiz_id ) ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid Quiz' ], 400 );
		}

		// Evaluate quiz answers.
		$questions = get_post_meta( $quiz_id, '_learnshapes_questions', true );
		if ( ! is_array( $questions ) ) {
			$questions = [];
		}

		$total_points = 0;
		$earned_points = 0;
		$correct_answers_count = 0;
		$answers_to_save = [];

		foreach ( $questions as $index => $q ) {
			$q_id = isset( $q['id'] ) ? $q['id'] : $index;
			$q_type = $q['type'];
			$q_points = isset( $q['points'] ) ? floatval( $q['points'] ) : 1;
			$total_points += $q_points;

			$user_ans = isset( $answers[ $q_id ] ) ? $answers[ $q_id ] : null;
			$is_correct = false;

			// Handle checking correctness based on question type.
			if ( $q_type === 'single_choice' || $q_type === 'true_false' ) {
				$correct_ans = isset( $q['correct'] ) ? $q['correct'] : '';
				if ( strval( $user_ans ) === strval( $correct_ans ) ) {
					$is_correct = true;
				}
			} elseif ( $q_type === 'multiple_choice' ) {
				$correct_ans = isset( $q['correct'] ) ? (array) $q['correct'] : [];
				$user_ans_arr = (array) $user_ans;
				sort( $correct_ans );
				sort( $user_ans_arr );
				if ( $correct_ans === $user_ans_arr ) {
					$is_correct = true;
				}
			} elseif ( $q_type === 'fill_in_the_blank' ) {
				$correct_ans = strtolower( trim( isset( $q['correct'] ) ? $q['correct'] : '' ) );
				if ( strtolower( trim( strval( $user_ans ) ) ) === $correct_ans ) {
					$is_correct = true;
				}
			} else {
				// Short answer / Essay: default true or manual grading.
				$is_correct = true; 
			}

			$pts = 0;
			if ( $is_correct ) {
				$pts = $q_points;
				$earned_points += $pts;
				$correct_answers_count++;
			}

			$answers_to_save[] = [
				'question_id' => $q_id,
				'answer_data' => json_encode( $user_ans ),
				'is_correct'  => $is_correct ? 1 : 0,
				'points'      => $pts,
			];
		}

		$score_percent = 0;
		if ( $total_points > 0 ) {
			$score_percent = ( $earned_points / $total_points ) * 100;
		}

		$passing_score = floatval( get_post_meta( $quiz_id, '_learnshapes_passing_score', true ) ?: 80 );
		$status = ( $score_percent >= $passing_score ) ? 'passed' : 'failed';

		// Create quiz attempt.
		$table_attempts = $wpdb->prefix . 'learnshapes_quiz_attempts';
		$wpdb->insert( $table_attempts, [
			'user_id'       => $user_id,
			'quiz_id'       => $quiz_id,
			'course_id'     => $course_id,
			'score'         => $score_percent,
			'passing_score' => $passing_score,
			'status'        => $status,
			'started_at'    => current_time( 'mysql' ),
			'submitted_at'  => current_time( 'mysql' ),
		] );

		$attempt_id = $wpdb->insert_id;

		// Save answers database record.
		$table_answers = $wpdb->prefix . 'learnshapes_quiz_answers';
		foreach ( $answers_to_save as $ans ) {
			$wpdb->insert( $table_answers, [
				'attempt_id'    => $attempt_id,
				'question_id'   => $ans['question_id'],
				'answer_data'   => $ans['answer_data'],
				'is_correct'    => $ans['is_correct'],
				'points_earned' => $ans['points'],
			] );
		}

		// Save attempt in progress if passed.
		if ( $status === 'passed' ) {
			// Trigger mark progress endpoint.
			$progress_req = new \WP_REST_Request( 'POST', '/learnshapes/v1/progress/mark' );
			$progress_req->set_param( 'course_id', $course_id );
			$progress_req->set_param( 'item_id', $quiz_id );
			$progress_req->set_param( 'item_type', 'quiz' );
			$progress_req->set_param( 'status', 'completed' );
			self::mark_progress( $progress_req );
		}

		do_action( 'learnshapes_after_quiz_submit', $user_id, $quiz_id, $attempt_id, $status );

		return new \WP_REST_Response( [
			'success'       => true,
			'score'         => round( $score_percent, 2 ),
			'passing_score' => $passing_score,
			'status'        => $status,
			'attempt_id'    => $attempt_id,
		], 200 );
	}

	/**
	 * Submit Assignment.
	 */
	public static function submit_assignment( $request ) {
		global $wpdb;

		$user_id = get_current_user_id();
		$assignment_id = intval( $request->get_param( 'assignment_id' ) );
		$course_id = intval( $request->get_param( 'course_id' ) );
		$submission_text = sanitize_textarea_field( $request->get_param( 'submission_text' ) );
		$file_url = esc_url_raw( $request->get_param( 'file_url' ) );

		if ( ! $assignment_id || ! get_post( $assignment_id ) ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid Assignment' ], 400 );
		}

		$table = $wpdb->prefix . 'ls_assignment_submissions';
		$wpdb->insert( $table, [
			'user_id'         => $user_id,
			'assignment_id'   => $assignment_id,
			'course_id'       => $course_id,
			'submission_text' => $submission_text,
			'file_url'        => $file_url,
			'status'          => 'pending',
			'submitted_at'    => current_time( 'mysql' ),
		] );

		do_action( 'learnshapes_after_assignment_submit', $user_id, $assignment_id, $wpdb->insert_id );

		return new \WP_REST_Response( [ 'success' => true, 'message' => 'Assignment submitted successfully.' ], 200 );
	}

	/**
	 * Grade an assignment submission.
	 */
	public static function grade_assignment( $request ) {
		global $wpdb;

		$submission_id = intval( $request->get_param( 'submission_id' ) );
		$status = sanitize_text_field( $request->get_param( 'status' ) ); // 'approved' or 'rejected'
		$grade = sanitize_text_field( $request->get_param( 'grade' ) );
		$feedback = sanitize_textarea_field( $request->get_param( 'feedback' ) );

		$table = $wpdb->prefix . 'ls_assignment_submissions';
		$submission = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $submission_id ) );

		if ( ! $submission ) {
			return new \WP_REST_Response( [ 'success' => false, 'message' => 'Submission not found' ], 404 );
		}

		$wpdb->update( $table, [
			'status'    => $status,
			'grade'     => $grade,
			'feedback'  => $feedback,
			'graded_by' => get_current_user_id(),
			'graded_at' => current_time( 'mysql' ),
		], [ 'id' => $submission_id ] );

		// If approved, mark assignment as completed progress.
		if ( $status === 'approved' ) {
			$progress_req = new \WP_REST_Request( 'POST', '/learnshapes/v1/progress/mark' );
			$progress_req->set_param( 'course_id', $submission->course_id );
			$progress_req->set_param( 'item_id', $submission->assignment_id );
			$progress_req->set_param( 'item_type', 'assignment' );
			$progress_req->set_param( 'status', 'completed' );
			self::mark_progress( $progress_req );
		}

		do_action( 'ls_assignment_graded', $submission->user_id, $submission->assignment_id, $submission_id, $status );

		return new \WP_REST_Response( [ 'success' => true, 'message' => 'Submission graded.' ], 200 );
	}

	/**
	 * Get reports for the instructor/dashboard charts.
	 */
	public static function get_reports( $request ) {
		global $wpdb;

		// 1. Get stats overview.
		$total_students = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}learnshapes_enrollments" );
		$total_courses = wp_count_posts( 'learnshapes_course' )->publish;
		$total_completions = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}learnshapes_enrollments WHERE status = 'completed'" );
		$total_revenue = $wpdb->get_var( "SELECT SUM(amount) FROM {$wpdb->prefix}learnshapes_orders WHERE status = 'completed'" ) ?: 0;
		$new_students = $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}learnshapes_enrollments WHERE enrolled_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)" );

		// Course Status Breakdown
		$course_status = [
			'published' => intval( wp_count_posts( 'learnshapes_course' )->publish ),
			'draft'     => intval( wp_count_posts( 'learnshapes_course' )->draft ),
			'pending'   => intval( wp_count_posts( 'learnshapes_course' )->pending ),
		];

		// 2. Fetch last 7 days registrations/enrollments.
		$chart_enrollments = [];
		for ( $i = 6; $i >= 0; $i-- ) {
			$date = date( 'Y-m-d', strtotime( "-$i days" ) );
			$count = $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}learnshapes_enrollments WHERE DATE(enrolled_at) = %s",
				$date
			) );
			$chart_enrollments[] = [
				'date'  => date( 'M d', strtotime( $date ) ),
				'count' => intval( $count )
			];
		}

		// 3. Popular courses.
		$popular_db = $wpdb->get_results( "
			SELECT course_id, COUNT(*) as enrollments_count 
			FROM {$wpdb->prefix}learnshapes_enrollments 
			GROUP BY course_id 
			ORDER BY enrollments_count DESC 
			LIMIT 5
		" );

		$popular_courses = [];
		foreach ( $popular_db as $row ) {
			$popular_courses[] = [
				'title' => get_the_title( $row->course_id ),
				'count' => intval( $row->enrollments_count ),
			];
		}

		// 4. Recent Enrollments
		$recent_db = $wpdb->get_results( "
			SELECT user_id, course_id, enrolled_at 
			FROM {$wpdb->prefix}learnshapes_enrollments 
			ORDER BY enrolled_at DESC 
			LIMIT 5
		" );

		$recent_enrollments = [];
		foreach ( $recent_db as $row ) {
			$user = get_userdata( $row->user_id );
			$recent_enrollments[] = [
				'student' => $user ? $user->display_name : 'Unknown User',
				'course'  => get_the_title( $row->course_id ),
				'date'    => date( 'M d, Y', strtotime( $row->enrolled_at ) ),
			];
		}

		return new \WP_REST_Response( [
			'success' => true,
			'stats'   => [
				'students'     => intval( $total_students ),
				'courses'      => intval( $total_courses ),
				'completions'  => intval( $total_completions ),
				'revenue'      => floatval( $total_revenue ),
				'new_students' => intval( $new_students ),
			],
			'course_status' => $course_status,
			'chart'         => $chart_enrollments,
			'popular'       => $popular_courses,
			'recent'        => $recent_enrollments,
		], 200 );
	}

	/**
	 * Save General / Settings items.
	 */
	public static function save_settings( $request ) {
		$new_settings = $request->get_param( 'settings' );
		$settings = get_option( 'learnshapes_settings', [] );

		$updated = array_replace_recursive( $settings, $new_settings );
		update_option( 'learnshapes_settings', $updated );

		return new \WP_REST_Response( [ 'success' => true, 'message' => 'Settings saved.' ], 200 );
	}

	/**
	 * Helper function to issue course certificate.
	 */
	private static function issue_certificate( $user_id, $course_id ) {
		global $wpdb;

		$table_certs = $wpdb->prefix . 'ls_certificates';
		
		// Check if already issued.
		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM $table_certs WHERE user_id = %d AND course_id = %d",
			$user_id, $course_id
		) );

		if ( ! $exists ) {
			$certificate_code = 'LS-' . strtoupper( wp_generate_password( 8, false ) );
			$verification_key = md5( $certificate_code . $user_id . $course_id );

			$wpdb->insert( $table_certs, [
				'certificate_code' => $certificate_code,
				'user_id'          => $user_id,
				'course_id'        => $course_id,
				'issued_at'        => current_time( 'mysql' ),
				'verification_key' => $verification_key,
			] );

			// Send Email notification for certificate.
			do_action( 'ls_certificate_issued', $user_id, $course_id, $certificate_code );
		}
	}
}
