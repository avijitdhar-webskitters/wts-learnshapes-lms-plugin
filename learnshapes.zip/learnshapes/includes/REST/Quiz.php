<?php
namespace Learnshapes\REST;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Quiz {

    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes() {
        $namespace = 'learnshapes/v1';

        register_rest_route( $namespace, '/quiz/(?P<id>\d+)/questions', [
            [
                'methods'             => 'GET',
                'callback'            => [ __CLASS__, 'get_questions' ],
                'permission_callback' => [ __CLASS__, 'check_permission' ],
                'args'                => [
                    'id' => [ 'type' => 'integer' ]
                ]
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ __CLASS__, 'save_questions' ],
                'permission_callback' => [ __CLASS__, 'check_permission' ],
                'args'                => [
                    'id' => [ 'type' => 'integer' ]
                ]
            ]
        ] );
    }

    public static function check_permission() {
        return current_user_can( 'edit_posts' );
    }

    public static function get_questions( $request ) {
        $quiz_id = (int) $request->get_param( 'id' );
        $questions = get_post_meta( $quiz_id, '_learnshapes_quiz_questions', true );
        if ( ! is_array( $questions ) ) {
            $questions = [];
        }
        return new \WP_REST_Response( [ 'success' => true, 'questions' => $questions ], 200 );
    }

    public static function save_questions( $request ) {
        $quiz_id = (int) $request->get_param( 'id' );
        $questions = $request->get_param( 'questions' );
        
        if ( ! is_array( $questions ) ) {
            $questions = [];
        }

        update_post_meta( $quiz_id, '_learnshapes_quiz_questions', $questions );

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Questions saved successfully.' ], 200 );
    }
}
