<?php
namespace Learnshapes\REST;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Curriculum REST endpoints – manage Modules, Lessons, Topics and course structure.
 */
class Curriculum {

    /** Initialize routes */
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes() {
        $namespace = 'learnshapes/v1';

        // Get full curriculum tree for a course.
        register_rest_route( $namespace, '/curriculum/course/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_course_structure' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
            'args'                => [
                'id' => [ 'type' => 'integer' ]
            ]
        ] );

        // Save full hierarchy (POST after drag‑and‑drop reorder).
        register_rest_route( $namespace, '/curriculum/course/(?P<id>\d+)/structure', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'save_course_structure' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
            'args'                => [
                'id' => [ 'type' => 'integer' ]
            ]
        ] );

        // Create Module, Lesson, Topic (POST).
        register_rest_route( $namespace, '/curriculum/module', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'create_module' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ]
        ] );
        register_rest_route( $namespace, '/curriculum/lesson', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'create_lesson' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ]
        ] );
        register_rest_route( $namespace, '/curriculum/topic', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'create_topic' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ]
        ] );

        // Update title (PATCH) and delete (DELETE) for any item.
        register_rest_route( $namespace, '/curriculum/(?P<type>module|lesson|topic)/(?P<id>\d+)', [
            'methods'             => [ 'PATCH', 'DELETE' ],
            'callback'            => [ __CLASS__, 'handle_item' ],
            'permission_callback' => [ __CLASS__, 'check_instructor_permission' ],
            'args'                => [
                'type' => [ 'validate_callback' => fn( $param ) => in_array( $param, [ 'module', 'lesson', 'topic' ], true ) ],
                'id'   => [ 'type' => 'integer' ]
            ]
        ] );
    }

    // Permission – reuse same logic as API class.
    public static function check_instructor_permission() {
        return current_user_can( 'learnshapes_create_courses' ) || current_user_can( 'manage_options' );
    }

    // -----------------------------------------------------------------
    // GET – course structure
    public static function get_course_structure( $request ) {
        $course_id = (int) $request->get_param( 'id' );
        $structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
        if ( ! is_array( $structure ) ) {
            $structure = [];
        }
        return new \WP_REST_Response( [ 'success' => true, 'structure' => $structure ], 200 );
    }

    // POST – save full hierarchy after reorder
    public static function save_course_structure( $request ) {
        $course_id = (int) $request->get_param( 'id' );
        $structure = $request->get_param( 'structure' );
        if ( ! is_array( $structure ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid structure data.' ], 400 );
        }
        update_post_meta( $course_id, '_learnshapes_course_structure', $structure );
        // Update parent relationships for lesson and topic posts.
        foreach ( $structure as $module ) {
            $module_id = (int) $module['id'];
            if ( $module_id ) {
                update_post_meta( $module_id, '_learnshapes_parent_course', $course_id );
            }
            if ( ! empty( $module['items'] ) ) {
                foreach ( $module['items'] as $lesson ) {
                    $lesson_id = (int) $lesson['id'];
                    if ( $lesson_id ) {
                        update_post_meta( $lesson_id, '_learnshapes_parent_course', $course_id );
                        // Also set post_parent to module for ordering (optional).
                        wp_update_post( [ 'ID' => $lesson_id, 'post_parent' => $module_id ] );
                    }
                    if ( ! empty( $lesson['items'] ) ) {
                        foreach ( $lesson['items'] as $topic ) {
                            $topic_id = (int) $topic['id'];
                            if ( $topic_id ) {
                                update_post_meta( $topic_id, '_learnshapes_parent_course', $course_id );
                                wp_update_post( [ 'ID' => $topic_id, 'post_parent' => $lesson_id ] );
                            }
                        }
                    }
                }
            }
        }
        do_action( 'learnshapes_course_structure_saved', $course_id, $structure );
        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Structure saved.' ], 200 );
    }

    // Helper to create generic CPT item (module, lesson, topic).
    private static function create_item( $type, $parent_id, $title ) {
        $cpt_map = [
            'module' => 'learnshapes_module',
            'lesson' => 'learnshapes_lesson',
            'topic'  => 'learnshapes_topic',
        ];
        if ( ! isset( $cpt_map[ $type ] ) ) {
            return new \WP_Error( 'invalid_type', 'Invalid curriculum type.' );
        }
        $post_id = wp_insert_post( [
            'post_title'   => $title,
            'post_type'    => $cpt_map[ $type ],
            'post_status'  => 'publish',
            'post_parent'  => $parent_id,
        ] );
        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }
        // Store parent course for later reference.
        $course_id = self::find_course_id( $parent_id );
        if ( $course_id ) {
            update_post_meta( $post_id, '_learnshapes_parent_course', $course_id );
        }
        return $post_id;
    }

    // Resolve the course ID from any parent (module/lesson/topic).
    private static function find_course_id( $parent_id ) {
        $post = get_post( $parent_id );
        while ( $post && $post->post_type !== 'learnshapes_course' ) {
            if ( $post->post_parent ) {
                $post = get_post( $post->post_parent );
            } else {
                break;
            }
        }
        return $post ? $post->ID : 0;
    }

    public static function create_module( $request ) {
        $title = sanitize_text_field( $request->get_param( 'title' ) ?: 'New Module' );
        $post_id = self::create_item( 'module', 0, $title );
        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $post_id->get_error_message() ], 400 );
        }
        return new \WP_REST_Response( [ 'success' => true, 'id' => $post_id ], 201 );
    }

    public static function create_lesson( $request ) {
        $parent_id = (int) $request->get_param( 'parent_id' );
        $title = sanitize_text_field( $request->get_param( 'title' ) ?: 'New Lesson' );
        $post_id = self::create_item( 'lesson', $parent_id, $title );
        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $post_id->get_error_message() ], 400 );
        }
        return new \WP_REST_Response( [ 'success' => true, 'id' => $post_id ], 201 );
    }

    public static function create_topic( $request ) {
        $parent_id = (int) $request->get_param( 'parent_id' );
        $title = sanitize_text_field( $request->get_param( 'title' ) ?: 'New Topic' );
        $post_id = self::create_item( 'topic', $parent_id, $title );
        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $post_id->get_error_message() ], 400 );
        }
        return new \WP_REST_Response( [ 'success' => true, 'id' => $post_id ], 201 );
    }

    // PATCH – update title, DELETE – remove item.
    public static function handle_item( $request ) {
        $type = $request->get_param( 'type' );
        $id   = (int) $request->get_param( 'id' );
        if ( $request->get_method() === 'PATCH' ) {
            $title = sanitize_text_field( $request->get_param( 'title' ) );
            if ( $title ) {
                wp_update_post( [ 'ID' => $id, 'post_title' => $title ] );
                return new \WP_REST_Response( [ 'success' => true, 'message' => 'Title updated.' ], 200 );
            }
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'No title provided.' ], 400 );
        }
        // DELETE
        wp_delete_post( $id, true );
        return new \WP_REST_Response( [ 'success' => true, 'message' => ucfirst( $type ) . ' deleted.' ], 200 );
    }
}

// Initialise the curriculum routes.
Curriculum::init();
?>
