<?php
/**
 * Learnshapes Uninstall
 *
 * Fired when the plugin is uninstalled.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Check if the user opted to delete all data on uninstall.
$settings = get_option( 'learnshapes_settings', [] );
$delete_data = isset( $settings['advanced']['delete_data_on_uninstall'] ) ? (bool) $settings['advanced']['delete_data_on_uninstall'] : false;

// Remove auto-created pages
if ( ! empty( $settings['pages'] ) && is_array( $settings['pages'] ) ) {
    foreach ( $settings['pages'] as $page_id ) {
        if ( get_post_type( $page_id ) === 'page' ) {
            if ( get_post_meta( $page_id, '_learnshapes_is_default_page', true ) ) {
                wp_delete_post( $page_id, true );
            }
        }
    }
}

if ( $delete_data ) {
	global $wpdb;

	// Drop custom tables.
	$tables = [
		'learnshapes_enrollments',
		'learnshapes_progress',
		'learnshapes_quiz_attempts',
		'learnshapes_quiz_answers',
		'ls_assignment_submissions',
		'ls_certificates',
		'learnshapes_orders',
		'learnshapes_activity_logs',
		'learnshapes_notifications'
	];

	foreach ( $tables as $table ) {
		$wpdb->query( "DROP TABLE IF EXISTS " . $wpdb->prefix . $table );
	}

	// Delete plugin options.
	delete_option( 'learnshapes_db_version' );
	delete_option( 'learnshapes_settings' );
	delete_option( 'learnshapes_setup_completed' );

	// Delete custom post types content.
	$post_types = [
		'learnshapes_course',
		'learnshapes_lesson',
		'learnshapes_topic',
		'learnshapes_quiz',
		'ls_assignment',
		'ls_certificate'
	];

	foreach ( $post_types as $post_type ) {
		$posts = get_posts( [
			'post_type'   => $post_type,
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
		] );

		if ( ! empty( $posts ) ) {
			foreach ( $posts as $post_id ) {
				wp_delete_post( $post_id, true );
			}
		}
	}
}
