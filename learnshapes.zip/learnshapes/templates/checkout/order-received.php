<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

get_header();

$order_id = isset( $_GET['ls_order_received'] ) ? intval( $_GET['ls_order_received'] ) : 0;

if ( ! $order_id ) { ?>
<div class="ls-or-wrap"><div class="ls-or-card ls-or-error">
	<div class="ls-or-icon">❌</div>
	<h1><?php esc_html_e( 'Invalid Order', 'learnshapes' ); ?></h1>
	<p><?php esc_html_e( 'No order reference found.', 'learnshapes' ); ?></p>
	<a href="<?php echo esc_url( home_url() ); ?>" class="ls-or-btn"><?php esc_html_e( 'Return Home', 'learnshapes' ); ?></a>
</div></div>
<?php get_footer(); return; }

$order      = new \Learnshapes\Payments\Order( $order_id );
$status     = $order->get_status();
$course_id  = $order->get_course_id();
$course     = get_post( $course_id );
$data       = $order->get_data();

$settings = get_option( 'learnshapes_settings', [] );
$currency = $data['currency'] ?? 'USD';
$currency_sym = [ 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'INR' => '₹' ];
$sym = $currency_sym[ $currency ] ?? $currency;

$icons = [
	'completed'  => '✅',
	'processing' => '⏳',
	'pending'    => '🕐',
	'failed'     => '❌',
	'cancelled'  => '🚫',
	'refunded'   => '↩️',
];
$icon = $icons[ $status ] ?? '📋';

$colors = [
	'completed'  => '#16a34a',
	'processing' => '#2563eb',
	'pending'    => '#ca8a04',
	'failed'     => '#dc2626',
	'cancelled'  => '#6b7280',
	'refunded'   => '#7c3aed',
];
$color = $colors[ $status ] ?? '#6b7280';
?>

<div class="ls-or-wrap">
	<div class="ls-or-card">
		<div class="ls-or-icon"><?php echo $icon; ?></div>

		<?php if ( $status === 'completed' ) : ?>
		<h1 class="ls-or-title" style="color:<?php echo esc_attr($color); ?>">
			<?php esc_html_e( 'Thank You! Enrollment Confirmed 🎓', 'learnshapes' ); ?>
		</h1>
		<p class="ls-or-subtitle"><?php esc_html_e( 'Your payment was successful and you are now enrolled.', 'learnshapes' ); ?></p>
		<?php elseif ( in_array($status, ['pending','processing'], true) ) : ?>
		<h1 class="ls-or-title" style="color:<?php echo esc_attr($color); ?>">
			<?php esc_html_e( 'Order Received', 'learnshapes' ); ?>
		</h1>
		<p class="ls-or-subtitle"><?php esc_html_e( 'Your order is being processed. You will be notified once it is confirmed.', 'learnshapes' ); ?></p>
		<?php else : ?>
		<h1 class="ls-or-title" style="color:<?php echo esc_attr($color); ?>">
			<?php echo esc_html( ucfirst( $status ) ); ?>
		</h1>
		<p class="ls-or-subtitle"><?php esc_html_e( 'Your order status has been updated.', 'learnshapes' ); ?></p>
		<?php endif; ?>

		<div class="ls-or-meta">
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Order', 'learnshapes' ); ?></span>
				<strong><?php echo esc_html( $order->get_order_number() ); ?></strong>
			</div>
			<?php if ( $course ) : ?>
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Course', 'learnshapes' ); ?></span>
				<strong><?php echo esc_html( $course->post_title ); ?></strong>
			</div>
			<?php endif; ?>
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Amount', 'learnshapes' ); ?></span>
				<strong><?php echo esc_html( $sym . number_format( $order->get_amount(), 2 ) . ' ' . $currency ); ?></strong>
			</div>
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Payment Method', 'learnshapes' ); ?></span>
				<strong><?php echo esc_html( ucfirst( $order->get_payment_gateway() ) ); ?></strong>
			</div>
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Status', 'learnshapes' ); ?></span>
				<span class="ls-or-status-badge" style="background:<?php echo esc_attr($color); ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span>
			</div>
			<?php if ( $order->get_transaction_id() ) : ?>
			<div class="ls-or-meta-item">
				<span class="ls-or-meta-label"><?php esc_html_e( 'Transaction ID', 'learnshapes' ); ?></span>
				<strong><?php echo esc_html( $order->get_transaction_id() ); ?></strong>
			</div>
			<?php endif; ?>
		</div>

		<div class="ls-or-actions">
			<?php if ( $status === 'completed' && $course ) : ?>
			<a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="ls-or-btn ls-or-btn-primary">
				🚀 <?php esc_html_e( 'Start Learning Now', 'learnshapes' ); ?>
			</a>
			<?php endif; ?>
			<a href="<?php echo esc_url( home_url() ); ?>" class="ls-or-btn ls-or-btn-secondary">
				<?php esc_html_e( '← Return Home', 'learnshapes' ); ?>
			</a>
		</div>

		<?php if ( in_array($status, ['pending','processing'], true) ) : ?>
		<div class="ls-or-offline-note">
			<?php
			$offline_opts = get_option( 'learnshapes_payment_offline', [] );
			$instructions = $offline_opts['instructions'] ?? '';
			if ( $order->get_payment_gateway() === 'offline' && $instructions ) :
			?>
			<h4><?php esc_html_e( 'Payment Instructions', 'learnshapes' ); ?></h4>
			<?php echo wp_kses_post( wpautop( $instructions ) ); ?>
			<?php endif; ?>
			<p class="ls-or-check-email"><?php esc_html_e( '📧 A confirmation email has been sent to your address.', 'learnshapes' ); ?></p>
		</div>
		<?php endif; ?>
	</div>
</div>

<style>
.ls-or-wrap { display: flex; align-items: center; justify-content: center; min-height: 60vh; padding: 40px 20px; }
.ls-or-card { background: #fff; border-radius: 16px; border: 1px solid #e2e8f0; padding: 48px 40px; max-width: 580px; width: 100%; text-align: center; box-shadow: 0 4px 24px rgba(0,0,0,.08); }
.ls-or-icon { font-size: 56px; line-height: 1; margin-bottom: 16px; }
.ls-or-title { font-size: 24px; font-weight: 800; margin: 0 0 10px; font-family: -apple-system, sans-serif; }
.ls-or-subtitle { font-size: 15px; color: #64748b; margin: 0 0 28px; }
.ls-or-meta { background: #f8fafc; border-radius: 12px; padding: 20px 24px; text-align: left; margin-bottom: 28px; display: grid; grid-template-columns: 1fr 1fr; gap: 14px 20px; }
.ls-or-meta-item { display: flex; flex-direction: column; gap: 3px; }
.ls-or-meta-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .5px; color: #94a3b8; }
.ls-or-meta-item strong { font-size: 14px; color: #0f172a; }
.ls-or-status-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; color: #fff; font-size: 12px; font-weight: 700; }
.ls-or-actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; margin-bottom: 24px; }
.ls-or-btn { display: inline-flex; align-items: center; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none; transition: all .2s; }
.ls-or-btn-primary { background: linear-gradient(135deg,#6366f1,#8b5cf6); color: #fff; }
.ls-or-btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(99,102,241,.3); color: #fff; }
.ls-or-btn-secondary { background: #f1f5f9; color: #475569; }
.ls-or-btn-secondary:hover { background: #e2e8f0; }
.ls-or-offline-note { background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 16px 20px; text-align: left; font-size: 14px; }
.ls-or-offline-note h4 { margin: 0 0 8px; font-size: 14px; color: #92400e; }
.ls-or-check-email { margin: 12px 0 0; color: #64748b; font-size: 13px; }
@media(max-width:500px){ .ls-or-meta { grid-template-columns: 1fr; } .ls-or-card { padding: 28px 20px; } }
</style>

<?php get_footer(); ?>
