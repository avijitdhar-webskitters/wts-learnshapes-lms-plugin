<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Resolve course from URL
$course_id = isset( $_GET['course_id'] )   ? intval( $_GET['course_id'] )
           : ( isset( $_GET['add-to-cart'] ) ? intval( $_GET['add-to-cart'] ) : 0 );
if ( ! $course_id && get_query_var( 'course_id' ) ) {
	$course_id = intval( get_query_var( 'course_id' ) );
}

$settings         = get_option( 'learnshapes_settings', [] );
$guest_checkout   = ! empty( $settings['payment']['guest_checkout'] );
$account_login    = isset( $settings['payment']['account_login'] )    ? $settings['payment']['account_login']    : '1';
$account_creation = isset( $settings['payment']['account_creation'] ) ? $settings['payment']['account_creation'] : '1';
$currency_sym     = [ 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'INR' => '₹' ];
$is_logged_in     = is_user_logged_in();

// Already enrolled → go to course
if ( $course_id && $is_logged_in ) {
	global $wpdb;
	$enrolled = $wpdb->get_var( $wpdb->prepare(
		"SELECT id FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id=%d AND course_id=%d AND status='active'",
		get_current_user_id(), $course_id
	) );
	if ( $enrolled ) {
		wp_safe_redirect( get_permalink( $course_id ) );
		exit;
	}
}

if ( ! $course_id ) {
	echo '<div class="ls-co-notice ls-co-error"><p>' . esc_html__( 'No course selected.', 'learnshapes' ) . '</p></div>';
	return;
}

$course = get_post( $course_id );
if ( ! $course || $course->post_type !== 'learnshapes_course' ) {
	echo '<div class="ls-co-notice ls-co-error"><p>' . esc_html__( 'Invalid course.', 'learnshapes' ) . '</p></div>';
	return;
}

$price        = floatval( get_post_meta( $course_id, '_learnshapes_price', true ) ?: 0 );
$sale_price   = floatval( get_post_meta( $course_id, '_learnshapes_sale_price', true ) ?: 0 );
$final_price  = ( $sale_price > 0 && $sale_price < $price ) ? $sale_price : $price;
$currency     = $settings['payment']['currency'] ?? 'USD';
$sym          = $currency_sym[ $currency ] ?? $currency;
$gateways     = \Learnshapes\Payments\GatewayManager::get_available_gateways();
$nonce        = wp_create_nonce( 'learnshapes_frontend_nonce' );
$ajax_url     = admin_url( 'admin-ajax.php' );
$thumb        = get_the_post_thumbnail_url( $course_id, 'medium' );
$instructor   = get_post_meta( $course_id, '_ls_instructor_name', true )
             ?: get_the_author_meta( 'display_name', $course->post_author );
?>

<div class="ls-co-wrap">

  <!-- ── Header ─────────────────────────────────────────────────────── -->
  <div class="ls-co-header">
    <a class="ls-co-back" href="<?php echo esc_url( get_permalink( $course_id ) ); ?>">← Back to Course</a>
    <div class="ls-co-brand">
      <span class="ls-co-brand-dot"></span>
      <strong>Secure Checkout</strong>
      <span class="ls-co-lock">🔒</span>
    </div>
  </div>

  <!-- ── Step Banner ───────────────────────────────────────────────── -->
  <div class="ls-co-steps">
    <div class="ls-co-step ls-co-step-active"><span>1</span> Details</div>
    <div class="ls-co-step-divider"></div>
    <div class="ls-co-step"><span>2</span> Payment</div>
    <div class="ls-co-step-divider"></div>
    <div class="ls-co-step"><span>3</span> Access</div>
  </div>

  <!-- ── Login prompt ──────────────────────────────────────────────── -->
  <?php if ( ! $is_logged_in && $account_login ) : ?>
  <div class="ls-co-login-bar">
    <div class="ls-co-login-bar-top">
      <div class="ls-co-login-bar-left">
        <div class="ls-co-login-avatar-sm">👤</div>
        <span>Already have an account? <strong>Sign in for faster checkout</strong></span>
      </div>
      <button type="button" id="ls-toggle-login" class="ls-co-toggle-btn">
        <span id="ls-toggle-text">Sign In</span>
        <svg id="ls-toggle-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="transition:transform .25s"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
    </div>
    <div id="ls-login-box" style="display:none;">
      <div class="ls-co-login-panel">
        <form id="ls-login-form">
          <div class="ls-co-login-fields">
            <div class="ls-co-login-field">
              <label>Username or Email</label>
              <input type="text" name="log" class="ls-co-input" placeholder="you@example.com" required autocomplete="username">
            </div>
            <div class="ls-co-login-field">
              <label>Password</label>
              <input type="password" name="pwd" class="ls-co-input" placeholder="••••••••" required autocomplete="current-password">
            </div>
          </div>
          <div id="ls-login-msg" class="ls-co-msg"></div>
          <div class="ls-co-login-actions">
            <button type="submit" class="ls-co-btn ls-co-btn-login">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
              Sign In to Account
            </button>
            <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="ls-co-forgot">Forgot password?</a>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── Main Grid ──────────────────────────────────────────────────── -->
  <div class="ls-co-grid">

    <!-- LEFT: Billing + Payment -->
    <div class="ls-co-left">
      <form id="ls-checkout-form">
        <input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>">

        <!-- Billing Details -->
        <div class="ls-co-card">
          <h3 class="ls-co-card-title">
            <span class="ls-co-card-icon">👤</span> Billing Details
          </h3>

          <?php if ( $is_logged_in ) :
            $user = wp_get_current_user(); ?>
          <div class="ls-co-user-chip">
            <div class="ls-co-avatar"><?php echo esc_html( strtoupper( substr( $user->display_name, 0, 2 ) ) ); ?></div>
            <div>
              <strong><?php echo esc_html( $user->display_name ); ?></strong>
              <span><?php echo esc_html( $user->user_email ); ?></span>
            </div>
            <span class="ls-co-verified">✓ Verified</span>
          </div>

          <?php elseif ( $account_creation || $guest_checkout ) : ?>
          <div class="ls-co-row-2">
            <div class="ls-co-field">
              <label>First Name <em>*</em></label>
              <input type="text" name="billing_first_name" class="ls-co-input" <?php if($account_creation) echo 'required'; ?> placeholder="John">
            </div>
            <div class="ls-co-field">
              <label>Last Name</label>
              <input type="text" name="billing_last_name" class="ls-co-input" placeholder="Doe">
            </div>
          </div>
          <div class="ls-co-field">
            <label>Email Address <em>*</em></label>
            <input type="email" name="billing_email" class="ls-co-input" required placeholder="john@example.com">
          </div>
          <?php if ( $guest_checkout && ! $account_creation ) : ?>
          <p class="ls-co-hint">✓ Checking out as guest</p>
          <?php endif; ?>

          <?php else : ?>
          <div class="ls-co-notice ls-co-warn">Please log in to complete your purchase.</div>
          <?php endif; ?>
        </div>

        <!-- Payment Method -->
        <div class="ls-co-card">
          <h3 class="ls-co-card-title">
            <span class="ls-co-card-icon">💳</span> Payment Method
          </h3>

          <?php if ( $final_price <= 0 ) : ?>
          <input type="hidden" name="payment_method" value="free">
          <div class="ls-co-free-badge">
            <span>🎉</span>
            <div>
              <strong>Free Enrollment</strong>
              <p>No payment required — click below to enroll instantly.</p>
            </div>
          </div>

          <?php elseif ( empty( $gateways ) ) : ?>
          <div class="ls-co-notice ls-co-warn">No payment methods configured. Please contact support.</div>

          <?php else :
            $first = true;
            foreach ( $gateways as $gw_id => $gateway ) : ?>
          <label class="ls-co-gateway <?php echo $first ? 'ls-co-gateway-active' : ''; ?>" for="pm_<?php echo esc_attr($gw_id); ?>">
            <input type="radio" id="pm_<?php echo esc_attr($gw_id); ?>" name="payment_method" value="<?php echo esc_attr($gw_id); ?>" <?php checked($first,true); ?>>
            <span class="ls-co-gateway-name"><?php echo esc_html($gateway->title); ?></span>
          </label>
          <div class="ls-co-gateway-detail" id="ls-gd-<?php echo esc_attr($gw_id); ?>" <?php if(!$first) echo 'style="display:none"'; ?>>
            <?php $gateway->render_checkout_fields(); ?>
          </div>
          <?php $first = false; endforeach; endif; ?>
        </div>

        <!-- Place Order -->
        <div class="ls-co-place-wrap">
          <div id="ls-co-msg" class="ls-co-msg" style="display:none;"></div>
          <label class="ls-co-terms">
            <input type="checkbox" id="ls-terms" required>
            I agree to the <a href="#" target="_blank">Terms &amp; Conditions</a>
          </label>
          <button type="submit" id="ls-place-order" class="ls-co-btn ls-co-btn-primary ls-co-btn-full">
            <?php echo $final_price <= 0 ? '🎓 Enroll for Free' : '🚀 Complete Purchase'; ?>
          </button>
          <p class="ls-co-secure">🔒 256-bit SSL encrypted · Secure payment</p>
        </div>
      </form>
    </div>

    <!-- RIGHT: Order Summary (sticky) -->
    <div class="ls-co-right">
      <div class="ls-co-summary" id="ls-co-summary">

        <!-- Course thumbnail -->
        <?php if ( $thumb ) : ?>
        <div class="ls-co-thumb-wrap">
          <img class="ls-co-thumb" src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($course->post_title); ?>">
          <div class="ls-co-thumb-overlay"></div>
        </div>
        <?php endif; ?>

        <!-- Course info -->
        <div class="ls-co-sum-info">
          <span class="ls-co-sum-label">You're enrolling in</span>
          <strong class="ls-co-course-name"><?php echo esc_html($course->post_title); ?></strong>
          <?php if ($instructor) : ?>
          <div class="ls-co-instructor-row">
            <div class="ls-co-inst-dot"><?php echo esc_html(strtoupper(substr($instructor,0,1))); ?></div>
            <span>by <?php echo esc_html($instructor); ?></span>
          </div>
          <?php endif; ?>
        </div>

        <!-- Price breakdown -->
        <div class="ls-co-price-block">
          <?php if ($sale_price > 0 && $sale_price < $price) : ?>
          <div class="ls-co-price-row">
            <span>Original</span>
            <span class="ls-co-strikethrough"><?php echo esc_html($sym . number_format($price, 2)); ?></span>
          </div>
          <div class="ls-co-price-row ls-co-saving-row">
            <span>You save</span>
            <span class="ls-co-saving-val">-<?php echo esc_html($sym . number_format($price - $sale_price, 2)); ?></span>
          </div>
          <?php endif; ?>
          <div class="ls-co-total-block">
            <span>Total Due Today</span>
            <?php if ($final_price <= 0) : ?>
            <div class="ls-co-big-price ls-co-free-price">FREE</div>
            <?php else : ?>
            <div class="ls-co-big-price"><?php echo esc_html($sym . number_format($final_price, 2)); ?> <small><?php echo esc_html($currency); ?></small></div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Feature list -->
        <ul class="ls-co-features">
          <li><span class="ls-co-feat-icon">⚡</span><span>Instant access after payment</span></li>
          <li><span class="ls-co-feat-icon">🏅</span><span>Certificate of completion</span></li>
          <li><span class="ls-co-feat-icon">♾️</span><span>Lifetime access</span></li>
          <li><span class="ls-co-feat-icon">🛡️</span><span>30-day money-back guarantee</span></li>
        </ul>

        <!-- Trust badges -->
        <div class="ls-co-trust">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          <span>256-bit SSL · Secure &amp; Encrypted</span>
        </div>

      </div>
    </div>

  </div>
</div>

<style>
/* ── Base ───────────────────────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
.ls-co-wrap { max-width:1080px; margin:0 auto; padding:24px 20px 60px; font-family:'Inter',sans-serif; color:#0f172a; }

/* Header */
.ls-co-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.ls-co-back { font-size:14px; color:#6366f1; text-decoration:none; font-weight:600; }
.ls-co-back:hover { text-decoration:underline; }
.ls-co-brand { display:flex; align-items:center; gap:8px; font-size:14px; font-weight:600; color:#475569; }
.ls-co-brand-dot { width:10px; height:10px; background:linear-gradient(135deg,#6366f1,#8b5cf6); border-radius:50%; }
.ls-co-lock { font-size:16px; }

/* Steps */
.ls-co-steps { display:flex; align-items:center; justify-content:center; gap:8px; margin-bottom:28px; }
.ls-co-step { display:flex; align-items:center; gap:6px; font-size:13px; font-weight:600; color:#94a3b8; }
.ls-co-step span { width:26px; height:26px; border-radius:50%; background:#e2e8f0; display:flex; align-items:center; justify-content:center; font-size:12px; }
.ls-co-step-active { color:#6366f1; }
.ls-co-step-active span { background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; }
.ls-co-step-divider { width:40px; height:2px; background:#e2e8f0; border-radius:2px; }

/* Login bar */
.ls-co-login-bar { background:#fff; border:1.5px solid #e2e8f0; border-radius:14px; margin-bottom:22px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.04); }
.ls-co-login-bar-top { display:flex; align-items:center; justify-content:space-between; padding:14px 20px; gap:12px; }
.ls-co-login-bar-left { display:flex; align-items:center; gap:12px; font-size:14px; color:#475569; flex:1; min-width:0; }
.ls-co-login-bar-left strong { color:#0f172a; }
.ls-co-login-avatar-sm { width:36px; height:36px; background:linear-gradient(135deg,#6366f1,#8b5cf6); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:17px; flex-shrink:0; }
.ls-co-toggle-btn { display:flex; align-items:center; gap:6px; padding:8px 16px; border:1.5px solid #6366f1; border-radius:8px; background:#f0f1ff; color:#6366f1; font-size:13px; font-weight:700; font-family:inherit; cursor:pointer; transition:all .2s; white-space:nowrap; flex-shrink:0; }
.ls-co-toggle-btn:hover { background:#6366f1; color:#fff; }
.ls-co-login-panel { padding:20px; border-top:1px solid #f1f5f9; background:#fafafe; }
.ls-co-login-fields { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px; }
@media(max-width:600px){ .ls-co-login-fields { grid-template-columns:1fr; } }
.ls-co-login-field label { display:block; font-size:12px; font-weight:700; color:#64748b; text-transform:uppercase; letter-spacing:.5px; margin-bottom:6px; }
.ls-co-login-actions { display:flex; align-items:center; gap:16px; flex-wrap:wrap; }
.ls-co-btn-login { padding:10px 20px; font-size:14px; background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; border-radius:8px; border:none; cursor:pointer; font-weight:700; display:inline-flex; align-items:center; gap:7px; transition:all .2s; font-family:inherit; }
.ls-co-btn-login:hover { filter:brightness(1.1); transform:translateY(-1px); box-shadow:0 4px 12px rgba(99,102,241,.3); }
.ls-co-forgot { font-size:13px; color:#94a3b8; text-decoration:none; }
.ls-co-forgot:hover { color:#6366f1; }

/* Grid */
.ls-co-grid { display:grid; grid-template-columns:1fr 380px; gap:28px; align-items:start; }
@media(max-width:800px){ .ls-co-grid { grid-template-columns:1fr; } }

/* Cards */
.ls-co-card { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:28px; margin-bottom:20px; box-shadow:0 2px 8px rgba(0,0,0,.04); }
.ls-co-card-title { margin:0 0 20px !important; font-size:18px !important; font-weight:700 !important; display:flex; align-items:center; gap:8px; padding-bottom:14px; border-bottom:1px solid #f1f5f9; text-transform:none !important; line-height: 1.3 !important; }
.ls-co-card-icon { font-size:18px; }

/* User chip */
.ls-co-user-chip { display:flex; align-items:center; gap:14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 18px; }
.ls-co-avatar { width:44px; height:44px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; font-weight:700; font-size:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.ls-co-user-chip strong { display:block; font-size:14px; font-weight:700; }
.ls-co-user-chip span { font-size:13px; color:#64748b; }
.ls-co-verified { margin-left:auto; font-size:12px; font-weight:700; color:#10b981; background:#f0fdf4; padding:4px 10px; border-radius:20px; border:1px solid #a7f3d0; white-space:nowrap; }

/* Fields */
.ls-co-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.ls-co-field { margin-bottom:14px; }
.ls-co-field label { display:block; font-size:13px; font-weight:600; margin-bottom:5px; color:#475569; }
.ls-co-field label em { color:#ef4444; font-style:normal; }
.ls-co-input { width:100%; padding:10px 14px; border:1.5px solid #e2e8f0; border-radius:8px; font-size:14px; font-family:'Inter',sans-serif; outline:none; transition:border-color .2s,box-shadow .2s; box-sizing:border-box; background:#fff; }
.ls-co-input:focus { border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,.12); }
.ls-co-hint { font-size:12px; color:#64748b; margin:6px 0 0; }

/* Gateways */
.ls-co-gateway { display:flex; align-items:center; gap:10px; padding:14px 16px; border:2px solid #e2e8f0; border-radius:10px; margin-bottom:10px; cursor:pointer; transition:border-color .2s,background .2s; font-size:14px; font-weight:600; }
.ls-co-gateway:hover { border-color:#a5b4fc; background:#fafafe; }
.ls-co-gateway-active { border-color:#6366f1; background:#f0f1ff; }
.ls-co-gateway input[type="radio"] { accent-color:#6366f1; width:17px; height:17px; }
.ls-co-gateway-detail { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:14px 16px; margin-bottom:12px; font-size:13px; color:#475569; }

/* Free badge */
.ls-co-free-badge { display:flex; gap:14px; align-items:center; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:10px; padding:16px 18px; }
.ls-co-free-badge span { font-size:32px; }
.ls-co-free-badge strong { display:block; color:#064e3b; font-size:15px; font-weight:700; }
.ls-co-free-badge p { margin:4px 0 0; color:#10b981; font-size:13px; }

/* Terms + place order */
.ls-co-place-wrap { margin-top:4px; }
.ls-co-terms { display:flex; align-items:center; gap:8px; font-size:13px; color:#475569; margin-bottom:14px; cursor:pointer; }
.ls-co-terms input { accent-color:#6366f1; width:16px; height:16px; flex-shrink:0; }
.ls-co-terms a { color:#6366f1; }
.ls-co-btn { display:inline-flex; align-items:center; justify-content:center; gap:8px; padding:12px 24px; border-radius:10px; font-size:14px; font-weight:700; font-family:'Inter',sans-serif; cursor:pointer; border:none; transition:all .2s; text-decoration:none; }
.ls-co-btn-primary { background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; }
.ls-co-btn-primary:hover { filter:brightness(1.08); transform:translateY(-1px); box-shadow:0 6px 20px rgba(99,102,241,.35); }
.ls-co-btn-primary:disabled { opacity:.6; cursor:not-allowed; transform:none; box-shadow:none; }
.ls-co-btn-sm { padding:9px 18px; font-size:13px; background:#6366f1; color:#fff; border-radius:8px; }
.ls-co-btn-full { width:100%; padding:15px; font-size:15px; }
.ls-co-secure { text-align:center; font-size:12px; color:#94a3b8; margin:10px 0 0; }

/* Messages */
.ls-co-msg { padding:12px 16px; border-radius:8px; font-size:13px; font-weight:600; margin-bottom:12px; display:none; }
.ls-co-msg.ls-ok { background:#f0fdf4; color:#16a34a; border:1px solid #bbf7d0; display:block; }
.ls-co-msg.ls-err { background:#fef2f2; color:#dc2626; border:1px solid #fecaca; display:block; }
.ls-co-notice { padding:12px 16px; border-radius:8px; font-size:14px; margin-bottom:14px; }
.ls-co-warn { background:#fffbeb; border:1px solid #fde68a; color:#92400e; }
.ls-co-error { background:#fef2f2; border:1px solid #fecaca; color:#dc2626; }

/* Summary (right) */
.ls-co-summary { background:#fff; border:1px solid #e2e8f0; border-radius:16px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,.07); position:sticky; top:20px; }
.ls-co-thumb-wrap { position:relative; }
.ls-co-thumb { width:100%; aspect-ratio:16/9; object-fit:cover; display:block; }
.ls-co-thumb-overlay { position:absolute; inset:0; background:linear-gradient(to bottom, transparent 40%, rgba(0,0,0,.55) 100%); }
.ls-co-sum-info { padding:18px 20px 16px; border-bottom:1px solid #f1f5f9; }
.ls-co-sum-label { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.7px; color:#94a3b8; display:block; margin-bottom:6px; }
.ls-co-course-name { display:block; font-size:16px; font-weight:800; color:#0f172a; line-height:1.35; margin-bottom:10px; }
.ls-co-instructor-row { display:flex; align-items:center; gap:8px; }
.ls-co-inst-dot { width:22px; height:22px; border-radius:50%; background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff; font-size:10px; font-weight:800; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.ls-co-instructor-row span { font-size:13px; color:#64748b; }
/* Price block */
.ls-co-price-block { padding:18px 20px; background:linear-gradient(135deg,#0f172a 0%,#1e1b4b 100%); }
.ls-co-price-row { display:flex; justify-content:space-between; align-items:center; font-size:13px; color:rgba(255,255,255,.65); margin-bottom:6px; }
.ls-co-strikethrough { text-decoration:line-through; color:rgba(255,255,255,.4); }
.ls-co-saving-row { color:#4ade80; }
.ls-co-saving-val { font-weight:700; color:#4ade80; }
.ls-co-total-block { border-top:1px solid rgba(255,255,255,.12); margin-top:10px; padding-top:12px; display:flex; justify-content:space-between; align-items:center; }
.ls-co-total-block span { font-size:12px; font-weight:600; color:rgba(255,255,255,.6); text-transform:uppercase; letter-spacing:.5px; }
.ls-co-big-price { font-size:26px; font-weight:900; color:#fff; line-height:1; }
.ls-co-big-price small { font-size:13px; font-weight:500; color:rgba(255,255,255,.6); vertical-align:middle; }
.ls-co-free-price { background:linear-gradient(135deg,#10b981,#34d399); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
/* Features */
.ls-co-features { list-style:none; margin:0; padding:16px 20px; display:flex; flex-direction:column; gap:10px; border-bottom:1px solid #f1f5f9; }
.ls-co-features li { display:flex; align-items:center; gap:10px; font-size:13px; color:#475569; }
.ls-co-feat-icon { font-size:16px; flex-shrink:0; }
/* Trust */
.ls-co-trust { display:flex; align-items:center; gap:7px; padding:12px 20px; font-size:12px; color:#64748b; background:#f8fafc; }

/* PayPal gateway detail */
.ls-paypal-box { text-align:center; padding:16px 12px; }
.ls-paypal-logo { margin-bottom:10px; }
.ls-paypal-desc { font-size:13px; color:#64748b; margin:0 0 12px; line-height:1.5; }
.ls-paypal-badges { display:flex; justify-content:center; gap:10px; flex-wrap:wrap; }
.ls-paypal-badge { background:#f0f9ff; border:1px solid #bae6fd; color:#0369a1; font-size:12px; font-weight:600; padding:4px 10px; border-radius:20px; }

@keyframes ls-spin { to { transform:rotate(360deg) } }
</style>

<script>
jQuery(function($){
  var ajaxUrl = '<?php echo esc_js($ajax_url); ?>';
  var nonce   = '<?php echo esc_js($nonce); ?>';

  // Toggle login
  $('#ls-toggle-login').on('click', function(){
    var $box = $('#ls-login-box');
    var $arrow = $('#ls-toggle-arrow');
    var $text  = $('#ls-toggle-text');
    $box.slideToggle(220, function(){
      var open = $box.is(':visible');
      $arrow.css('transform', open ? 'rotate(180deg)' : 'rotate(0deg)');
      $text.text(open ? 'Close' : 'Sign In');
    });
  });

  // Login AJAX
  $('#ls-login-form').on('submit', function(e){
    e.preventDefault();
    var $btn = $(this).find('button');
    $btn.prop('disabled',true).text('Signing in…');
    $.post(ajaxUrl,{
      action:'learnshapes_ajax_login',
      nonce:nonce,
      log:$(this).find('[name="log"]').val(),
      pwd:$(this).find('[name="pwd"]').val()
    }).done(function(res){
      if(res.success){ location.reload(); }
      else { $('#ls-login-msg').html(res.data.message||'Login failed.'); $btn.prop('disabled',false).text('Log In'); }
    });
  });

  // Gateway switch
  $(document).on('change','input[name="payment_method"]',function(){
    var id=$(this).val();
    $('.ls-co-gateway').removeClass('ls-co-gateway-active');
    $(this).closest('.ls-co-gateway').addClass('ls-co-gateway-active');
    $('.ls-co-gateway-detail').hide();
    $('#ls-gd-'+id).slideDown(150);
  });

  // Message helper
  function showMsg(msg,type){
    var $m=$('#ls-co-msg');
    $m.removeClass('ls-ok ls-err').addClass(type==='error'?'ls-err':'ls-ok').html(msg).show();
    $('html,body').animate({scrollTop:$m.offset().top-100},300);
  }

  // Checkout submit
  $('#ls-checkout-form').on('submit',function(e){
    e.preventDefault();
    var $btn=$('#ls-place-order');
    var orig=$btn.html();
    $btn.prop('disabled',true).html('<svg style="animation:ls-spin 1s linear infinite;width:18px;height:18px;display:inline-block;vertical-align:middle" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10" stroke-opacity=".3"/><path d="M12 2a10 10 0 0 1 10 10"/></svg> Processing…');
    $('#ls-co-msg').hide();
    $.post(ajaxUrl,$(this).serialize()+'&action=learnshapes_checkout&nonce='+nonce)
    .done(function(res){
      if(res.success){
        if(res.data.redirect_url){ window.location.href=res.data.redirect_url; }
        else { showMsg(res.data.message||'Success!','success'); $btn.prop('disabled',false).html(orig); }
      } else {
        showMsg(res.data.message||'Payment failed. Please try again.','error');
        $btn.prop('disabled',false).html(orig);
      }
    }).fail(function(){ showMsg('Connection error. Please try again.','error'); $btn.prop('disabled',false).html(orig); });
  });
});
</script>

