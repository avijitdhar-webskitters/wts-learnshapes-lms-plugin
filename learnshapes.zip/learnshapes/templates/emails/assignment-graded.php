<?php
/**
 * Assignment Graded Email Template
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** @var string $header */
/** @var string $footer */
/** @var WP_User $user */
/** @var int $assignment_id */
/** @var string $grade */
/** @var string $feedback */
?>
<?php echo $header; ?>
<h2 style="font-family:Arial,Helvetica,sans-serif; color:#4f46e5;"><?php esc_html_e( 'Your Assignment Has Been Graded', 'learnshapes' ); ?></h2>
<p style="font-family:Arial,Helvetica,sans-serif;"><?php printf( esc_html__( 'Hello %s,', 'learnshapes' ), esc_html( $user->display_name ) ); ?></p>
<p style="font-family:Arial,Helvetica,sans-serif;">
    <?php printf(
        esc_html__( 'Your submission for assignment ID %d has been graded.', 'learnshapes' ),
        esc_html( $assignment_id )
    ); ?>
</p>
<p style="font-family:Arial,Helvetica,sans-serif;">
    <?php esc_html_e( 'Grade:', 'learnshapes' ); ?> <strong><?php echo esc_html( $grade ); ?></strong>
</p>
<?php if ( $feedback ) : ?>
<p style="font-family:Arial,Helvetica,sans-serif;">
    <?php esc_html_e( 'Feedback from the instructor:', 'learnshapes' ); ?>
    <br/><em><?php echo nl2br( esc_html( $feedback ) ); ?></em>
</p>
<?php endif; ?>
<p style="font-family:Arial,Helvetica,sans-serif;">
    <?php esc_html_e( 'You can view your submission and details in your student dashboard.', 'learnshapes' ); ?>
</p>
<?php echo $footer; ?>
