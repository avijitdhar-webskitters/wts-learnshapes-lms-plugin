<?php
/**
 * Single Learnshapes Course Template – premium design.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Enqueue the new premium course page styles
wp_enqueue_style( 'learnshapes-course-page-css', LEARNSHAPES_URL . 'assets/css/course-page.css', [], time() );

global $post;
$course_id = $post->ID;

// Retrieve price meta
$price = get_post_meta( $course_id, '_learnshapes_price', true );
$price_display = $price ? floatval( $price ) : 0;

// Student progress
$user_id = get_current_user_id();
$progress = 0;
$completed_lessons = 0;
$total_lessons = 0;

// Calculate total lessons from structure
$structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
if ( is_array( $structure ) ) {
    foreach ( $structure as $module ) {
        if ( ! empty( $module['items'] ) && is_array( $module['items'] ) ) {
            $total_lessons += count($module['items']);
        }
    }
}

if ( $user_id ) {
    global $wpdb;
    $table   = $wpdb->prefix . 'learnshapes_enrollments';
    $percent = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT progress_percent FROM $table WHERE user_id = %d AND course_id = %d AND status = 'active'",
            $user_id,
            $course_id
        )
    );
    if ( $percent !== null ) {
        $progress = floatval( $percent );
        if ($total_lessons > 0) {
            $completed_lessons = round(($progress / 100) * $total_lessons); // Approximate for display
        }
    }
}

// Determine enrollment status
$is_enrolled = false;
if ( $user_id ) {
    $is_enrolled = (bool) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id = %d AND course_id = %d AND status = 'active'",
            $user_id,
            $course_id
        )
    );
}

$cta_label = $is_enrolled ? __( 'Continue Lesson', 'learnshapes' ) : ( $price_display > 0 ? __( 'Enroll Now', 'learnshapes' ) : __( 'Enroll Now (Free)', 'learnshapes' ) );
$cta_action = $is_enrolled ? 'continue' : 'enroll';

get_header(); ?>

<div class="ls-course-wrap">
    
    <!-- Top Bar Breadcrumbs -->
    <div class="ls-breadcrumbs">
        <a href="<?php echo esc_url( home_url('/courses') ); ?>"><?php esc_html_e('All Courses', 'learnshapes'); ?></a>
        <span class="sep">&gt;</span>
        <span class="current"><?php echo esc_html( get_the_title( $course_id ) ); ?></span>
    </div>

    <div class="ls-course-header-card">
        <div class="ls-course-header-img" style="background-image:url('<?php echo esc_url( get_the_post_thumbnail_url( $course_id, 'large' ) ); ?>');">
        </div>
        <div class="ls-course-header-info">
            <span class="ls-tag">DIGITAL MARKETING</span>
            <h1 class="ls-course-title"><?php echo esc_html( get_the_title( $course_id ) ); ?></h1>
            <p class="ls-course-excerpt"><?php echo wp_kses_post( get_the_excerpt( $course_id ) ); ?></p>
            
            <div class="ls-course-meta">
                <div class="ls-meta-item"><span class="dashicons dashicons-media-document"></span> <?php echo is_array($structure) ? count($structure) : 0; ?> Topics</div>
                <div class="ls-meta-item"><span class="dashicons dashicons-welcome-learn-more"></span> <?php echo esc_html($total_lessons); ?> Lessons</div>
                <div class="ls-meta-item"><span class="dashicons dashicons-awards"></span> Certificate</div>
            </div>

            <div class="ls-course-progress-wrap">
                <div class="ls-progress-labels">
                    <span class="ls-progress-percent"><strong><?php echo round($progress); ?>%</strong> Complete</span>
                    <span class="ls-progress-count"><?php echo esc_html($completed_lessons); ?> / <?php echo esc_html($total_lessons); ?> Lessons</span>
                </div>
                <div class="ls-progress-bar"><div class="ls-progress-fill" style="width:<?php echo esc_attr( $progress ); ?>%;"></div></div>
            </div>
        </div>
    </div>

    <div class="ls-course-grid">
        <!-- Left Column -->
        <div class="ls-course-main">

            <!-- Curriculum Header -->
            <div class="ls-curriculum-header">
                <a href="#" class="ls-expand-all"><span class="dashicons dashicons-external"></span> Expand All</a>
                <a href="#" class="ls-collapse-all"><span class="dashicons dashicons-external" style="transform: scaleX(-1);"></span> Collapse All</a>
            </div>

            <!-- Curriculum Accordion -->
            <div class="ls-course-content-accordion">
                <?php
                if ( class_exists( '\Learnshapes\Renderer\CurriculumRenderer' ) ) {
                    \Learnshapes\Renderer\CurriculumRenderer::render( $course_id, $is_enrolled );
                }
                ?>
            </div>
        </div>

        <!-- Right Column / Sidebar -->
        <div class="ls-course-sidebar">
            
            <!-- Course Content Sidebar Nav -->
            <div class="ls-sidebar-card ls-content-sidebar">
                <div class="ls-sidebar-card-header">
                    <div class="ls-icon-box"><span class="dashicons dashicons-list-view"></span></div>
                    <h3><?php esc_html_e('Course Content', 'learnshapes'); ?></h3>
                </div>
                <ul class="ls-sidebar-nav-list">
                    <?php 
                    if ( is_array( $structure ) ) {
                        foreach ( $structure as $module ) {
                            echo '<li><a href="#module-' . esc_attr($module['id']) . '">';
                            echo esc_html($module['title']);
                            echo '<span class="ls-sidebar-nav-right">0/2 ';
                            if ( ! $is_enrolled ) {
                                echo '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>';
                            } else {
                                echo '<span class="dashicons dashicons-arrow-right-alt2"></span>';
                            }
                            echo '</span></a></li>';
                        }
                    } else {
                         echo '<li>' . esc_html__('No content', 'learnshapes') . '</li>';
                    }
                    ?>
                </ul>
            </div>

            <!-- Enrollment CTA -->
            <div class="ls-sidebar-card ls-enrollment-card">
                <div class="ls-sidebar-card-header">
                    <div class="ls-icon-box" style="background:#e0f2fe; color:#0369a1;"><span class="dashicons dashicons-welcome-learn-more"></span></div>
                    <h3><?php esc_html_e('Enrollment', 'learnshapes'); ?></h3>
                </div>
                <div class="ls-enrollment-content">
                    <?php if ( $price_display > 0 && !$is_enrolled ) : ?>
                        <p class="ls-price"><?php echo esc_html( '$' . number_format_i18n( $price_display, 2 ) ); ?></p>
                        <p class="ls-enrollment-desc">This course requires a one-time payment.</p>
                    <?php elseif ( !$is_enrolled ) : ?>
                        <p class="ls-price ls-price-free"><?php esc_html_e('Free', 'learnshapes'); ?></p>
                        <p class="ls-enrollment-desc">This course is free to enroll.</p>
                    <?php else: ?>
                        <p class="ls-price ls-price-enrolled"><?php esc_html_e('Enrolled', 'learnshapes'); ?></p>
                        <p class="ls-enrollment-desc">You are currently enrolled.</p>
                    <?php endif; ?>
                    <button class="ls-btn-primary" id="ls-course-action" data-action="<?php echo esc_attr( $cta_action ); ?>" data-course-id="<?php echo esc_attr( $course_id ); ?>">
                        <?php if (!$is_enrolled) echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px; vertical-align: middle;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'; ?>
                        <?php echo esc_html( $is_enrolled ? __( 'Continue Lesson', 'learnshapes' ) : __( 'Enroll to Unlock', 'learnshapes' ) ); ?>
                    </button>
                    <?php if (!$is_enrolled) : ?>
                    <div class="ls-guarantee">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                        30-Day Money Back Guarantee
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Info Card -->
            <div class="ls-sidebar-card ls-info-card">
                <div class="ls-icon-box ls-icon-box-purple"><span class="dashicons dashicons-star-filled"></span></div>
                <h4>Learn at your own pace</h4>
                <p>Start learning anytime and access course materials 24/7.</p>
            </div>

        </div>
    </div>
    </div>
</div>

<?php if (!$is_enrolled) : ?>
<div class="ls-locked-footer-bar">
    <div class="ls-locked-footer-content">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
        <strong>Locked Content:</strong> All lessons, quizzes, and course materials are locked until the user enrolls in the course. Content is non-clickable and shows a lock icon with a clear call to action.
    </div>
</div>
<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('ls-course-action');
        if (!btn) return;
        btn.addEventListener('click', function() {
            const action = btn.dataset.action;
            const courseId = btn.dataset.courseId;
            
            // Disable button during process
            btn.disabled = true;
            btn.innerText = 'Processing...';

            if (action === 'enroll' || action === 'purchase') {
                if (learnshapes.checkoutUrl) {
                    let sep = learnshapes.checkoutUrl.indexOf('?') !== -1 ? '&' : '?';
                    window.location.href = learnshapes.checkoutUrl + sep + 'add-to-cart=' + courseId;
                } else {
                    alert('Checkout page not configured. Please contact the administrator.');
                    btn.disabled = false;
                    btn.innerText = '<?php echo esc_js($cta_label); ?>';
                }
            } else if (action === 'resume' || action === 'continue') {
                window.location.href = learnshapes.resturl.replace('/wp-json/learnshapes/v1', '') + '/?post_type=learnshapes_course&p=' + courseId + '&resume=true';
            }
        });
    });
</script>

<?php get_footer(); ?>
