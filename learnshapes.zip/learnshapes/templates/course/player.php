<?php
/**
 * Distraction-Free Learning Player Template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wpdb;
$user_id = get_current_user_id();

// Redirect to login if user is not logged in.
if ( ! $user_id ) {
	auth_redirect();
	exit;
}

$current_item_id = get_the_ID();
$current_post_type = get_post_type();
$course_id = get_post_meta( $current_item_id, '_learnshapes_parent_course', true );

// If course ID isn't directly set, attempt to find a course linking to this step
if ( ! $course_id ) {
	$courses = get_posts( [
		'post_type'  => 'learnshapes_course',
		'meta_key'   => '_learnshapes_course_structure',
		'meta_value' => strval( $current_item_id ),
		'meta_compare' => 'LIKE',
		'fields'     => 'ids',
	] );
	if ( ! empty( $courses ) ) {
		$course_id = $courses[0];
	}
}

// Fetch enrollment and check access.
$enrollment = null;
if ( $course_id ) {
	$enrollment = $wpdb->get_row( $wpdb->prepare(
		"SELECT * FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id = %d AND course_id = %d",
		$user_id, $course_id
	) );
}

// Block access if not enrolled (unless admin/editor).
if ( ! $enrollment && ! current_user_can( 'manage_options' ) ) {
	wp_safe_redirect( get_permalink( $course_id ) );
	exit;
}

$structure = get_post_meta( $course_id, '_learnshapes_course_structure', true ) ?: [];
$completed_ids = $wpdb->get_col( $wpdb->prepare(
	"SELECT item_id FROM {$wpdb->prefix}learnshapes_progress WHERE user_id = %d AND course_id = %d AND status = 'completed'",
	$user_id, $course_id
) ) ?: [];

$progress_percent = $enrollment ? floatval( $enrollment->progress_percent ) : 0;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php the_title(); ?> - Learnshapes Player</title>
	<?php wp_head(); ?>
	<style>
		/* Override WP Admin Bar padding */
		html { margin-top: 0px !important; }
		#wpadminbar { display: none !important; }
	</style>
</head>
<body class="learnshapes-player-body">

<div class="learnshapes-player">
	<!-- Player Left Sidebar -->
	<aside class="player-sidebar">
		<div class="player-sidebar-header">
			<a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="back-link">
				<span class="dashicons dashicons-arrow-left-alt"></span> <?php esc_html_e( 'Back to Course Details', 'learnshapes' ); ?>
			</a>
			<h2 style="margin-top:15px;"><?php echo esc_html( get_the_title( $course_id ) ); ?></h2>
		</div>

		<div class="player-outline-list">
			<?php if ( empty( $structure ) ) : ?>
				<p style="padding: 20px; font-size:12px;"><?php esc_html_e( 'Empty outline.', 'learnshapes' ); ?></p>
			<?php else : ?>
				<?php foreach ( $structure as $section ) : ?>
					<div class="player-outline-section"><?php echo esc_html( $section['title'] ); ?></div>
					<?php if ( isset( $section['items'] ) && is_array( $section['items'] ) ) : ?>
						<?php foreach ( $section['items'] as $item ) :
							$item_id = $item['id'];
							$type = $item['type'];
							$is_active = ( $item_id === $current_item_id );
							$is_completed = in_array( $item_id, $completed_ids );
							
							$icon = 'welcome-write-blog';
							if ( $type === 'quiz' ) {
								$icon = 'welcome-edit-page';
							} elseif ( $type === 'assignment' ) {
								$icon = 'portfolio';
							}
							?>
							<a href="<?php echo esc_url( get_permalink( $item_id ) ); ?>" class="player-outline-item <?php echo $is_active ? 'active' : ''; ?> <?php echo $is_completed ? 'completed' : ''; ?>">
								<span class="dashicons dashicons-<?php echo esc_attr( $is_completed ? 'yes' : $icon ); ?>"></span>
								<span><?php echo esc_html( get_the_title( $item_id ) ); ?></span>
							</a>
						<?php endforeach; ?>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</aside>

	<!-- Player Right/Main Area -->
	<div class="player-main">
		<!-- Top Bar with Course Progress -->
		<header class="player-topbar">
			<div class="player-title">
				<h3><?php the_title(); ?></h3>
			</div>
			
			<div class="player-progress-area" style="display:flex; align-items:center; gap:20px; width: 350px;">
				<div class="progress-bar-bg" style="flex-grow:1;">
					<div class="progress-bar-fill" style="width: <?php echo esc_attr( $progress_percent ); ?>%;"></div>
				</div>
				<span style="font-size:12px; font-weight:bold; color:var(--ls-text-muted); min-width: 40px;"><?php echo esc_html( round( $progress_percent ) ); ?>%</span>
			</div>
		</header>

		<!-- Content Panel -->
		<main class="player-content">
			<div class="player-content-inner">
				
				<?php if ( $current_post_type === 'learnshapes_lesson' || $current_post_type === 'learnshapes_topic' ) : ?>
					<!-- LESSON INTERFACE -->
					<div class="lesson-content">
						<?php the_content(); ?>
					</div>

					<div class="player-footer-actions" style="margin-top:40px; border-top: 1px solid var(--ls-border); padding-top:20px; display:flex; justify-content:flex-end;">
						<?php
						$is_completed = in_array( $current_item_id, $completed_ids );
						?>
						<button id="learnshapes-mark-complete" class="widget-btn" style="width:auto; padding: 12px 30px; background: <?php echo $is_completed ? 'var(--ls-text-muted)' : 'var(--ls-success)'; ?>;" data-course="<?php echo esc_attr( $course_id ); ?>" data-item="<?php echo esc_attr( $current_item_id ); ?>" data-type="lesson">
							<?php echo $is_completed ? esc_html__( 'Completed ✓', 'learnshapes' ) : esc_html__( 'Mark Lesson Complete', 'learnshapes' ); ?>
						</button>
					</div>

				<?php elseif ( $current_post_type === 'learnshapes_quiz' ) : ?>
					<!-- QUIZ INTERFACE -->
					<?php
					$questions = get_post_meta( $current_item_id, '_learnshapes_questions', true ) ?: [];
					?>
					<div class="quiz-interface">
						<div class="quiz-instructions">
							<?php the_content(); ?>
							<p style="margin-top:10px; font-weight:bold;">Total Questions: <?php echo count( $questions ); ?></p>
						</div>

						<form id="learnshapes-quiz-form">
							<input type="hidden" name="quiz_id" value="<?php echo esc_attr( $current_item_id ); ?>">
							<input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>">

							<?php foreach ( $questions as $q_index => $q ) :
								$q_id = isset( $q['id'] ) ? $q['id'] : $q_index;
								$q_type = $q['type'];
								?>
								<div class="quiz-question-box">
									<h4>Question <?php echo $q_index + 1; ?>: <?php echo esc_html( $q['question'] ); ?></h4>
									<ul class="quiz-options">
										<?php if ( $q_type === 'single_choice' || $q_type === 'true_false' ) : ?>
											<?php foreach ( $q['options'] as $o_index => $option ) : ?>
												<li class="quiz-option-item">
													<label>
														<input type="radio" name="answers[<?php echo esc_attr( $q_id ); ?>]" value="<?php echo esc_attr( $o_index ); ?>" required>
														<span><?php echo esc_html( $option ); ?></span>
													</label>
												</li>
											<?php endforeach; ?>
										<?php elseif ( $q_type === 'multiple_choice' ) : ?>
											<?php foreach ( $q['options'] as $o_index => $option ) : ?>
												<li class="quiz-option-item">
													<label>
														<input type="checkbox" name="answers[<?php echo esc_attr( $q_id ); ?>][]" value="<?php echo esc_attr( $o_index ); ?>">
														<span><?php echo esc_html( $option ); ?></span>
													</label>
												</li>
											<?php endforeach; ?>
										<?php elseif ( $q_type === 'fill_in_the_blank' ) : ?>
											<li class="quiz-option-item">
												<input type="text" name="answers[<?php echo esc_attr( $q_id ); ?>]" class="regular-text" placeholder="Type your answer here..." required style="width: 100%; border: 1px solid var(--ls-border); border-radius: var(--ls-radius-sm); padding:10px;">
											</li>
										<?php endif; ?>
									</ul>
								</div>
							<?php endforeach; ?>

							<button type="submit" class="widget-btn" style="margin-top:20px; background:var(--ls-primary);">Submit Quiz Answers</button>
						</form>

						<div id="quiz-result-card" class="learnshapes-card" style="display:none; margin-top:30px;">
							<h3 class="result-title">Quiz Results</h3>
							<div class="result-score" style="font-size:36px; font-weight:bold; margin:20px 0;">0%</div>
							<p class="result-status" style="font-weight:bold;"></p>
							<button onclick="location.reload();" class="button">Retake Quiz</button>
						</div>
					</div>

				<?php elseif ( $current_post_type === 'ls_assignment' ) : ?>
					<!-- ASSIGNMENT INTERFACE -->
					<div class="assignment-interface">
						<div class="assignment-description">
							<?php the_content(); ?>
						</div>

						<div class="assignment-submission-form" style="margin-top:30px; border-top:1px solid var(--ls-border); padding-top:25px;">
							<h3>Your Submission</h3>
							<form id="learnshapes-assignment-form">
								<input type="hidden" name="assignment_id" value="<?php echo esc_attr( $current_item_id ); ?>">
								<input type="hidden" name="course_id" value="<?php echo esc_attr( $course_id ); ?>">

								<div class="form-group">
									<label for="sub-text">Write your submission details:</label>
									<textarea id="sub-text" name="submission_text" rows="6" class="large-text" placeholder="Enter answers or descriptions..." style="width: 100%; border: 1px solid var(--ls-border); border-radius: var(--ls-radius-sm); padding:10px;"></textarea>
								</div>

								<div class="form-group" style="margin-top:15px;">
									<label for="sub-file">Or enter a link to file upload (PDF/Drive):</label>
									<input type="text" id="sub-file" name="file_url" class="regular-text" placeholder="https://example.com/yourfile.pdf" style="width: 100%; border: 1px solid var(--ls-border); border-radius: var(--ls-radius-sm); padding:10px;">
								</div>

								<button type="submit" class="widget-btn" style="margin-top:20px; background:var(--ls-primary);">Submit Assignment</button>
							</form>
						</div>
					</div>
				<?php endif; ?>

			</div>
		</main>
	</div>
</div>

<script>
	jQuery(document).ready(function($) {
		// 1. Mark Lesson Complete AJAX
		$('#learnshapes-mark-complete').on('click', function() {
			let button = $(this);
			let courseId = button.data('course');
			let itemId = button.data('item');
			let itemType = button.data('type');

			button.prop('disabled', true).text('Updating...');

			$.ajax({
				url: learnshapes.resturl + '/progress/mark',
				method: 'POST',
				beforeSend: function(xhr) {
					xhr.setRequestHeader('X-WP-Nonce', learnshapes.restNonce);
				},
				data: {
					course_id: courseId,
					item_id: itemId,
					item_type: itemType,
					status: 'completed'
				},
				success: function(response) {
					if (response.success) {
						button.text('Completed ✓').css('background', 'var(--ls-text-muted)');
						$('.player-progress-area .progress-bar-fill').css('width', response.progress_percent + '%');
						$('.player-progress-area span').text(Math.round(response.progress_percent) + '%');
						
						// Highlight in sidebar
						let sidebarItem = $('.player-outline-item.active');
						sidebarItem.addClass('completed');
						sidebarItem.find('span.dashicons').removeClass('dashicons-welcome-write-blog').addClass('dashicons-yes');
						
						if (response.completed) {
							alert('Congratulations! You completed the course.');
						}
					}
				},
				error: function() {
					alert('Failed to mark completion.');
					button.prop('disabled', false).text('Mark Lesson Complete');
				}
			});
		});

		// 2. Quiz Submission Form AJAX
		$('#learnshapes-quiz-form').on('submit', function(e) {
			e.preventDefault();
			let form = $(this);
			let submitBtn = form.find('button[type="submit"]');
			submitBtn.prop('disabled', true).text('Evaluating answers...');

			// Serialize form data manually to match REST parameters
			let quizId = form.find('input[name="quiz_id"]').val();
			let courseId = form.find('input[name="course_id"]').val();
			
			// Extract answers
			let answers = {};
			form.serializeArray().forEach(item => {
				if (item.name.startsWith('answers[')) {
					let qKey = item.name.match(/answers\[(.*?)\]/)[1];
					if (item.name.endsWith('][]')) {
						answers[qKey] = answers[qKey] || [];
						answers[qKey].push(item.value);
					} else {
						answers[qKey] = item.value;
					}
				}
			});

			$.ajax({
				url: learnshapes.resturl + '/quiz/submit',
				method: 'POST',
				beforeSend: function(xhr) {
					xhr.setRequestHeader('X-WP-Nonce', learnshapes.restNonce);
				},
				contentType: 'application/json',
				data: JSON.stringify({
					quiz_id: quizId,
					course_id: courseId,
					answers: answers
				}),
				success: function(response) {
					if (response.success) {
						form.slideUp(200);
						let card = $('#quiz-result-card');
						card.find('.result-score').text(Math.round(response.score) + '%');
						card.find('.result-status').text('Status: ' + response.status.toUpperCase() + ' (Passing threshold: ' + response.passing_score + '%)');
						if (response.status === 'passed') {
							card.find('.result-status').css('color', 'green');
						} else {
							card.find('.result-status').css('color', 'red');
						}
						card.slideDown(200);
					}
				},
				error: function() {
					alert('Quiz submission failed.');
					submitBtn.prop('disabled', false).text('Submit Quiz Answers');
				}
			});
		});

		// 3. Assignment Submission Form AJAX
		$('#learnshapes-assignment-form').on('submit', function(e) {
			e.preventDefault();
			let form = $(this);
			let submitBtn = form.find('button[type="submit"]');
			submitBtn.prop('disabled', true).text('Submitting...');

			$.ajax({
				url: learnshapes.resturl + '/assignment/submit',
				method: 'POST',
				beforeSend: function(xhr) {
					xhr.setRequestHeader('X-WP-Nonce', learnshapes.restNonce);
				},
				data: {
					assignment_id: form.find('input[name="assignment_id"]').val(),
					course_id: form.find('input[name="course_id"]').val(),
					submission_text: form.find('textarea[name="submission_text"]').val(),
					file_url: form.find('input[name="file_url"]').val()
				},
				success: function(response) {
					if (response.success) {
						form.html('<p style="color:green; font-weight:bold; font-size:16px;">✓ Submission received. Your work has been sent to the instructor for grading.</p>');
					}
				},
				error: function() {
					alert('Assignment submission failed.');
					submitBtn.prop('disabled', false).text('Submit Assignment');
				}
			});
		});
	});
</script>

<?php wp_footer(); ?>
</body>
</html>
