<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$user_id = get_current_user_id();

// Capture filters from GET
$search_query   = isset( $_GET['ls_search'] ) ? sanitize_text_field( wp_unslash( $_GET['ls_search'] ) ) : '';
$selected_cats  = isset( $_GET['ls_cat'] ) && is_array( $_GET['ls_cat'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_GET['ls_cat'] ) ) : [];
$selected_diffs = isset( $_GET['ls_diff'] ) && is_array( $_GET['ls_diff'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_GET['ls_diff'] ) ) : [];
$selected_prices = isset( $_GET['ls_price'] ) && is_array( $_GET['ls_price'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_GET['ls_price'] ) ) : [];
$sort_by        = isset( $_GET['ls_sort'] ) ? sanitize_text_field( wp_unslash( $_GET['ls_sort'] ) ) : 'newest';

$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1 );

$args = [
	'post_type'      => 'learnshapes_course',
	'posts_per_page' => 12,
	'post_status'    => 'publish',
	'paged'          => $paged,
];

if ( $search_query ) {
	$args['s'] = $search_query;
}

$tax_queries = [];
if ( ! empty( $selected_cats ) ) {
	$tax_queries[] = [
		'taxonomy' => 'learnshapes_category',
		'field'    => 'slug',
		'terms'    => $selected_cats,
	];
}
if ( ! empty( $selected_diffs ) ) {
	$tax_queries[] = [
		'taxonomy' => 'learnshapes_difficulty',
		'field'    => 'slug',
		'terms'    => $selected_diffs,
	];
}

if ( count( $tax_queries ) > 1 ) {
	$tax_queries['relation'] = 'AND';
}
if ( ! empty( $tax_queries ) ) {
	$args['tax_query'] = $tax_queries;
}

// Meta queries for pricing
if ( count( $selected_prices ) === 1 ) {
	if ( in_array( 'free', $selected_prices ) ) {
		$args['meta_query'] = [
			'relation' => 'OR',
			[
				'key'     => '_learnshapes_price',
				'value'   => ['0', '0.00', ''],
				'compare' => 'IN'
			],
			[
				'key'     => '_learnshapes_price',
				'compare' => 'NOT EXISTS'
			]
		];
	} elseif ( in_array( 'paid', $selected_prices ) ) {
		$args['meta_query'] = [
			[
				'key'     => '_learnshapes_price',
				'value'   => 0,
				'compare' => '>',
				'type'    => 'NUMERIC'
			]
		];
	}
}

// Sorting
if ( $sort_by === 'newest' ) {
	$args['orderby'] = 'date';
	$args['order']   = 'DESC';
} elseif ( $sort_by === 'oldest' ) {
	$args['orderby'] = 'date';
	$args['order']   = 'ASC';
} elseif ( $sort_by === 'title_a' ) {
	$args['orderby'] = 'title';
	$args['order']   = 'ASC';
} elseif ( $sort_by === 'title_z' ) {
	$args['orderby'] = 'title';
	$args['order']   = 'DESC';
}

$courses_query = new \WP_Query( $args );

// Get taxonomies for filters
$categories = get_terms( [ 'taxonomy' => 'learnshapes_category', 'hide_empty' => true ] );
$difficulties = get_terms( [ 'taxonomy' => 'learnshapes_difficulty', 'hide_empty' => true ] );

// Settings for currency
$settings = get_option( 'learnshapes_settings', [] );
$currency = $settings['payment']['currency'] ?? 'USD';
$currency_sym = [ 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'INR' => '₹' ];
$sym = $currency_sym[ $currency ] ?? $currency;

$total_courses = $courses_query->found_posts;
$start_count = ( $paged - 1 ) * 12 + 1;
$end_count = min( $paged * 12, $total_courses );
if ( $total_courses == 0 ) $start_count = 0;

$is_ajax = isset( $_SERVER['HTTP_X_REQUESTED_WITH'] ) && strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) === 'xmlhttprequest';

// If this is an AJAX request, just return the inner main content
if ( $is_ajax ) {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	ob_start();
}
?>

<?php if ( ! $is_ajax ) : ?>
<div class="ls-catalog-wrap">
	<!-- Header -->
	<div class="ls-catalog-header">
		<h1><?php esc_html_e( 'Explore All Courses', 'learnshapes' ); ?></h1>
		<p><?php esc_html_e( 'Discover expert-led courses across a variety of topics and advance your skills.', 'learnshapes' ); ?></p>
	</div>

	<div class="ls-catalog-layout">
		<!-- Sidebar Filters -->
		<aside class="ls-catalog-sidebar">
			<form id="ls-courses-filter-form" action="" method="GET">
				
				<div class="ls-filter-header">
					<h3><?php esc_html_e( 'Filters', 'learnshapes' ); ?></h3>
					<a href="<?php echo esc_url( remove_query_arg( ['ls_search', 'ls_cat', 'ls_diff', 'ls_price', 'ls_sort', 'paged'] ) ); ?>" class="ls-filter-reset"><?php esc_html_e( 'Reset All', 'learnshapes' ); ?></a>
				</div>

				<div class="ls-filter-group">
					<h4 class="ls-filter-title"><?php esc_html_e( 'Search', 'learnshapes' ); ?></h4>
					<div class="ls-search-box">
						<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
						<input type="text" name="ls_search" placeholder="<?php esc_attr_e( 'Search courses...', 'learnshapes' ); ?>" value="<?php echo esc_attr( $search_query ); ?>">
					</div>
				</div>

				<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
				<div class="ls-filter-group">
					<h4 class="ls-filter-title"><?php esc_html_e( 'Categories', 'learnshapes' ); ?> <span class="ls-toggle-icon"></span></h4>
					<div class="ls-filter-options">
						<?php foreach ( $categories as $cat ) : ?>
						<label class="ls-checkbox-label">
							<input type="checkbox" name="ls_cat[]" value="<?php echo esc_attr( $cat->slug ); ?>" <?php checked( in_array( $cat->slug, $selected_cats ), true ); ?>>
							<span class="ls-checkbox-custom"></span>
							<span class="ls-checkbox-text"><?php echo esc_html( $cat->name ); ?></span>
							<span class="ls-filter-count"><?php echo esc_html( $cat->count ); ?></span>
						</label>
						<?php endforeach; ?>
					</div>
				</div>
				<?php endif; ?>

				<?php if ( ! empty( $difficulties ) && ! is_wp_error( $difficulties ) ) : ?>
				<div class="ls-filter-group">
					<h4 class="ls-filter-title"><?php esc_html_e( 'Level', 'learnshapes' ); ?> <span class="ls-toggle-icon"></span></h4>
					<div class="ls-filter-options">
						<?php foreach ( $difficulties as $diff ) : ?>
						<label class="ls-checkbox-label">
							<input type="checkbox" name="ls_diff[]" value="<?php echo esc_attr( $diff->slug ); ?>" <?php checked( in_array( $diff->slug, $selected_diffs ), true ); ?>>
							<span class="ls-checkbox-custom"></span>
							<span class="ls-checkbox-text"><?php echo esc_html( $diff->name ); ?></span>
							<span class="ls-filter-count"><?php echo esc_html( $diff->count ); ?></span>
						</label>
						<?php endforeach; ?>
					</div>
				</div>
				<?php endif; ?>

				<div class="ls-filter-group">
					<h4 class="ls-filter-title"><?php esc_html_e( 'Price', 'learnshapes' ); ?> <span class="ls-toggle-icon"></span></h4>
					<div class="ls-filter-options">
						<label class="ls-checkbox-label">
							<input type="checkbox" name="ls_price[]" value="free" <?php checked( in_array( 'free', $selected_prices ), true ); ?>>
							<span class="ls-checkbox-custom"></span>
							<span class="ls-checkbox-text"><?php esc_html_e( 'Free', 'learnshapes' ); ?></span>
						</label>
						<label class="ls-checkbox-label">
							<input type="checkbox" name="ls_price[]" value="paid" <?php checked( in_array( 'paid', $selected_prices ), true ); ?>>
							<span class="ls-checkbox-custom"></span>
							<span class="ls-checkbox-text"><?php esc_html_e( 'Paid', 'learnshapes' ); ?></span>
						</label>
					</div>
				</div>
				
				<!-- hidden sort input so it persists when filtering -->
				<input type="hidden" name="ls_sort" value="<?php echo esc_attr( $sort_by ); ?>" id="ls_sort_hidden">
			</form>
		</aside>

		<!-- Main Content -->
		<div class="ls-catalog-main" id="ls-catalog-main-content">
<?php endif; // End if not AJAX ?>

			<div class="ls-catalog-topbar">
				<div class="ls-results-count">
					<?php printf( esc_html__( 'Showing %1$d - %2$d of %3$d courses', 'learnshapes' ), $start_count, $end_count, $total_courses ); ?>
				</div>
				<div class="ls-catalog-actions">
					<div class="ls-sort-dropdown">
						<label for="ls-sort-select"><?php esc_html_e( 'Sort by:', 'learnshapes' ); ?></label>
						<select id="ls-sort-select">
							<option value="newest" <?php selected( $sort_by, 'newest' ); ?>><?php esc_html_e( 'Newest', 'learnshapes' ); ?></option>
							<option value="oldest" <?php selected( $sort_by, 'oldest' ); ?>><?php esc_html_e( 'Oldest', 'learnshapes' ); ?></option>
							<option value="title_a" <?php selected( $sort_by, 'title_a' ); ?>><?php esc_html_e( 'Title A-Z', 'learnshapes' ); ?></option>
							<option value="title_z" <?php selected( $sort_by, 'title_z' ); ?>><?php esc_html_e( 'Title Z-A', 'learnshapes' ); ?></option>
						</select>
					</div>
					<div class="ls-view-toggles">
						<button class="ls-view-btn ls-active" data-view="grid"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h6v6H4zm10 0h6v6h-6zM4 14h6v6H4zm10 0h6v6h-6z"/></svg></button>
						<button class="ls-view-btn" data-view="list"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/></svg></button>
					</div>
				</div>
			</div>

			<?php if ( $courses_query->have_posts() ) : ?>
			<div class="ls-course-grid" id="ls-course-grid">
				<?php while ( $courses_query->have_posts() ) : $courses_query->the_post(); 
					$course_id = get_the_ID();
					$permalink = get_permalink( $course_id );
					$price = get_post_meta( $course_id, '_learnshapes_price', true );
					$is_free = empty( $price ) || floatval( $price ) === 0.00;
					$price_label = $is_free ? __( 'Free', 'learnshapes' ) : $sym . number_format( floatval( $price ), 2 );
					
					// Taxonomies
					$cats = get_the_terms( $course_id, 'learnshapes_category' );
					$cat_name = ! empty( $cats ) ? $cats[0]->name : __( 'Uncategorized', 'learnshapes' );
					
					$diffs = get_the_terms( $course_id, 'learnshapes_difficulty' );
					$diff_name = ! empty( $diffs ) ? $diffs[0]->name : __( 'All Levels', 'learnshapes' );

					// Rating
					$rating = get_post_meta( $course_id, '_learnshapes_rating', true ) ?: '0.0';
					$rating_count = get_post_meta( $course_id, '_learnshapes_rating_count', true ) ?: '0';

					// Author
					$author_id = get_post_field( 'post_author', $course_id );
					$author_name = get_the_author_meta( 'display_name', $author_id );
					$author_avatar = get_avatar_url( $author_id, ['size' => 64] );
					
					// Lessons count
					$structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
					$lesson_count = 0;
					if ( is_array( $structure ) ) {
						foreach( $structure as $sec ) {
							if ( isset($sec['items']) ) $lesson_count += count($sec['items']);
						}
					}
					
					$is_bestseller = get_post_meta( $course_id, '_learnshapes_students', true ) > 1000;
				?>
				<div class="ls-card">
					<div class="ls-card-thumb">
						<a href="<?php echo esc_url( $permalink ); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'medium_large' ); ?>
							<?php else : ?>
								<div class="ls-card-thumb-fallback"></div>
							<?php endif; ?>
						</a>
						<?php if ( $is_bestseller ) : ?>
							<span class="ls-badge-bestseller"><?php esc_html_e( 'Bestseller', 'learnshapes' ); ?></span>
						<?php endif; ?>
						<button class="ls-bookmark-btn"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg></button>
					</div>
					<div class="ls-card-content">
						<span class="ls-card-cat"><?php echo esc_html( strtoupper($cat_name) ); ?></span>
						<h3 class="ls-card-title"><a href="<?php echo esc_url( $permalink ); ?>"><?php the_title(); ?></a></h3>
						<p class="ls-card-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 12 ) ); ?></p>
						
						<div class="ls-card-author-rating">
							<div class="ls-card-author">
								<img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>">
								<span><?php echo esc_html($author_name); ?></span>
							</div>
							<?php if ( $rating > 0 ) : ?>
							<div class="ls-card-rating">
								<span class="ls-star">★</span> <?php echo esc_html($rating); ?> <span class="ls-rating-count">(<?php echo esc_html($rating_count); ?>)</span>
							</div>
							<?php endif; ?>
						</div>
					</div>
					<div class="ls-card-footer">
						<div class="ls-card-meta">
							<span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg> <?php echo esc_html($lesson_count); ?> <?php esc_html_e('Lessons', 'learnshapes'); ?></span>
							<span><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline></svg> <?php echo esc_html($diff_name); ?></span>
						</div>
						<div class="ls-card-price <?php echo $is_free ? 'ls-free' : ''; ?>">
							<?php echo esc_html( $price_label ); ?>
						</div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>

			<!-- AJAX Load More / Pagination -->
			<?php if ( $courses_query->max_num_pages > 1 && $paged < $courses_query->max_num_pages ) : ?>
			<div class="ls-load-more-wrap">
				<button id="ls-load-more-btn" class="ls-btn-primary" data-next-page="<?php echo esc_attr( $paged + 1 ); ?>">
					<?php esc_html_e( 'Load More Courses', 'learnshapes' ); ?>
					<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.59-9.21l5.67-1.36"/></svg>
				</button>
				<p class="ls-load-status"><?php printf( esc_html__( 'Showing %1$d - %2$d of %3$d courses', 'learnshapes' ), 1, $end_count, $total_courses ); ?></p>
			</div>
			<?php else : ?>
			<div class="ls-load-more-wrap">
				<p class="ls-load-status"><?php esc_html_e( 'All courses loaded', 'learnshapes' ); ?></p>
			</div>
			<?php endif; ?>

			<?php else : ?>
			<div class="ls-no-results">
				<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
				<h3><?php esc_html_e( 'No courses found', 'learnshapes' ); ?></h3>
				<p><?php esc_html_e( 'Try adjusting your filters or search terms to find what you are looking for.', 'learnshapes' ); ?></p>
				<button class="ls-btn-secondary" onclick="window.location.href='<?php echo esc_url( remove_query_arg( ['ls_search', 'ls_cat', 'ls_diff', 'ls_price', 'ls_sort', 'paged'] ) ); ?>'"><?php esc_html_e('Clear All Filters', 'learnshapes'); ?></button>
			</div>
			<?php endif; wp_reset_postdata(); ?>

<?php 
if ( $is_ajax ) {
	$html = ob_get_clean();
	echo $html;
	exit;
}
?>
		</div>
	</div>
</div>

<style>
/* Force clean fonts against theme */
.ls-catalog-wrap, .ls-catalog-wrap h1, .ls-catalog-wrap h2, .ls-catalog-wrap h3, .ls-catalog-wrap h4, .ls-catalog-wrap p, .ls-catalog-wrap span, .ls-catalog-wrap div, .ls-catalog-wrap a, .ls-catalog-wrap label { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important; }
.ls-catalog-wrap { max-width: 1280px; margin: 40px auto; padding: 0 20px; color: #0f172a; }
.ls-catalog-header { margin-bottom: 40px; text-align: left; }
.ls-catalog-header h1 { font-size: 36px; font-weight: 800; margin: 0 0 12px; color: #0f172a; letter-spacing: -1px; }
.ls-catalog-header p { font-size: 16px; color: #64748b; margin: 0; max-width: 600px; line-height: 1.5; }

.ls-catalog-layout { display: grid; grid-template-columns: 260px 1fr; gap: 40px; align-items: start; }

/* Sidebar */
.ls-catalog-sidebar { background: #fff; position: sticky; top: 20px; }
.ls-filter-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.ls-filter-header h3 { margin: 0; font-size: 18px; font-weight: 700; color: #0f172a; }
.ls-filter-reset { font-size: 13px; color: #6366f1; text-decoration: none; font-weight: 600; }
.ls-filter-reset:hover { text-decoration: underline; }

.ls-filter-group { border-bottom: 1px solid #f1f5f9; padding-bottom: 24px; margin-bottom: 24px; }
.ls-filter-group:last-child { border-bottom: none; }
.ls-filter-title { font-size: 14px; font-weight: 700; margin: 0 0 16px; color: #0f172a; display: flex; justify-content: space-between; align-items: center; }

/* Search Box */
.ls-search-box { position: relative; }
.ls-search-box svg { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8; }
.ls-search-box input { width: 100%; padding: 10px 12px 10px 36px !important; border: 1px solid #e2e8f0 !important; border-radius: 8px !important; font-size: 14px !important; outline: none !important; transition: border-color 0.2s, box-shadow 0.2s !important; box-sizing: border-box !important; background: #fff !important; margin: 0 !important; }
.ls-search-box input:focus { border-color: #6366f1 !important; box-shadow: 0 0 0 3px rgba(99,102,241,0.1) !important; }

/* Checkboxes & Radios */
.ls-filter-options { display: flex; flex-direction: column; gap: 12px; }
.ls-checkbox-label, .ls-radio-label { display: flex; align-items: center; cursor: pointer; font-size: 14px; color: #475569; position: relative; user-select: none; margin: 0 !important; padding: 0 !important; }
.ls-checkbox-label input, .ls-radio-label input { position: absolute; opacity: 0; cursor: pointer; height: 0; width: 0; }
.ls-checkbox-custom, .ls-radio-custom { height: 18px; width: 18px; background-color: #fff; border: 1.5px solid #cbd5e1; border-radius: 4px; margin-right: 10px; display: flex; align-items: center; justify-content: center; transition: all 0.2s; flex-shrink: 0; }
.ls-radio-custom { border-radius: 50%; }
.ls-checkbox-label input:checked ~ .ls-checkbox-custom, .ls-radio-label input:checked ~ .ls-radio-custom { background-color: #6366f1; border-color: #6366f1; }
.ls-checkbox-custom::after { content: ""; display: none; width: 4px; height: 8px; border: solid white; border-width: 0 2px 2px 0; transform: rotate(45deg); margin-bottom: 2px; }
.ls-radio-custom::after { content: ""; display: none; width: 6px; height: 6px; border-radius: 50%; background: white; }
.ls-checkbox-label input:checked ~ .ls-checkbox-custom::after, .ls-radio-label input:checked ~ .ls-radio-custom::after { display: block; }
.ls-checkbox-label:hover .ls-checkbox-text, .ls-radio-label:hover .ls-radio-text { color: #0f172a; }
.ls-checkbox-text, .ls-radio-text { flex-grow: 1; }
.ls-filter-count { font-size: 12px; color: #94a3b8; }

/* Topbar */
.ls-catalog-topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #f1f5f9; flex-wrap: wrap; gap: 16px; }
.ls-results-count { font-size: 14px; color: #475569; font-weight: 500; }
.ls-catalog-actions { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
.ls-sort-dropdown { display: flex; align-items: center; gap: 8px; font-size: 14px; color: #475569; font-weight: 500; white-space: nowrap; }
.ls-sort-dropdown label { margin: 0; }
.ls-sort-dropdown select { border: 1px solid #e2e8f0 !important; border-radius: 6px !important; font-size: 14px !important; font-weight: 600 !important; color: #0f172a !important; cursor: pointer !important; outline: none !important; background: #fff !important; padding: 6px 12px !important; margin: 0 !important; height: auto !important; }
.ls-view-toggles { display: flex; gap: 4px; background: #f8fafc; padding: 4px; border-radius: 6px; }
.ls-view-btn { background: transparent !important; border: none !important; padding: 6px !important; margin: 0 !important; cursor: pointer !important; color: #94a3b8 !important; border-radius: 4px !important; display: flex !important; align-items: center !important; justify-content: center !important; transition: all 0.2s !important; box-shadow: none !important; min-width: auto !important; min-height: auto !important; line-height: 1 !important; outline: none !important; }
.ls-view-btn svg { width: 18px !important; height: 18px !important; display: block !important; margin: 0 !important; }
.ls-view-btn:hover { color: #6366f1 !important; }
.ls-view-btn.ls-active { background: #fff !important; color: #6366f1 !important; box-shadow: 0 1px 3px rgba(0,0,0,0.1) !important; }

/* Grid */
.ls-course-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; margin-bottom: 40px; transition: all 0.3s; }
.ls-course-grid.ls-list-view { grid-template-columns: 1fr; }

/* Cards */
.ls-card { background: #fff; border-radius: 12px; border: 1px solid #f1f5f9; overflow: hidden; transition: all 0.3s; display: flex; flex-direction: column; box-shadow: 0 4px 6px rgba(0,0,0,0.02); position: relative; }
.ls-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.06); border-color: #e2e8f0; }

.ls-list-view .ls-card { flex-direction: row; align-items: stretch; }

.ls-card-thumb { position: relative; height: 180px; width: 100%; flex-shrink: 0; background: #f8fafc; overflow: hidden; }
.ls-list-view .ls-card-thumb { width: 280px; height: auto; }
.ls-card-thumb img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; display: block; color: transparent; text-indent: -9999px; }
.ls-card:hover .ls-card-thumb img { transform: scale(1.05); }
.ls-card-thumb-fallback { width: 100%; height: 100%; background: linear-gradient(135deg, #e0e7ff, #c7d2fe); }

.ls-badge-bestseller { position: absolute; top: 12px; left: 12px; background: #4f46e5; color: #fff; font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 4px 8px; border-radius: 4px; letter-spacing: 0.5px; z-index: 1; }
.ls-catalog-wrap button.ls-bookmark-btn { position: absolute !important; top: 12px !important; right: 12px !important; background: rgba(255,255,255,0.9) !important; border: none !important; width: 32px !important; height: 32px !important; border-radius: 50% !important; display: flex !important; align-items: center !important; justify-content: center !important; cursor: pointer !important; color: #64748b !important; transition: all 0.2s !important; box-shadow: 0 2px 4px rgba(0,0,0,0.1) !important; z-index: 1 !important; padding: 0 !important; margin: 0 !important; min-width: auto !important; min-height: auto !important; outline: none !important; line-height: 1 !important; }
.ls-catalog-wrap button.ls-bookmark-btn svg { width: 16px !important; height: 16px !important; display: block !important; margin: 0 !important; }
.ls-catalog-wrap button.ls-bookmark-btn:hover { color: #4f46e5 !important; background: #fff !important; transform: scale(1.05) !important; }

.ls-card-content { padding: 20px 24px 16px; flex-grow: 1; display: flex; flex-direction: column; }
.ls-list-view .ls-card-content { padding: 24px; justify-content: center; border-bottom: none; }

.ls-card-cat { font-size: 10px; font-weight: 700; color: #8b5cf6; margin-bottom: 8px; display: block; letter-spacing: 0.5px; text-transform: uppercase; }
.ls-card-title { margin: 0 0 8px !important; font-size: 18px !important; font-weight: 700 !important; line-height: 1.3 !important; text-transform: none !important; }
.ls-card-title a { color: #0f172a !important; text-decoration: none !important; transition: color 0.2s; text-transform: none !important; font-size: 18px !important; }
.ls-card-title a:hover { color: #4f46e5 !important; }
.ls-card-excerpt { font-size: 14px; color: #64748b; margin: 0 0 16px; line-height: 1.5; flex-grow: 1; }

.ls-card-author-rating { display: flex; justify-content: space-between; align-items: center; margin-top: auto; }
.ls-card-author { display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 500; color: #475569; }
.ls-card-author img { width: 24px; height: 24px; border-radius: 50%; object-fit: cover; margin: 0 !important; padding: 0 !important; border: none !important; }
.ls-card-rating { font-size: 13px; font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 4px; }
.ls-star { color: #fbbf24; }
.ls-rating-count { color: #94a3b8; font-weight: 400; }

.ls-card-footer { padding: 16px 24px; border-top: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; background: #f8fafc; }
.ls-list-view .ls-card-footer { flex-direction: column; justify-content: center; border-top: none; border-left: 1px solid #f1f5f9; width: 180px; flex-shrink: 0; padding: 24px; background: #fff; }
.ls-card-meta { display: flex; gap: 12px; font-size: 12px; color: #64748b; font-weight: 500; }
.ls-card-meta span { display: flex; align-items: center; gap: 4px; white-space: nowrap; }
.ls-card-meta svg { width: 14px; height: 14px; }
.ls-list-view .ls-card-meta { flex-direction: column; gap: 8px; margin-bottom: 16px; align-items: flex-start; }

.ls-card-price { font-size: 18px; font-weight: 800; color: #4f46e5; }
.ls-card-price.ls-free { color: #10b981; }

/* Buttons & Load More */
.ls-load-more-wrap { text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #f1f5f9; }
.ls-catalog-wrap button.ls-btn-primary { display: inline-flex !important; align-items: center !important; justify-content: center !important; gap: 8px !important; background: #4f46e5 !important; color: #fff !important; border: none !important; padding: 12px 24px !important; border-radius: 8px !important; font-size: 14px !important; font-weight: 600 !important; cursor: pointer !important; transition: all 0.2s !important; box-shadow: 0 4px 6px rgba(79, 70, 229, 0.2) !important; margin: 0 auto !important; line-height: 1.5 !important; outline: none !important; height: auto !important; width: auto !important; }
.ls-catalog-wrap button.ls-btn-primary svg { width: 16px !important; height: 16px !important; display: block !important; margin: 0 !important; }
.ls-catalog-wrap button.ls-btn-primary:hover { background: #4338ca !important; transform: translateY(-1px) !important; box-shadow: 0 6px 12px rgba(79, 70, 229, 0.3) !important; }
.ls-catalog-wrap button.ls-btn-primary:active { transform: translateY(0) !important; }
.ls-catalog-wrap button.ls-btn-primary.ls-loading svg { animation: ls-spin 1s linear infinite; }
.ls-load-status { font-size: 13px; color: #64748b; margin-top: 12px; }

.ls-catalog-wrap button.ls-btn-secondary { display: inline-flex !important; align-items: center !important; justify-content: center !important; background: #fff !important; border: 1px solid #cbd5e1 !important; padding: 10px 20px !important; border-radius: 8px !important; font-weight: 600 !important; cursor: pointer !important; color: #475569 !important; transition: all 0.2s !important; margin: 0 auto !important; height: auto !important; width: auto !important; outline: none !important; }
.ls-catalog-wrap button.ls-btn-secondary:hover { border-color: #4f46e5 !important; color: #4f46e5 !important; }

@keyframes ls-spin { 100% { transform: rotate(360deg); } }

/* No Results */
.ls-no-results { text-align: center; padding: 60px 20px; background: #f8fafc; border-radius: 12px; border: 1px dashed #cbd5e1; }
.ls-no-results h3 { font-size: 20px; color: #0f172a; margin: 16px 0 8px; font-weight: 700; }
.ls-no-results p { color: #64748b; margin: 0 0 24px; }

/* Loading overlay for AJAX */
.ls-catalog-main { position: relative; min-height: 300px; transition: opacity 0.2s; }
.ls-catalog-main.ls-loading { opacity: 0.6; pointer-events: none; }

@media (max-width: 992px) {
	.ls-catalog-layout { grid-template-columns: 1fr; }
	.ls-catalog-sidebar { display: none; } /* On mobile, we would ideally add a filter toggle button, but for now we hide or show inline */
	.ls-list-view .ls-card { flex-direction: column; }
	.ls-list-view .ls-card-thumb { width: 100%; height: 180px; }
	.ls-list-view .ls-card-footer { width: 100%; border-left: none; border-top: 1px solid #f1f5f9; flex-direction: row; justify-content: space-between; }
	.ls-list-view .ls-card-meta { flex-direction: row; margin-bottom: 0; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
	const gridMain = document.getElementById('ls-catalog-main-content');
	const filterForm = document.getElementById('ls-courses-filter-form');
	const sortSelect = document.getElementById('ls-sort-select');
	const sortHidden = document.getElementById('ls_sort_hidden');
	let isFetching = false;

	if (!gridMain) return;

	// View Toggle logic
	function initViewToggles() {
		const grid = document.getElementById('ls-course-grid');
		const btns = document.querySelectorAll('.ls-view-btn');
		
		if (!grid || !btns.length) return;

		const savedView = localStorage.getItem('ls_course_view');
		if (savedView === 'list') {
			grid.classList.add('ls-list-view');
			btns[0].classList.remove('ls-active');
			btns[1].classList.add('ls-active');
		}

		btns.forEach(btn => {
			btn.addEventListener('click', function(e) {
				e.preventDefault();
				const view = this.getAttribute('data-view');
				
				btns.forEach(b => b.classList.remove('ls-active'));
				this.classList.add('ls-active');

				if (view === 'list') {
					grid.classList.add('ls-list-view');
					localStorage.setItem('ls_course_view', 'list');
				} else {
					grid.classList.remove('ls-list-view');
					localStorage.setItem('ls_course_view', 'grid');
				}
			});
		});
	}

	initViewToggles();

	// AJAX Fetch function
	async function fetchCourses(url, isLoadMore = false) {
		if (isFetching) return;
		isFetching = true;

		const loadBtn = document.getElementById('ls-load-more-btn');
		if (loadBtn && isLoadMore) {
			loadBtn.classList.add('ls-loading');
		} else {
			gridMain.classList.add('ls-loading');
		}

		try {
			const res = await fetch(url, {
				headers: { 'X-Requested-With': 'XMLHttpRequest' }
			});
			const html = await res.text();

			if (isLoadMore) {
				// Parse and append
				const parser = new DOMParser();
				const doc = parser.parseFromString(html, 'text/html');
				
				// Append new cards
				const newGrid = doc.getElementById('ls-course-grid');
				const currentGrid = document.getElementById('ls-course-grid');
				if (newGrid && currentGrid) {
					currentGrid.innerHTML += newGrid.innerHTML;
				}

				// Replace topbar and load more wrapper
				const newTopbar = doc.querySelector('.ls-catalog-topbar');
				if (newTopbar) document.querySelector('.ls-catalog-topbar').innerHTML = newTopbar.innerHTML;

				const newLoadWrap = doc.querySelector('.ls-load-more-wrap');
				const curLoadWrap = document.querySelector('.ls-load-more-wrap');
				if (newLoadWrap && curLoadWrap) {
					curLoadWrap.outerHTML = newLoadWrap.outerHTML;
				}

			} else {
				// Replace entirely
				gridMain.innerHTML = html;
			}
			
			// Reinitialize events on new elements
			initViewToggles();
			bindLoadMore();
			
			// (Removed window.history.pushState to keep URL purely clean during AJAX)

		} catch (e) {
			console.error('Failed to fetch courses', e);
		} finally {
			isFetching = false;
			gridMain.classList.remove('ls-loading');
			if (loadBtn && isLoadMore) loadBtn.classList.remove('ls-loading');
		}
	}

	// Bind Filter Form Change
	if (filterForm) {
		const inputs = filterForm.querySelectorAll('input');
		inputs.forEach(input => {
			input.addEventListener('change', function(e) {
				if(e.target.type === 'text') return; // let search happen on keyup or enter
				triggerFilter();
			});
		});

		const searchInput = filterForm.querySelector('input[name="ls_search"]');
		if (searchInput) {
			let debounceTimer;
			searchInput.addEventListener('keyup', function() {
				clearTimeout(debounceTimer);
				debounceTimer = setTimeout(triggerFilter, 500);
			});
			filterForm.addEventListener('submit', function(e) {
				e.preventDefault();
				triggerFilter();
			});
		}
	}

	function triggerFilter() {
		if (sortSelect) {
			sortHidden.value = sortSelect.value;
		}
		const formData = new FormData(filterForm);
		const params = new URLSearchParams(formData);
		const url = window.location.pathname + '?' + params.toString();
		fetchCourses(url, false);
	}

	// Bind Sort Select
	document.addEventListener('change', function(e) {
		if (e.target && e.target.id === 'ls-sort-select') {
			if (sortHidden) sortHidden.value = e.target.value;
			triggerFilter();
		}
	});

	// Bind Load More
	function bindLoadMore() {
		const loadBtn = document.getElementById('ls-load-more-btn');
		if (loadBtn) {
			loadBtn.addEventListener('click', function() {
				const nextPage = this.getAttribute('data-next-page');
				if (filterForm) {
					const formData = new FormData(filterForm);
					const params = new URLSearchParams(formData);
					params.set('paged', nextPage);
					const url = window.location.pathname + '?' + params.toString();
					fetchCourses(url, true);
				}
			});
		}
	}
	bindLoadMore();

	// Handle browser back/forward buttons
	window.addEventListener('popstate', function() {
		fetchCourses(window.location.href, false);
	});
});
</script>
