<?php
/**
 * Single Learnshapes Course Template – premium design.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $post;
$course_id = $post->ID;

// Retrieve price meta
$price = get_post_meta( $course_id, '_learnshapes_price', true );
$price_display = $price ? floatval( $price ) : 0;

// Offline Course Meta
$is_offline = get_post_meta( $course_id, '_ls_offline_enable', true ) === '1';
$offline_lessons = get_post_meta( $course_id, '_ls_offline_lessons', true );
$offline_delivery = get_post_meta( $course_id, '_ls_offline_delivery', true );
$offline_address = get_post_meta( $course_id, '_ls_offline_address', true );

$delivery_labels = [
    'private' => 'Private 1-1',
    'group' => 'Group Training',
    'classroom' => 'Classroom',
    'workshop' => 'Workshop',
    'seminar' => 'Seminar',
    'webinar' => 'Webinar',
    'zoom' => 'Zoom Live',
    'google_meet' => 'Google Meet',
    'hybrid' => 'Hybrid',
    'self_paced' => 'Self-Paced Offline'
];
$delivery_label = isset($delivery_labels[$offline_delivery]) ? $delivery_labels[$offline_delivery] : 'Offline Training';

// Student progress
$user_id = get_current_user_id();
$progress = 0;
$completed_lessons = 0;
$total_lessons = 0;

// Calculate total lessons from structure
$structure = get_post_meta( $course_id, '_learnshapes_course_structure', true );
if ( is_array( $structure ) ) {
    foreach ( $structure as $module ) {
        if ( ! empty( $module['items'] ) && is_array( $module['items'] ) ) {
            $total_lessons += count($module['items']);
        }
    }
}

if ( $user_id ) {
    global $wpdb;
    $table   = $wpdb->prefix . 'learnshapes_enrollments';
    $percent = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT progress_percent FROM $table WHERE user_id = %d AND course_id = %d",
            $user_id,
            $course_id
        )
    );
    $progress = $percent ? floatval( $percent ) : 0;
    $completed_lessons = round(($progress / 100) * $total_lessons); // Approximate for display
}

// Determine enrollment status
$is_enrolled = false;
if ( $user_id ) {
    $is_enrolled = (bool) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}learnshapes_enrollments WHERE user_id = %d AND course_id = %d AND status = 'active'",
            $user_id,
            $course_id
        )
    );
}

// Dynamic CTAs based on Online/Offline mode
if ( $is_offline ) {
    $cta_label = $is_enrolled ? apply_filters('ls_offline_enrolled_btn', __( 'Contact Instructor', 'learnshapes' )) : apply_filters('ls_offline_enroll_btn', __( 'Reserve Seat', 'learnshapes' ));
    $cta_action = $is_enrolled ? 'contact' : 'enroll';
} else {
    $cta_label = $is_enrolled ? __( 'Continue Lesson', 'learnshapes' ) : __( 'Enroll Now', 'learnshapes' );
    $cta_action = $is_enrolled ? 'continue' : 'enroll';
}

get_header(); ?>

<div class="ls-course-wrap">
    
    <!-- Top Bar Breadcrumbs -->
    <div class="ls-breadcrumbs">
        <a href="<?php echo esc_url( home_url('/courses') ); ?>"><?php esc_html_e('All Courses', 'learnshapes'); ?></a>
        <span class="sep">&gt;</span>
        <span class="current"><?php echo esc_html( get_the_title( $course_id ) ); ?></span>
    </div>

    <div class="ls-course-grid">
        <!-- Left Column -->
        <div class="ls-course-main">
            
            <!-- Course Header Card -->
            <div class="ls-course-header-card">
                <div class="ls-course-header-img" style="background-image:url('<?php echo esc_url( get_the_post_thumbnail_url( $course_id, 'large' ) ); ?>');">
                </div>
                <div class="ls-course-header-info">
                    <h1>
                        <?php echo esc_html( get_the_title( $course_id ) ); ?>
                        <?php if ( $is_offline ) : ?>
                            <span class="ls-badge-offline" style="background: #28a745; color: white; padding: 4px 8px; border-radius: 4px; font-size: 14px; font-weight: bold; margin-left: 10px; display: inline-block; vertical-align: middle;">Offline Training</span>
                        <?php endif; ?>
                    </h1>
                    <p class="ls-course-excerpt"><?php echo wp_kses_post( get_the_excerpt( $course_id ) ); ?></p>
                    
                    <?php if ( $is_offline ) : ?>
                        <!-- Offline Info Snippets -->
                        <div class="ls-offline-snippets" style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 15px;">
                            <span class="ls-snippet"><i class="dashicons dashicons-calendar-alt"></i> <?php echo esc_html($offline_lessons); ?> Sessions</span>
                            <span class="ls-snippet"><i class="dashicons dashicons-networking"></i> <?php echo esc_html($delivery_label); ?></span>
                            <?php if ( $offline_address ) : ?>
                                <span class="ls-snippet"><i class="dashicons dashicons-location"></i> <?php echo esc_html($offline_address); ?></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ( $is_enrolled && !$is_offline ) : ?>
                    <div class="ls-progress-inline" style="margin-top:20px;">
                        <span class="ls-progress-text"><strong><?php echo round($progress); ?>%</strong> Complete</span>
                        <div class="ls-progress-bar"><div class="ls-progress-fill" style="width:<?php echo esc_attr( $progress ); ?>%;"></div></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ( $is_offline ) : ?>
                <!-- Offline Training Card Component -->
                <div class="ls-offline-details-card" style="margin-top: 30px; padding: 25px; background: #fff; border-radius: 8px; border: 1px solid #e2e4e7; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                    <h3 style="margin-top:0; border-bottom: 2px solid #f0f0f1; padding-bottom: 10px; margin-bottom: 20px;">Training Information</h3>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div>
                            <p style="margin: 0 0 5px; color: #646970; font-size: 13px; text-transform: uppercase;">Delivery Format</p>
                            <p style="margin: 0; font-weight: 600; font-size: 16px;"><?php echo esc_html($delivery_label); ?></p>
                        </div>
                        <div>
                            <p style="margin: 0 0 5px; color: #646970; font-size: 13px; text-transform: uppercase;">Total Classes</p>
                            <p style="margin: 0; font-weight: 600; font-size: 16px;"><?php echo esc_html($offline_lessons); ?> Sessions</p>
                        </div>
                        <div style="grid-column: 1 / -1;">
                            <p style="margin: 0 0 5px; color: #646970; font-size: 13px; text-transform: uppercase;">Location / Meeting Link</p>
                            <?php if ( filter_var($offline_address, FILTER_VALIDATE_URL) ) : ?>
                                <a href="<?php echo esc_url($offline_address); ?>" target="_blank" class="ls-btn-secondary" style="display: inline-block; background: #f0f0f1; color: #1d2327; padding: 8px 15px; border-radius: 4px; text-decoration: none; font-weight: 600;"><span class="dashicons dashicons-video-alt3" style="vertical-align: middle; margin-right: 5px;"></span> Join Meeting Room</a>
                            <?php else: ?>
                                <p style="margin: 0; font-weight: 600; font-size: 16px;"><span class="dashicons dashicons-location-alt" style="vertical-align: middle;"></span> <?php echo esc_html($offline_address ?: 'TBA'); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( !$is_offline ) : ?>
            <!-- Curriculum Header (Only for Online) -->
            <div class="ls-curriculum-header" style="margin-top: 30px;">
                <a href="#" class="ls-expand-all"><?php esc_html_e('Expand All', 'learnshapes'); ?></a>
                <span class="sep">|</span>
                <a href="#" class="ls-collapse-all"><?php esc_html_e('Collapse All', 'learnshapes'); ?></a>
            </div>

            <!-- Curriculum Accordion -->
            <div class="ls-course-content-accordion">
                <?php
                if ( class_exists( '\\Learnshapes\\Renderer\\CurriculumRenderer' ) ) {
                    \\Learnshapes\\Renderer\\CurriculumRenderer::render( $course_id );
                }
                ?>
            </div>
            
            <!-- Topic Navigation -->
            <div class="ls-topic-nav">
                <div class="ls-nav-prev">
                    <a href="#"><span class="dashicons dashicons-arrow-left-alt2"></span> Previous Module</a>
                </div>
                <div class="ls-nav-next">
                    <a href="#">Next Module <span class="dashicons dashicons-arrow-right-alt2"></span></a>
                </div>
            </div>
            <?php endif; ?>

            <?php
            // Extra course info meta
            $ls_level        = get_post_meta( $course_id, '_ls_level', true ) ?: 'all';
            $ls_key_features = get_post_meta( $course_id, '_ls_key_features', true );
            $ls_requirements = get_post_meta( $course_id, '_ls_target_audience', true );
            $ls_cert         = get_post_meta( $course_id, '_ls_assigned_certificate', true );
            $duration_val    = get_post_meta( $course_id, '_ls_duration', true ) ?: '0';
            $duration_type   = get_post_meta( $course_id, '_ls_duration_type', true ) ?: 'week';
            $level_labels    = ['all'=>'All Levels','beginner'=>'Beginner','intermediate'=>'Intermediate','expert'=>'Expert'];
            $level_label     = $level_labels[$ls_level] ?? 'All Levels';
            $access_label    = ($duration_val == 0) ? 'Lifetime Access' : $duration_val . ' ' . ucfirst($duration_type) . '(s)';
            if ( !$is_offline ) :
            ?>

            <!-- About This Course -->
            <div class="ls-about-course" style="margin-top:35px; padding:28px; background:#fff; border-radius:12px; border:1px solid #eaecf0;">
                <h2 style="margin:0 0 10px; font-size:20px; font-weight:700;">About This Course</h2>
                <p style="color:#555; margin-bottom:24px; line-height:1.7;"><?php echo wp_kses_post( get_the_excerpt($course_id) ?: get_the_content(null, false, $course_id) ); ?></p>

                <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:16px; text-align:center; margin-top:10px;">
                    <?php
                    $meta_icons = [
                        ['icon'=>'📊', 'label'=>$level_label,      'sub'=>'No prior experience required'],
                        ['icon'=>'📘', 'label'=>$total_lessons.' Lesson'.($total_lessons!=1?'s':''), 'sub'=>'Self-paced learning'],
                        ['icon'=>'🏅', 'label'=>$ls_cert ? 'Certificate' : 'No Certificate', 'sub'=>$ls_cert ? 'Earn a certificate on completion' : ''],
                        ['icon'=>'♾',  'label'=>$access_label,     'sub'=>'Learn anytime, anywhere'],
                    ];
                    foreach ( $meta_icons as $mi ) :
                    ?>
                    <div style="background:#f7f8ff; border-radius:10px; padding:16px 10px;">
                        <div style="font-size:28px; margin-bottom:8px;"><?php echo $mi['icon']; ?></div>
                        <strong style="display:block; font-size:13px; color:#1d2327;"><?php echo esc_html($mi['label']); ?></strong>
                        <?php if ( $mi['sub'] ) : ?><span style="font-size:11px; color:#888;"><?php echo esc_html($mi['sub']); ?></span><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ( $ls_key_features ) : $features = array_filter(explode("\n", $ls_key_features)); ?>
            <!-- What You'll Learn -->
            <div class="ls-what-learn" style="margin-top:24px; padding:28px; background:#fff; border-radius:12px; border:1px solid #eaecf0;">
                <h2 style="margin:0 0 20px; font-size:20px; font-weight:700;">What You'll Learn</h2>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                    <?php foreach ( $features as $f ) : ?>
                    <div style="display:flex; align-items:flex-start; gap:10px;">
                        <span style="color:#6366f1; font-size:18px; flex-shrink:0; margin-top:1px;">✓</span>
                        <span style="font-size:14px; color:#374151; line-height:1.5;"><?php echo esc_html(trim($f)); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ( $ls_requirements ) : ?>
            <!-- Who Is This Course For -->
            <div class="ls-who-for" style="margin-top:24px; padding:22px 28px; background:linear-gradient(135deg,#eef2ff 0%,#f0fdf4 100%); border-radius:12px; border:1px solid #e0e7ff; display:flex; gap:18px; align-items:flex-start;">
                <div style="width:44px; height:44px; background:#6366f1; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">💡</div>
                <div>
                    <h3 style="margin:0 0 6px; font-size:16px; font-weight:700;">Who Is This Course For?</h3>
                    <p style="margin:0; color:#4b5563; font-size:14px; line-height:1.6;"><?php echo esc_html($ls_requirements); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Topic Navigation -->
            <div class="ls-topic-nav" style="margin-top:24px;">
                <div class="ls-nav-prev"><a href="#"><span class="dashicons dashicons-arrow-left-alt2"></span> Previous Module</a></div>
                <div class="ls-nav-next"><a href="#">Next Module <span class="dashicons dashicons-arrow-right-alt2"></span></a></div>
            </div>
            <?php endif; ?>

        </div>

        <!-- Right Column / Sidebar -->
        <div class="ls-course-sidebar">

            <?php if ( $is_enrolled && !$is_offline ) : ?>
            <div class="ls-sidebar-card ls-progress-card">
                <h3><?php esc_html_e('Course Progress', 'learnshapes'); ?></h3>
                <p class="ls-progress-percent"><strong><?php echo round($progress); ?>%</strong> Complete</p>
                <div class="ls-progress-bar"><div class="ls-progress-fill" style="width:<?php echo esc_attr($progress); ?>%;"></div></div>
                <p class="ls-lessons-completed"><?php printf('%d / %d Lessons Completed', $completed_lessons, $total_lessons); ?></p>
            </div>
            <?php endif; ?>

            <?php if ( !$is_offline ) : ?>
            <div class="ls-sidebar-card ls-content-sidebar">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:15px;">
                    <span style="font-size:20px;">📋</span>
                    <h3 style="margin:0; font-size:16px; font-weight:700;"><?php esc_html_e('Course Content', 'learnshapes'); ?></h3>
                </div>
                <ul class="ls-sidebar-nav-list">
                    <?php if ( is_array($structure) ) foreach ($structure as $mod) {
                        echo '<li><a href="#module-'.esc_attr($mod['id']).'">'.esc_html($mod['title']).'<span class="dashicons dashicons-arrow-right-alt2"></span></a></li>';
                    } ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Enrollment Card -->
            <div class="ls-sidebar-card ls-enroll-card" style="border:1px solid #e0e7ff; background:#fff; border-radius:14px; padding:24px; margin-bottom:18px;">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
                    <span style="width:36px; height:36px; background:#eef2ff; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:18px;">🎓</span>
                    <h3 style="margin:0; font-size:16px; font-weight:700;"><?php echo $is_offline ? 'Registration' : 'Enrollment'; ?></h3>
                </div>
                <?php if ( $price_display > 0 && !$is_enrolled ) : ?>
                    <div style="font-size:28px; font-weight:800; color:#1d2327; margin-bottom:6px;">$<?php echo number_format_i18n($price_display, 2); ?></div>
                    <p style="font-size:13px; color:#6b7280; margin:0 0 18px;">This course requires a one-time payment.</p>
                <?php elseif ( $is_enrolled ) : ?>
                    <p style="color:#16a34a; font-weight:600; margin-bottom:14px;">✓ You are enrolled</p>
                <?php else : ?>
                    <p style="color:#16a34a; font-weight:600; margin-bottom:14px; font-size:15px;">Free</p>
                <?php endif; ?>
                <button class="ls-btn-primary" id="ls-course-action" data-action="<?php echo esc_attr($cta_action); ?>" data-course-id="<?php echo esc_attr($course_id); ?>" style="width:100%; padding:13px; font-size:15px; font-weight:700; border-radius:8px; background:#6366f1; border:none; color:#fff; cursor:pointer;">
                    <?php echo esc_html($cta_label); ?>
                </button>
                <?php if ( $is_offline ) : ?>
                <p style="margin-top:10px; font-size:11px; color:#9ca3af; text-align:center;">By reserving, you agree to our training policies.</p>
                <?php endif; ?>
            </div>

            <!-- Learn At Your Own Pace Card -->
            <div class="ls-sidebar-card" style="border:1px solid #e0e7ff; background:#fff; border-radius:14px; padding:22px; margin-bottom:18px; display:flex; gap:14px; align-items:flex-start;">
                <span style="width:40px; height:40px; background:linear-gradient(135deg,#6366f1,#8b5cf6); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">⭐</span>
                <div>
                    <h4 style="margin:0 0 6px; font-size:15px; font-weight:700;">Learn At Your Own Pace</h4>
                    <p style="margin:0; font-size:13px; color:#6b7280; line-height:1.5;">Start learning anytime and access course materials 24/7.</p>
                </div>
            </div>

            <?php if ( $ls_cert ) : ?>
            <div class="ls-sidebar-card" style="border:1px solid #d1fae5; background:#f0fdf4; border-radius:14px; padding:22px; display:flex; gap:14px; align-items:flex-start;">
                <span style="font-size:28px;">🏅</span>
                <div>
                    <h4 style="margin:0 0 4px; font-size:15px; font-weight:700;">Certificate of Completion</h4>
                    <p style="margin:0; font-size:13px; color:#6b7280;">Earn your certificate after completing all course requirements.</p>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
