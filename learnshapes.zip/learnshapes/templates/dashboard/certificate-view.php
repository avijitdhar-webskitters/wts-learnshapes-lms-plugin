<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$cert_id = isset( $_GET['ls_certificate'] ) ? (int) $_GET['ls_certificate'] : 0;
$course_id = isset( $_GET['course_id'] ) ? (int) $_GET['course_id'] : 0;

if ( ! $cert_id || get_post_type( $cert_id ) !== 'ls_certificate' ) {
    wp_die( 'Invalid Certificate.' );
}

$bg_image_id = get_post_meta( $cert_id, '_ls_cert_bg_id', true );
$bg_image_url = $bg_image_id ? wp_get_attachment_url( $bg_image_id ) : '';

$elements_json = get_post_meta( $cert_id, '_ls_cert_elements', true );
$elements = json_decode( $elements_json, true );
if ( ! is_array( $elements ) ) {
    $elements = [];
}

// Variables replacement
$course_name = $course_id ? get_the_title( $course_id ) : 'Course Name';
$student_name = wp_get_current_user()->display_name;
$current_time = date_i18n( get_option( 'date_format' ) );

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Certificate - <?php echo esc_attr( $course_name ); ?></title>
    <style>
        body {
            background: #f1f1f1;
            margin: 0;
            padding: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: sans-serif;
        }
        .cert-container {
            width: 800px;
            height: 600px;
            background-color: #fff;
            background-size: cover;
            background-position: center;
            position: relative;
            box-shadow: 0 0 20px rgba(0,0,0,0.15);
        }
        .cert-element {
            position: absolute;
            display: flex;
            align-items: center;
            overflow: hidden;
        }
        @media print {
            body { background: none; padding: 0; }
            .no-print { display: none; }
            .cert-container { box-shadow: none; }
            @page { margin: 0; size: landscape; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; font-size: 16px; cursor: pointer;">Print Certificate</button>
    </div>

    <div class="cert-container" style="<?php echo $bg_image_url ? "background-image: url('" . esc_url($bg_image_url) . "');" : ""; ?>">
        <?php foreach ( $elements as $el ) : 
            $text = $el['text'];
            
            // Replace tags
            if ( $el['type'] === 'course_name' ) $text = $course_name;
            if ( $el['type'] === 'student_name' ) $text = $student_name;
            if ( $el['type'] === 'current_time' ) $text = $current_time;
            if ( $el['type'] === 'course_start_date' ) $text = 'Started on Date'; // Mock
            if ( $el['type'] === 'course_end_date' ) $text = 'Completed on Date'; // Mock

            $style = sprintf(
                'left: %dpx; top: %dpx; width: %dpx; height: %dpx; font-size: %dpx; color: %s; font-family: %s; text-align: %s; justify-content: %s;',
                $el['x'], $el['y'], $el['width'], $el['height'], $el['fontSize'], $el['color'], $el['fontFamily'], $el['textAlign'],
                $el['textAlign'] === 'center' ? 'center' : ($el['textAlign'] === 'right' ? 'flex-end' : 'flex-start')
            );
        ?>
            <div class="cert-element" style="<?php echo esc_attr( $style ); ?>">
                <?php if ( $el['type'] === 'qr_code' ) : ?>
                    <!-- Mock QR code -->
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo urlencode( get_site_url() . '?ls_certificate=' . $cert_id . '&course_id=' . $course_id ); ?>" style="width:100%; height:100%; object-fit: contain;">
                <?php else : ?>
                    <span style="width: 100%;"><?php echo esc_html( $text ); ?></span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
