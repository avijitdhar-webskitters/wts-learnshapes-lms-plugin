<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="learnshapes-login-box">
	<div style="text-align:center; margin-bottom:20px; color:var(--ls-primary);">
		<span class="dashicons dashicons-welcome-learn-more" style="font-size:40px; width:40px; height:40px;"></span>
	</div>
	<h2><?php esc_html_e( 'Student Portal Sign In', 'learnshapes' ); ?></h2>
	<p style="text-align:center; color:var(--ls-text-muted); font-size:13px; margin-bottom:24px;">
		<?php esc_html_e( 'Please sign in to access your course list, track progress, and view earned certificates.', 'learnshapes' ); ?>
	</p>

	<form name="loginform" id="loginform" action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
		<div class="form-group">
			<label for="user_login"><?php esc_html_e( 'Username or Email Address', 'learnshapes' ); ?></label>
			<input type="text" name="log" id="user_login" class="input" required />
		</div>

		<div class="form-group">
			<label for="user_pass"><?php esc_html_e( 'Password', 'learnshapes' ); ?></label>
			<input type="password" name="pwd" id="user_pass" class="input" required />
		</div>

		<div class="form-group" style="display:flex; justify-content:space-between; align-items:center; margin: 15px 0 25px 0;">
			<label style="font-weight:normal; font-size:13px; cursor:pointer;">
				<input name="rememberme" type="checkbox" id="rememberme" value="forever" /> <?php esc_html_e( 'Remember Me', 'learnshapes' ); ?>
			</label>
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" style="font-size:13px; text-decoration:none; color:var(--ls-primary);"><?php esc_html_e( 'Forgot Password?', 'learnshapes' ); ?></a>
		</div>

		<input type="hidden" name="redirect_to" value="<?php echo esc_url( get_permalink() ); ?>" />
		<button type="submit" name="wp-submit" id="wp-submit" class="widget-btn"><?php esc_html_e( 'Log In', 'learnshapes' ); ?></button>
	</form>

	<?php if ( get_option( 'users_can_register' ) ) : ?>
		<div style="text-align:center; margin-top:24px; border-top: 1px solid var(--ls-border); padding-top:20px;">
			<span style="font-size:13px; color:var(--ls-text-muted);"><?php esc_html_e( "Don't have an account?", 'learnshapes' ); ?></span>
			<a href="<?php echo esc_url( wp_registration_url() ); ?>" style="font-size:13px; text-decoration:none; color:var(--ls-primary); font-weight:bold; margin-left:6px;"><?php esc_html_e( 'Sign Up', 'learnshapes' ); ?></a>
		</div>
	<?php endif; ?>
</div>
