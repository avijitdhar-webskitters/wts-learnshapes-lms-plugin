<?php
/**
 * Template: Student My Courses
 *
 * Displays a list of courses the logged-in student is enrolled in,
 * with progress bars and quick‑start links.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

global $wpdb;
$user_id = get_current_user_id();
if ( ! $user_id ) {
    echo '<p class="learnshapes-login-box">' . esc_html__( 'Please log in to view your courses.', 'learnshapes' ) . '</p>';
    return;
}

// Fetch enrolled courses.
$courses = $wpdb->get_results( $wpdb->prepare(
    "SELECT c.* FROM {$wpdb->prefix}learnshapes_enrollments e JOIN {$wpdb->posts} c ON e.course_id = c.ID WHERE e.user_id = %d AND c.post_type = 'learnshapes_course'",
    $user_id
) );

if ( empty( $courses ) ) {
    echo '<p class="learnshapes-login-box">' . esc_html__( 'You are not enrolled in any courses yet.', 'learnshapes' ) . '</p>';
    return;
}
?>
<div class="learnshapes-grid" style="--columns: 2;">
<?php foreach ( $courses as $course ) : ?>
    <?php
    $course_id   = $course->ID;
    $title       = get_the_title( $course_id );
    $price       = get_post_meta( $course_id, '_learnshapes_price', true );
    $price_text  = empty( $price ) ? __( 'Free', 'learnshapes' ) : '$' . number_format( floatval( $price ), 2 );
    // Fetch progress percent (0‑100).
    $progress    = $wpdb->get_var( $wpdb->prepare(
        "SELECT progress_percent FROM {$wpdb->prefix}learnshapes_progress WHERE user_id = %d AND course_id = %d",
        $user_id,
        $course_id
    ) );
    $progress    = $progress ? intval( $progress ) : 0;
    ?>
    <div class="learnshapes-course-card">
        <div class="course-card-content">
            <h4><?php echo esc_html( $title ); ?></h4>
            <div class="course-card-meta">
                <span class="course-price <?php echo $price ? '' : 'free'; ?>"><?php echo esc_html( $price_text ); ?></span>
                <a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="course-btn"><?php esc_html_e( 'View', 'learnshapes' ); ?></a>
            </div>
        </div>
        <div class="course-card-progress">
            <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: <?php echo $progress; ?>%;"></div></div>
            <div class="progress-label"><span><?php esc_html_e( 'Progress', 'learnshapes' ); ?></span> <span><?php echo $progress; ?>%</span></div>
        </div>
    </div>
<?php endforeach; ?>
</div>
