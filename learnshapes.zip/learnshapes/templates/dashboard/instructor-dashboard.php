<?php
if ( ! defined( 'ABSPATH' ) ) exit;

wp_enqueue_style( 'learnshapes-dashboard-css', LEARNSHAPES_URL . 'assets/css/dashboard-frontend.css', [], time() );

$current_user = wp_get_current_user();
?>
<div class="ls-dashboard-wrapper">
    <!-- Sidebar -->
    <div class="ls-sidebar">
        <div class="ls-sidebar-logo">
            <span class="dashicons dashicons-chart-area"></span> LearnDash
        </div>
        <ul class="ls-sidebar-menu">
            <li class="active"><a href="#" data-target="tab-dashboard"><span class="dashicons dashicons-admin-home"></span> Dashboard</a></li>
            <li><a href="#" data-target="tab-courses"><span class="dashicons dashicons-welcome-learn-more"></span> Courses</a></li>
            <li><a href="#" data-target="tab-lessons"><span class="dashicons dashicons-media-document"></span> Lessons</a></li>
            <li><a href="#" data-target="tab-topics"><span class="dashicons dashicons-category"></span> Topics</a></li>
            <li><a href="#" data-target="tab-quizzes"><span class="dashicons dashicons-format-aside"></span> Quizzes</a></li>
            <li><a href="#" data-target="tab-assignments"><span class="dashicons dashicons-clipboard"></span> Assignments</a></li>
            <li><a href="#" data-target="tab-students"><span class="dashicons dashicons-groups"></span> Students</a></li>
            <li><a href="#" data-target="tab-certificates"><span class="dashicons dashicons-awards"></span> Certificates</a></li>
            <li><a href="#" data-target="tab-reports"><span class="dashicons dashicons-chart-bar"></span> Reports</a></li>
            <li><a href="#" data-target="tab-messages"><span class="dashicons dashicons-email"></span> Messages</a></li>
            <li><a href="#" data-target="tab-profile"><span class="dashicons dashicons-admin-users"></span> Profile</a></li>
            <li><a href="#" data-target="tab-settings"><span class="dashicons dashicons-admin-generic"></span> Settings</a></li>
        </ul>
        <div class="ls-sidebar-bottom">
            <a href="#"><span class="dashicons dashicons-editor-help"></span> Help Center</a>
            <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>"><span class="dashicons dashicons-migrate"></span> Logout</a>
            <div class="ls-user-profile">
                <img src="<?php echo esc_url( get_avatar_url( $current_user->ID ) ); ?>" alt="User">
                <div class="ls-user-profile-info">
                    <strong><?php echo esc_html( $current_user->display_name ); ?></strong>
                    <span><?php echo esc_html( $current_user->user_email ); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="ls-main-content">
        <!-- TAB: Dashboard (Overview) -->
        <div id="tab-dashboard" class="ls-tab-pane active">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Welcome back, <?php echo esc_html( $current_user->first_name ?: $current_user->display_name ); ?>! 👋</h1>
                    <p>Here's what's happening with your courses today.</p>
                </div>
                <div class="ls-top-actions">
                    <a href="<?php echo admin_url('post-new.php?post_type=learnshapes_course'); ?>" class="ls-btn-new">
                        <span class="dashicons dashicons-plus"></span> Add New
                    </a>
                    <div class="ls-notification-bell">
                        <span class="dashicons dashicons-bell"></span>
                        <span class="ls-badge">1</span>
                    </div>
                </div>
            </div>

            <!-- Metrics -->
            <div class="ls-metrics-grid">
                <div class="ls-metric-card">
                    <div class="ls-metric-info" style="flex:1;">
                        <h4>Total Students</h4>
                        <p class="ls-metric-val">1,248</p>
                        <span class="ls-metric-sub">+12% this month</span>
                    </div>
                    <div class="ls-metric-icon green" style="background:transparent; color:#10b981;"><span class="dashicons dashicons-chart-line"></span></div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-info" style="flex:1;">
                        <h4>Courses</h4>
                        <p class="ls-metric-val">8</p>
                        <span class="ls-metric-sub">+1 this month</span>
                    </div>
                    <div class="ls-metric-icon green" style="background:transparent; color:#10b981;"><span class="dashicons dashicons-chart-line"></span></div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-info" style="flex:1;">
                        <h4>Lessons</h4>
                        <p class="ls-metric-val">68</p>
                        <span class="ls-metric-sub">+4 this month</span>
                    </div>
                    <div class="ls-metric-icon green" style="background:transparent; color:#10b981;"><span class="dashicons dashicons-chart-line"></span></div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-info" style="flex:1;">
                        <h4>Revenue</h4>
                        <p class="ls-metric-val">$4,520</p>
                        <span class="ls-metric-sub">+18% this month</span>
                    </div>
                    <div class="ls-metric-icon green" style="background:transparent; color:#10b981;"><span class="dashicons dashicons-chart-line"></span></div>
                </div>
            </div>

            <!-- Course Overview Table -->
            <div class="ls-section">
                <div class="ls-section-header">
                    <h3>Course Overview</h3>
                </div>
                <div class="ls-table-card">
                    <table class="ls-table">
                        <thead>
                            <tr>
                                <th>Course</th>
                                <th>Students</th>
                                <th>Lessons</th>
                                <th>Completion Rate</th>
                                <th>Revenue</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Digital Marketing Mastery</strong></td>
                                <td>455</td>
                                <td>20</td>
                                <td>65%</td>
                                <td>$2,450</td>
                                <td><span class="ls-status-badge published">Published</span></td>
                            </tr>
                            <tr>
                                <td><strong>Web Development Fundamentals</strong></td>
                                <td>312</td>
                                <td>18</td>
                                <td>48%</td>
                                <td>$1,250</td>
                                <td><span class="ls-status-badge published">Published</span></td>
                            </tr>
                            <tr>
                                <td><strong>SEO Fundamentals</strong></td>
                                <td>210</td>
                                <td>12</td>
                                <td>35%</td>
                                <td>$820</td>
                                <td><span class="ls-status-badge published">Published</span></td>
                            </tr>
                            <tr>
                                <td><strong>Content Writing Masterclass</strong></td>
                                <td>170</td>
                                <td>10</td>
                                <td>72%</td>
                                <td>$0</td>
                                <td><span class="ls-status-badge draft">Draft</span></td>
                            </tr>
                            <tr>
                                <td><strong>Social Media Marketing</strong></td>
                                <td>100</td>
                                <td>8</td>
                                <td>30%</td>
                                <td>$0</td>
                                <td><span class="ls-status-badge draft">Draft</span></td>
                            </tr>
                        </tbody>
                    </table>
                    <div style="padding: 16px; text-align: center; border-top: 1px solid #edf2f7;">
                        <a href="#" class="ls-view-all">View All Courses</a>
                    </div>
                </div>
            </div>

            <div class="ls-dashboard-grid-2col">
                <!-- Left Col (Charts) -->
                <div>
                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Students Activity</h3>
                        </div>
                        <div class="ls-chart-card">
                            <canvas id="ls-instructor-activity-chart" class="ls-chart-container"></canvas>
                        </div>
                    </div>

                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Recent Students</h3>
                        </div>
                        <div class="ls-chart-card">
                            <ul class="ls-students-list">
                                <li>
                                    <img src="https://ui-avatars.com/api/?name=Dianne+Russell&background=random" alt="Avatar">
                                    <div class="ls-student-info">
                                        <strong>Dianne Russell</strong>
                                        <span>Enrolled in Digital Marketing Mastery</span>
                                    </div>
                                    <div class="ls-student-time">2 hours ago</div>
                                </li>
                                <li>
                                    <img src="https://ui-avatars.com/api/?name=Cody+Fisher&background=random" alt="Avatar">
                                    <div class="ls-student-info">
                                        <strong>Cody Fisher</strong>
                                        <span>Completed Lesson: 1.2 Importance of SEO</span>
                                    </div>
                                    <div class="ls-student-time">5 hours ago</div>
                                </li>
                                <li>
                                    <img src="https://ui-avatars.com/api/?name=Guy+Hawkins&background=random" alt="Avatar">
                                    <div class="ls-student-info">
                                        <strong>Guy Hawkins</strong>
                                        <span>Enrolled in Web Development Fundamentals</span>
                                    </div>
                                    <div class="ls-student-time">1 day ago</div>
                                </li>
                            </ul>
                            <div style="text-align: center; margin-top: 16px;">
                                <a href="#" class="ls-view-all">View All Students</a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Col (Donut Chart & Notifications) -->
                <div>
                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Content Summary</h3>
                        </div>
                        <div class="ls-chart-card">
                            <canvas id="ls-instructor-content-chart" style="height: 200px; width: 100%;"></canvas>
                            <div style="text-align: center; margin-top: 16px;">
                                <a href="#" class="ls-view-all">View All Content</a>
                            </div>
                        </div>
                    </div>

                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Recent Notifications</h3>
                        </div>
                        <div class="ls-chart-card">
                            <ul class="ls-students-list">
                                <li>
                                    <div class="ls-student-info">
                                        <strong><span class="dashicons dashicons-admin-users" style="font-size:16px;"></span> New student enrolled in Digital Marketing Mastery</strong>
                                    </div>
                                    <div class="ls-student-time">2 hours ago</div>
                                </li>
                                <li>
                                    <div class="ls-student-info">
                                        <strong><span class="dashicons dashicons-yes" style="font-size:16px;"></span> Lesson 1.3 in SEO Fundamentals marked as complete by 3 students</strong>
                                    </div>
                                    <div class="ls-student-time">5 hours ago</div>
                                </li>
                                <li>
                                    <div class="ls-student-info">
                                        <strong><span class="dashicons dashicons-star-filled" style="font-size:16px;"></span> New review received for Digital Marketing Mastery</strong>
                                    </div>
                                    <div class="ls-student-time">1 day ago</div>
                                </li>
                            </ul>
                            <div style="text-align: center; margin-top: 16px;">
                                <a href="#" class="ls-view-all">View All Notifications</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB: Courses -->
        <div id="tab-courses" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Courses</h1>
                    <p>Manage your created courses.</p>
                </div>
                <div class="ls-top-actions">
                    <a href="<?php echo admin_url('post-new.php?post_type=learnshapes_course'); ?>" class="ls-btn-new">
                        <span class="dashicons dashicons-plus"></span> Add New
                    </a>
                </div>
            </div>
            <div class="ls-side-card"><p>Course management interface will appear here.</p></div>
        </div>

        <!-- TAB: Lessons -->
        <div id="tab-lessons" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Lessons</h1></div>
            </div>
            <div class="ls-side-card"><p>Lessons management interface will appear here.</p></div>
        </div>

        <!-- TAB: Topics -->
        <div id="tab-topics" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Topics</h1></div>
            </div>
            <div class="ls-side-card"><p>Topics management interface will appear here.</p></div>
        </div>

        <!-- TAB: Quizzes -->
        <div id="tab-quizzes" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Quizzes</h1></div>
            </div>
            <div class="ls-side-card"><p>Quizzes management interface will appear here.</p></div>
        </div>

        <!-- TAB: Assignments -->
        <div id="tab-assignments" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Assignments</h1></div>
            </div>
            <div class="ls-side-card"><p>Assignments management interface will appear here.</p></div>
        </div>

        <!-- TAB: Students -->
        <div id="tab-students" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Students</h1></div>
            </div>
            <div class="ls-side-card"><p>Students management interface will appear here.</p></div>
        </div>

        <!-- TAB: Certificates -->
        <div id="tab-certificates" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Certificates</h1></div>
            </div>
            <div class="ls-side-card"><p>Certificates management interface will appear here.</p></div>
        </div>

        <!-- TAB: Reports -->
        <div id="tab-reports" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Reports</h1></div>
            </div>
            <div class="ls-side-card"><p>Reports interface will appear here.</p></div>
        </div>

        <!-- TAB: Messages -->
        <div id="tab-messages" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Messages</h1></div>
            </div>
            <div class="ls-side-card"><p>Messages interface will appear here.</p></div>
        </div>

        <!-- TAB: Profile -->
        <div id="tab-profile" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Profile</h1></div>
            </div>
            <div class="ls-side-card" style="text-align: left;">
                <p><strong>Name:</strong> <?php echo esc_html( $current_user->display_name ); ?></p>
                <p><strong>Email:</strong> <?php echo esc_html( $current_user->user_email ); ?></p>
                <a href="#" class="ls-btn-sm">Edit Profile</a>
            </div>
        </div>

        <!-- TAB: Settings -->
        <div id="tab-settings" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text"><h1>Settings</h1></div>
            </div>
            <div class="ls-side-card" style="text-align: left;">
                <p><strong>Instructor Notifications:</strong> Enabled</p>
                <a href="#" class="ls-btn-sm">Update Settings</a>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching logic
    const menuLinks = document.querySelectorAll('.ls-sidebar-menu a[data-target]');
    const tabPanes = document.querySelectorAll('.ls-tab-pane');

    menuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('data-target');
            
            // Update active menu item
            document.querySelectorAll('.ls-sidebar-menu li').forEach(li => li.classList.remove('active'));
            this.closest('li').classList.add('active');

            // Show target pane
            tabPanes.forEach(pane => {
                if(pane.id === targetId) {
                    pane.style.display = 'block';
                } else {
                    pane.style.display = 'none';
                }
            });
        });
    });

    // Hide all tabs except the active one on load
    tabPanes.forEach(pane => {
        if(!pane.classList.contains('active')) {
            pane.style.display = 'none';
        }
    });

    if (typeof Chart !== 'undefined') {
        const ctxActivity = document.getElementById('ls-instructor-activity-chart');
        if (ctxActivity) {
            new Chart(ctxActivity, {
                type: 'line',
                data: {
                    labels: ['May 1', 'May 8', 'May 15', 'May 22', 'May 29'],
                    datasets: [{
                        label: 'Students',
                        data: [200, 400, 300, 500, 600],
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 800 } } }
            });
        }

        const ctxContent = document.getElementById('ls-instructor-content-chart');
        if (ctxContent) {
            new Chart(ctxContent, {
                type: 'doughnut',
                data: {
                    labels: ['Published', 'Draft', 'Pending Review'],
                    datasets: [{
                        data: [45, 15, 8],
                        backgroundColor: ['#3b82f6', '#f59e0b', '#ef4444'],
                        borderWidth: 0
                    }]
                },
                options: { 
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: { 
                        legend: { position: 'right' } 
                    } 
                }
            });
        }
    }
});
</script>
