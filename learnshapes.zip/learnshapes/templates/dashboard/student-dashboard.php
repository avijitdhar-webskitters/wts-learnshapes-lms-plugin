<?php
if ( ! defined( 'ABSPATH' ) ) exit;

wp_enqueue_style( 'learnshapes-dashboard-css', LEARNSHAPES_URL . 'assets/css/dashboard-frontend.css', [], time() );

$current_user = wp_get_current_user();
?>
<div class="ls-dashboard-wrapper">
    <!-- Sidebar -->
    <div class="ls-sidebar">
        <div class="ls-sidebar-logo">
            <span class="dashicons dashicons-chart-area"></span> LearnDash
        </div>
        <ul class="ls-sidebar-menu">
            <li class="active"><a href="#" data-target="tab-dashboard"><span class="dashicons dashicons-admin-home"></span> Dashboard</a></li>
            <li><a href="#" data-target="tab-courses"><span class="dashicons dashicons-welcome-learn-more"></span> My Courses</a></li>
            <li><a href="#" data-target="tab-certificates"><span class="dashicons dashicons-awards"></span> Certificates</a></li>
            <li><a href="#" data-target="tab-achievements"><span class="dashicons dashicons-star-filled"></span> Achievements</a></li>
            <li><a href="#" data-target="tab-wishlist"><span class="dashicons dashicons-heart"></span> Wishlist</a></li>
            <li><a href="#" data-target="tab-messages"><span class="dashicons dashicons-email"></span> Messages</a></li>
            <li><a href="#" data-target="tab-profile"><span class="dashicons dashicons-admin-users"></span> Profile</a></li>
            <li><a href="#" data-target="tab-settings"><span class="dashicons dashicons-admin-generic"></span> Settings</a></li>
        </ul>
        <div class="ls-sidebar-bottom">
            <a href="#"><span class="dashicons dashicons-editor-help"></span> Help Center</a>
            <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>"><span class="dashicons dashicons-migrate"></span> Logout</a>
            <div class="ls-user-profile">
                <img src="<?php echo esc_url( get_avatar_url( $current_user->ID ) ); ?>" alt="User">
                <div class="ls-user-profile-info">
                    <strong><?php echo esc_html( $current_user->display_name ); ?></strong>
                    <span><?php echo esc_html( $current_user->user_email ); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="ls-main-content">
        <!-- TAB: Dashboard (Overview) -->
        <div id="tab-dashboard" class="ls-tab-pane active">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Welcome back, <?php echo esc_html( $current_user->first_name ?: $current_user->display_name ); ?>! 👋</h1>
                    <p>Ready to continue your learning journey?</p>
                </div>
                <div class="ls-top-actions">
                    <div class="ls-notification-bell">
                        <span class="dashicons dashicons-bell"></span>
                        <span class="ls-badge">2</span>
                    </div>
                </div>
            </div>

            <!-- Metrics -->
            <div class="ls-metrics-grid">
                <div class="ls-metric-card">
                    <div class="ls-metric-icon"><span class="dashicons dashicons-media-document"></span></div>
                    <div class="ls-metric-info">
                        <h4>Enrolled Courses</h4>
                        <p class="ls-metric-val">6</p>
                        <span class="ls-metric-sub">Courses you're learning</span>
                    </div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-icon purple"><span class="dashicons dashicons-welcome-learn-more"></span></div>
                    <div class="ls-metric-info">
                        <h4>Lessons Completed</h4>
                        <p class="ls-metric-val">24</p>
                        <span class="ls-metric-sub">Out of 68 lessons</span>
                    </div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-icon green"><span class="dashicons dashicons-chart-line"></span></div>
                    <div class="ls-metric-info">
                        <h4>Course Progress</h4>
                        <p class="ls-metric-val">35%</p>
                        <span class="ls-metric-sub">Average progress</span>
                    </div>
                </div>
                <div class="ls-metric-card">
                    <div class="ls-metric-icon orange"><span class="dashicons dashicons-awards"></span></div>
                    <div class="ls-metric-info">
                        <h4>Certificates Earned</h4>
                        <p class="ls-metric-val">2</p>
                        <span class="ls-metric-sub">Keep up the great work!</span>
                    </div>
                </div>
            </div>

            <div class="ls-dashboard-grid-2col">
                <!-- Left Col -->
                <div>
                    <!-- Continue Learning -->
                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Continue Learning</h3>
                            <a href="#" class="ls-view-all">View All</a>
                        </div>
                        <div class="ls-continue-card">
                            <div class="ls-continue-img"></div>
                            <div class="ls-continue-info">
                                <h4>Digital Marketing Mastery</h4>
                                <div class="ls-progress-wrap">
                                    <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 65%;"></div></div>
                                    <div class="ls-progress-text">
                                        <span>65% Complete</span>
                                    </div>
                                </div>
                                <p style="font-size: 13px; color: #718096; margin-bottom: 12px;">Last lesson: Importance of Digital Marketing</p>
                                <a href="#" class="ls-btn-sm">Continue Learning</a>
                            </div>
                        </div>
                    </div>

                    <!-- My Courses List -->
                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>My Courses</h3>
                        </div>
                        <div class="ls-course-list">
                            <div class="ls-course-row">
                                <div class="ls-cr-icon"><span class="dashicons dashicons-portfolio"></span></div>
                                <div class="ls-cr-title">Digital Marketing Mastery</div>
                                <div class="ls-cr-progress">
                                    <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 65%;"></div></div>
                                </div>
                                <div class="ls-cr-status">In Progress</div>
                            </div>
                            <div class="ls-course-row">
                                <div class="ls-cr-icon"><span class="dashicons dashicons-editor-code"></span></div>
                                <div class="ls-cr-title">Web Development Fundamentals</div>
                                <div class="ls-cr-progress">
                                    <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 40%;"></div></div>
                                </div>
                                <div class="ls-cr-status">In Progress</div>
                            </div>
                            <div class="ls-course-row">
                                <div class="ls-cr-icon"><span class="dashicons dashicons-search"></span></div>
                                <div class="ls-cr-title">SEO Fundamentals</div>
                                <div class="ls-cr-progress">
                                    <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 20%; background: #f59e0b;"></div></div>
                                </div>
                                <div class="ls-cr-status">Not Started</div>
                            </div>
                        </div>
                    </div>

                    <!-- Learning Overview Chart -->
                    <div class="ls-section">
                        <div class="ls-section-header">
                            <h3>Learning Overview</h3>
                        </div>
                        <div class="ls-chart-card">
                            <canvas id="ls-learning-overview-chart" class="ls-chart-container"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Right Col -->
                <div>
                    <div class="ls-side-card" style="margin-bottom: 32px;">
                        <h4 style="text-align: left; font-weight: 700;">Up Next</h4>
                        <p style="text-align: left; margin: 0 0 16px 0;"><strong>1.3 Digital Marketing Channels Overview</strong><br>12 min</p>
                        <a href="#" class="ls-btn-sm" style="background: #fff; color: #4f46e5 !important; border: 1px solid #4f46e5; width: 100%; text-align: center;">Start Lesson</a>
                    </div>

                    <div class="ls-side-card" style="margin-bottom: 32px;">
                        <div class="ls-section-header" style="margin-bottom: 20px;">
                            <h3>Recent Achievements</h3>
                        </div>
                        <div class="ls-achievement-icon">
                            <span class="dashicons dashicons-star-filled"></span>
                        </div>
                        <h4 style="text-align: center; font-size: 14px !important; margin-bottom: 4px !important;">Lesson Completed</h4>
                        <p style="text-align: center; font-size: 12px; margin-bottom: 20px;">Complete 10 lessons<br><small>2 days ago</small></p>

                        <div class="ls-achievement-icon" style="background: #eff6ff; color: #3b82f6;">
                            <span class="dashicons dashicons-awards"></span>
                        </div>
                        <h4 style="text-align: center; font-size: 14px !important; margin-bottom: 4px !important;">Getting Started</h4>
                        <p style="text-align: center; font-size: 12px;">Enroll in your first course<br><small>1 week ago</small></p>
                        <a href="#" class="ls-view-all" style="display: block; text-align: center; margin-top: 16px;">View All</a>
                    </div>

                    <div class="ls-chart-card">
                        <h3 style="margin: 0 0 16px 0; font-size: 16px;">Time Spent Learning</h3>
                        <h2 style="margin: 0 0 16px 0; font-size: 24px;">12h 45m</h2>
                        <canvas id="ls-time-spent-chart" style="height: 150px; width: 100%;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB: My Courses -->
        <div id="tab-courses" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>My Courses</h1>
                    <p>All the courses you are currently enrolled in.</p>
                </div>
            </div>
            <div class="ls-course-list">
                <div class="ls-course-row">
                    <div class="ls-cr-icon"><span class="dashicons dashicons-portfolio"></span></div>
                    <div class="ls-cr-title">Digital Marketing Mastery</div>
                    <div class="ls-cr-progress">
                        <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 65%;"></div></div>
                    </div>
                    <div class="ls-cr-status">In Progress</div>
                </div>
                <div class="ls-course-row">
                    <div class="ls-cr-icon"><span class="dashicons dashicons-editor-code"></span></div>
                    <div class="ls-cr-title">Web Development Fundamentals</div>
                    <div class="ls-cr-progress">
                        <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 40%;"></div></div>
                    </div>
                    <div class="ls-cr-status">In Progress</div>
                </div>
                <div class="ls-course-row">
                    <div class="ls-cr-icon"><span class="dashicons dashicons-search"></span></div>
                    <div class="ls-cr-title">SEO Fundamentals</div>
                    <div class="ls-cr-progress">
                        <div class="ls-progress-bar"><div class="ls-progress-fill" style="width: 20%; background: #f59e0b;"></div></div>
                    </div>
                    <div class="ls-cr-status">Not Started</div>
                </div>
            </div>
        </div>

        <!-- TAB: Certificates -->
        <div id="tab-certificates" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Certificates</h1>
                    <p>View and download your earned certificates.</p>
                </div>
            </div>
            
            <?php 
            // We'll just fetch the first available certificate template to mock as earned for the user
            $certs = get_posts(['post_type' => 'ls_certificate', 'posts_per_page' => 1]);
            $cert_id = !empty($certs) ? $certs[0]->ID : 0;
            ?>

            <?php if ($cert_id) : ?>
                <div class="ls-dashboard-grid-2col">
                    <div class="ls-continue-card">
                        <div class="ls-continue-img" style="background: #e2e8f0; display:flex; align-items:center; justify-content:center; color:#475569;"><span class="dashicons dashicons-awards" style="font-size:32px;"></span></div>
                        <div class="ls-continue-info">
                            <h4>Digital Marketing Mastery</h4>
                            <p style="font-size: 13px; color: #718096; margin-bottom: 12px;">Earned on: <?php echo date_i18n( get_option( 'date_format' ) ); ?></p>
                            <a href="<?php echo esc_url( home_url( '/?ls_certificate=' . $cert_id . '&course_id=1' ) ); ?>" target="_blank" class="ls-btn-sm">View Certificate</a>
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <div class="ls-side-card">
                    <p>No certificates earned yet. Keep learning! (Admin needs to create a Certificate template first)</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- TAB: Achievements -->
        <div id="tab-achievements" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Achievements</h1>
                    <p>Your recent milestones and badges.</p>
                </div>
            </div>
            <div class="ls-dashboard-grid-2col">
                <div class="ls-side-card">
                    <div class="ls-achievement-icon"><span class="dashicons dashicons-star-filled"></span></div>
                    <h4 style="text-align: center;">Lesson Completed</h4>
                    <p style="text-align: center;">Complete 10 lessons</p>
                </div>
                <div class="ls-side-card">
                    <div class="ls-achievement-icon" style="background: #eff6ff; color: #3b82f6;"><span class="dashicons dashicons-awards"></span></div>
                    <h4 style="text-align: center;">Getting Started</h4>
                    <p style="text-align: center;">Enroll in your first course</p>
                </div>
            </div>
        </div>

        <!-- TAB: Wishlist -->
        <div id="tab-wishlist" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Wishlist</h1>
                    <p>Courses you've saved for later.</p>
                </div>
            </div>
            <div class="ls-side-card">
                <p>Your wishlist is empty.</p>
            </div>
        </div>

        <!-- TAB: Messages -->
        <div id="tab-messages" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Messages</h1>
                    <p>Communicate with your instructors.</p>
                </div>
            </div>
            <div class="ls-side-card">
                <p>No new messages.</p>
            </div>
        </div>

        <!-- TAB: Profile -->
        <div id="tab-profile" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Profile</h1>
                    <p>Update your personal information.</p>
                </div>
            </div>
            <div class="ls-side-card" style="text-align: left;">
                <p><strong>Name:</strong> <?php echo esc_html( $current_user->display_name ); ?></p>
                <p><strong>Email:</strong> <?php echo esc_html( $current_user->user_email ); ?></p>
                <a href="#" class="ls-btn-sm">Edit Profile</a>
            </div>
        </div>

        <!-- TAB: Settings -->
        <div id="tab-settings" class="ls-tab-pane">
            <div class="ls-top-header">
                <div class="ls-welcome-text">
                    <h1>Settings</h1>
                    <p>Manage your account preferences.</p>
                </div>
            </div>
            <div class="ls-side-card" style="text-align: left;">
                <p><strong>Email Notifications:</strong> Enabled</p>
                <p><strong>Dark Mode:</strong> Disabled</p>
                <a href="#" class="ls-btn-sm">Update Settings</a>
            </div>
        </div>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching logic
    const menuLinks = document.querySelectorAll('.ls-sidebar-menu a[data-target]');
    const tabPanes = document.querySelectorAll('.ls-tab-pane');

    menuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('data-target');
            
            // Update active menu item
            document.querySelectorAll('.ls-sidebar-menu li').forEach(li => li.classList.remove('active'));
            this.closest('li').classList.add('active');

            // Show target pane
            tabPanes.forEach(pane => {
                if(pane.id === targetId) {
                    pane.style.display = 'block';
                } else {
                    pane.style.display = 'none';
                }
            });
        });
    });

    // Hide all tabs except the active one on load
    tabPanes.forEach(pane => {
        if(!pane.classList.contains('active')) {
            pane.style.display = 'none';
        }
    });

    if (typeof Chart !== 'undefined') {
        const ctxOverview = document.getElementById('ls-learning-overview-chart');
        if (ctxOverview) {
            new Chart(ctxOverview, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Progress',
                        data: [10, 25, 45, 60, 85, 100],
                        borderColor: '#8b5cf6',
                        backgroundColor: 'rgba(139, 92, 246, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } }
            });
        }

        const ctxTime = document.getElementById('ls-time-spent-chart');
        if (ctxTime) {
            new Chart(ctxTime, {
                type: 'bar',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Hours',
                        data: [1.5, 3, 2, 4, 1, 3.5, 2.5],
                        backgroundColor: '#8b5cf6',
                        borderRadius: 4
                    }]
                },
                options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true } } }
            });
        }
    }
});
</script>
