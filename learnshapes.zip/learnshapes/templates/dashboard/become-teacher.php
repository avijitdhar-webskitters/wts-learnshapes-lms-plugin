<?php
/**
 * Become a Teacher / Instructor Template
 *
 * This template can be overridden by copying it to yourtheme/learnshapes/dashboard/become-teacher.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="learnshapes-become-teacher-wrapper" style="max-width: 600px; margin: 40px auto; padding: 40px; background: #ffffff; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); text-align: center; border: 1px solid #f1f5f9; font-family: 'Inter', sans-serif;">
	
	<?php if ( current_user_can( 'learnshapes_create_courses' ) || current_user_can( 'manage_options' ) ) : ?>
		
		<div class="ls-icon" style="font-size: 48px; color: #10b981; margin-bottom: 20px;">✔️</div>
		<h2 style="color: #0f172a; margin-bottom: 15px; font-weight: 600; font-size: 24px;"><?php esc_html_e( 'You are already an Instructor!', 'learnshapes' ); ?></h2>
		<p style="color: #475569; margin-bottom: 30px; font-size: 16px; line-height: 1.6;"><?php esc_html_e( 'You already have full access to the instructor dashboard. Start creating and managing your courses today.', 'learnshapes' ); ?></p>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=learnshapes-dashboard' ) ); ?>" class="ls-btn" style="background: #2563eb; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 500; transition: background 0.3s;"><?php esc_html_e( 'Go to Instructor Dashboard', 'learnshapes' ); ?></a>
	
	<?php else : ?>
		
		<div class="ls-icon" style="font-size: 48px; margin-bottom: 20px;">🎓</div>
		<h2 style="color: #0f172a; margin-bottom: 15px; font-weight: 600; font-size: 24px;"><?php esc_html_e( 'Become an Instructor', 'learnshapes' ); ?></h2>
		<p style="color: #475569; font-size: 16px; line-height: 1.6; margin-bottom: 30px;">
			<?php esc_html_e( 'Join our growing community of expert educators. Share your knowledge with the world, build your brand, and earn money by teaching what you love.', 'learnshapes' ); ?>
		</p>
		
		<?php if ( ! is_user_logged_in() ) : ?>
			<div style="background: #f8fafc; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0;">
				<p style="color: #475569; margin-top: 0; margin-bottom: 20px;"><?php esc_html_e( 'Please log in or register first to apply.', 'learnshapes' ); ?></p>
				<a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>" class="ls-btn" style="background: #2563eb; color: #fff; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: 500;"><?php esc_html_e( 'Log In to Apply', 'learnshapes' ); ?></a>
			</div>
		<?php else : ?>
			<div class="ls-notice ls-info" style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; color: #1e3a8a; text-align: left; border-radius: 0 8px 8px 0; margin-bottom: 25px;">
				<h4 style="margin-top: 0; margin-bottom: 10px; color: #1e40af; font-size: 16px;"><?php esc_html_e( 'Application Status', 'learnshapes' ); ?></h4>
				<p style="margin:0; font-size: 14px;"><?php esc_html_e( 'Your account currently does not have instructor privileges. Please contact the site administrator to review your profile and upgrade your account.', 'learnshapes' ); ?></p>
			</div>
			
			<div style="text-align: left; margin-top: 20px;">
				<h3 style="font-size: 18px; color: #0f172a; margin-bottom: 15px;"><?php esc_html_e( 'Why teach with us?', 'learnshapes' ); ?></h3>
				<ul style="color: #475569; padding-left: 20px; line-height: 1.6;">
					<li style="margin-bottom: 8px;"><?php esc_html_e( 'Reach a global audience of eager learners.', 'learnshapes' ); ?></li>
					<li style="margin-bottom: 8px;"><?php esc_html_e( 'Use our intuitive curriculum builder to create engaging content.', 'learnshapes' ); ?></li>
					<li style="margin-bottom: 8px;"><?php esc_html_e( 'Earn revenue with a transparent payout structure.', 'learnshapes' ); ?></li>
				</ul>
			</div>
		<?php endif; ?>
		
	<?php endif; ?>

</div>
