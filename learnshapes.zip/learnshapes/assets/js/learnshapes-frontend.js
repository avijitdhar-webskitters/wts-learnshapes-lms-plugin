/**
 * Learnshapes LMS – Frontend JavaScript
 *
 * Handles the complete enroll-button lifecycle on the course single page:
 *  1. Click "Enroll Now" / "Reserve Seat" etc.
 *  2. AJAX call → learnshapes_enroll_course
 *  3. Redirect to checkout or course page based on response.
 */
( function ( $ ) {
	'use strict';

	/* ── Helpers ──────────────────────────────────────────────────────────── */

	/**
	 * Show a toast notification at bottom-right of screen.
	 */
	function toast( msg, type ) {
		type = type || 'info'; // info | success | error | warning
		var colors = {
			info    : { bg: '#1e293b', border: '#334155' },
			success : { bg: '#064e3b', border: '#065f46' },
			error   : { bg: '#450a0a', border: '#7f1d1d' },
			warning : { bg: '#451a03', border: '#78350f' }
		};
		var c = colors[ type ] || colors.info;
		var icons = { info:'ℹ️', success:'✅', error:'❌', warning:'⚠️' };

		var $t = $( '<div class="ls-toast ls-toast-' + type + '">' +
			'<span class="ls-toast-icon">' + icons[ type ] + '</span>' +
			'<span class="ls-toast-msg">' + $( '<span>' ).text( msg ).html() + '</span>' +
			'<button class="ls-toast-close">×</button>' +
			'</div>' );

		$( 'body' ).append( $t );
		setTimeout( function () { $t.addClass( 'ls-toast-show' ); }, 10 );

		var timer = setTimeout( function () { dismissToast( $t ); }, 5000 );

		$t.find( '.ls-toast-close' ).on( 'click', function () {
			clearTimeout( timer );
			dismissToast( $t );
		} );
	}

	function dismissToast( $t ) {
		$t.removeClass( 'ls-toast-show' );
		setTimeout( function () { $t.remove(); }, 400 );
	}

	/* ── Toast CSS (injected once) ────────────────────────────────────────── */
	if ( ! $( '#ls-toast-style' ).length ) {
		$( 'head' ).append( '<style id="ls-toast-style">' +
			'#ls-toast-container,.ls-toast{position:fixed;bottom:24px;right:24px;z-index:99999}' +
			'.ls-toast{display:flex;align-items:center;gap:10px;padding:14px 18px;border-radius:10px;' +
			'color:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;' +
			'font-size:14px;font-weight:500;border-left:4px solid;box-shadow:0 8px 32px rgba(0,0,0,.35);' +
			'max-width:340px;margin-bottom:10px;opacity:0;transform:translateX(120%);' +
			'transition:opacity .35s,transform .35s;backdrop-filter:blur(8px);}' +
			'.ls-toast.ls-toast-show{opacity:1;transform:translateX(0)}' +
			'.ls-toast-info{background:rgba(30,41,59,.95);border-color:#6366f1}' +
			'.ls-toast-success{background:rgba(6,78,59,.95);border-color:#10b981}' +
			'.ls-toast-error{background:rgba(69,10,10,.95);border-color:#ef4444}' +
			'.ls-toast-warning{background:rgba(69,26,3,.95);border-color:#f59e0b}' +
			'.ls-toast-icon{font-size:18px;flex-shrink:0}' +
			'.ls-toast-msg{flex:1;line-height:1.4}' +
			'.ls-toast-close{background:none;border:none;color:#94a3b8;font-size:18px;cursor:pointer;' +
			'padding:0;line-height:1;flex-shrink:0;transition:color .15s}' +
			'.ls-toast-close:hover{color:#f1f5f9}' +
		'</style>' );
	}

	/* ── Enroll Button Handler ────────────────────────────────────────────── */

	$( document ).on( 'click', '#ls-course-action', function ( e ) {
		e.preventDefault();

		var $btn     = $( this );
		var action   = $btn.data( 'action' );
		var courseId = $btn.data( 'course-id' );

		// Already enrolled → go to course
		if ( action === 'continue' || action === 'contact' ) {
			if ( learnshapes && learnshapes.courseUrl ) {
				window.location.href = learnshapes.courseUrl;
			}
			return;
		}

		var origHtml  = $btn.html();
		var origText  = $btn.text().trim();

		$btn.prop( 'disabled', true ).html(
			'<span style="display:inline-flex;align-items:center;gap:8px;">' +
			'<svg style="animation:ls-spin 1s linear infinite;width:18px;height:18px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10" stroke-opacity=".25"/><path d="M12 2a10 10 0 0 1 10 10"/></svg>' +
			'Checking…</span>'
		);

		if ( ! $( '#ls-spin-style' ).length ) {
			$( 'head' ).append( '<style id="ls-spin-style">@keyframes ls-spin{to{transform:rotate(360deg)}}</style>' );
		}

		$.ajax( {
			url    : learnshapes.ajaxurl,
			method : 'POST',
			data   : {
				action    : 'learnshapes_enroll_course',
				nonce     : learnshapes.nonce,
				course_id : courseId
			}
		} )
		.done( function ( res ) {
			if ( res.success ) {
				var data = res.data;

				if ( data.action === 'redirect' ) {
					// Paid course – go to checkout
					toast( data.message || 'Redirecting to checkout…', 'info' );
					setTimeout( function () {
						window.location.href = data.url;
					}, 600 );

				} else if ( data.action === 'enrolled' ) {
					// Free course enrolled instantly
					toast( data.message || 'Enrolled! Redirecting…', 'success' );
					$btn.html( '✓ Enrolled!' ).css( 'background', '#10b981' );
					setTimeout( function () {
						window.location.href = data.url;
					}, 1200 );

				} else if ( data.action === 'login' ) {
					// Must log in first
					toast( data.message || 'Please log in to enroll.', 'warning' );
					$btn.prop( 'disabled', false ).html( origHtml );
					setTimeout( function () {
						window.location.href = data.url;
					}, 1500 );

				} else {
					$btn.prop( 'disabled', false ).html( origHtml );
					toast( data.message || 'Something went wrong.', 'error' );
				}
			} else {
				$btn.prop( 'disabled', false ).html( origHtml );
				toast( ( res.data && res.data.message ) || 'Enrollment failed. Please try again.', 'error' );
			}
		} )
		.fail( function () {
			$btn.prop( 'disabled', false ).html( origHtml );
			toast( 'Connection error. Please check your internet and try again.', 'error' );
		} );
	} );

	/* ── Inline purchase notice (enrollment confirmed via query string) ────── */
	if ( window.location.search.indexOf( 'ls_enrolled=1' ) !== -1 ) {
		toast( '🎉 You have been enrolled successfully!', 'success' );
	}

} )( jQuery );

