(function($) {
    'use strict';

    const canvas = $('#ls-cert-canvas');
    const inputElements = $('#ls-cert-elements');
    const bgInput = $('#ls-cert-bg_id');
    const bgBtn = $('#ls-cert-btn-bg');
    const bgRemoveBtn = $('#ls-cert-btn-remove-bg');
    
    let elements = [];
    let mediaUploader;

    function init() {
        // Load existing elements
        try {
            const saved = JSON.parse(inputElements.val());
            if (Array.isArray(saved)) {
                elements = saved;
                elements.forEach(renderElement);
            }
        } catch (e) { console.error(e); }

        // BG Image Uploader
        bgBtn.on('click', function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media({
                title: 'Choose Certificate Background',
                button: { text: 'Use as background' },
                multiple: false
            });
            mediaUploader.on('select', function() {
                const attachment = mediaUploader.state().get('selection').first().toJSON();
                bgInput.val(attachment.id);
                canvas.css('background-image', 'url(' + attachment.url + ')');
                bgRemoveBtn.show();
            });
            mediaUploader.open();
        });

        bgRemoveBtn.on('click', function() {
            bgInput.val('');
            canvas.css('background-image', 'none');
            $(this).hide();
        });

        // Add element
        $('.ls-cert-add-el').on('click', function() {
            const type = $(this).data('type');
            const newEl = {
                id: 'el_' + Date.now(),
                type: type,
                x: 100,
                y: 100,
                width: 200,
                height: type === 'qr_code' ? 100 : 40,
                text: getDefaultText(type),
                fontSize: 24,
                color: '#000000',
                fontFamily: 'Arial',
                textAlign: 'left'
            };
            elements.push(newEl);
            renderElement(newEl);
            saveElements();
        });
    }

    function getDefaultText(type) {
        const map = {
            'course_name': '[Course Name]',
            'student_name': '[Student Name]',
            'course_start_date': '[Start Date]',
            'course_end_date': '[End Date]',
            'current_time': '[Current Date]',
            'qr_code': '[QR Code]',
            'custom_text': 'Double click to edit text'
        };
        return map[type] || '[Text]';
    }

    function renderElement(el) {
        const div = $('<div class="ls-cert-el" id="'+el.id+'"></div>');
        div.css({
            left: el.x + 'px',
            top: el.y + 'px',
            width: el.width + 'px',
            height: el.height + 'px',
            fontSize: el.fontSize + 'px',
            color: el.color,
            fontFamily: el.fontFamily,
            textAlign: el.textAlign
        });

        const content = $('<div class="ls-cert-el-content"></div>').text(el.text);
        if (el.type === 'qr_code') {
            content.html('<span class="dashicons dashicons-grid-view" style="font-size: 100%; width:100%; height:100%;"></span>');
        }
        div.append(content);

        const delBtn = $('<button type="button" class="ls-cert-el-del dashicons dashicons-no"></button>');
        delBtn.on('click', function() {
            div.remove();
            elements = elements.filter(e => e.id !== el.id);
            saveElements();
        });
        div.append(delBtn);

        // Settings popup hook (double click)
        div.on('dblclick', function() {
            const newText = prompt("Enter text:", el.text);
            if (newText !== null) {
                el.text = newText;
                content.text(newText);
                saveElements();
            }
        });

        canvas.append(div);

        // Make draggable & resizable
        div.draggable({
            containment: "parent",
            stop: function(event, ui) {
                const updated = elements.find(e => e.id === el.id);
                if (updated) {
                    updated.x = ui.position.left;
                    updated.y = ui.position.top;
                    saveElements();
                }
            }
        });

        div.resizable({
            containment: "parent",
            stop: function(event, ui) {
                const updated = elements.find(e => e.id === el.id);
                if (updated) {
                    updated.width = ui.size.width;
                    updated.height = ui.size.height;
                    saveElements();
                }
            }
        });
    }

    function saveElements() {
        inputElements.val(JSON.stringify(elements));
    }

    init();

})(jQuery);
