/**
 * Curriculum Builder – Modules, Lessons, Topics with drag‑and‑drop.
 * REST API: learnshapes/v1  |  SortableJS for DnD
 */
( function ( $ ) {

    const apiRoot  = LearnshapesCurriculum.root;
    const apiNonce = LearnshapesCurriculum.nonce;
    const courseId = parseInt( $( '#learnshapes-curriculum-builder' ).data( 'course-id' ), 10 );
    const container = document.getElementById( 'learnshapes-curriculum-builder' );

    if ( ! container || ! courseId ) return;

    // -----------------------------------------------------------------------
    // Build skeleton UI immediately (no wait for API).
    // -----------------------------------------------------------------------
    const addModuleBtn = document.createElement( 'button' );
    addModuleBtn.type      = 'button';
    addModuleBtn.className = 'button button-primary ls-add-module-btn';
    addModuleBtn.innerHTML = '<span class="dashicons dashicons-plus-alt2" style="font-size: 16px; height: 16px; width: 16px; display: flex; align-items: center; justify-content: center;"></span> Add Module';
    addModuleBtn.style.cssText = 'margin-bottom:12px; display:inline-flex; align-items:center; justify-content: center; gap:6px; padding: 0 12px; min-height: 32px; line-height: 1;';
    container.appendChild( addModuleBtn );

    const treeContainer = document.createElement( 'div' );
    treeContainer.id = 'ls-curriculum-tree';
    container.appendChild( treeContainer );

    // Inline styles for the builder UI
    const style = document.createElement( 'style' );
    style.textContent = `
        #ls-curriculum-tree .ls-curriculum-root { list-style:none; margin:0; padding:0; }
        #ls-curriculum-tree .ls-module-item     { background:#fff; border:1px solid #c3c4c7; border-left:3px solid #2271b1; border-radius:4px; margin-bottom:8px; }
        #ls-curriculum-tree .ls-lesson-item     { background:#f9f9f9; border:1px solid #ddd; border-left:3px solid #72aee6; border-radius:3px; margin:6px 0 6px 20px; }
        #ls-curriculum-tree .ls-topic-item      { background:#fafafa; border:1px solid #e0e0e0; border-left:3px solid #a2bde8; border-radius:2px; margin:4px 0 4px 40px; }
        #ls-curriculum-tree .ls-lessons-list,
        #ls-curriculum-tree .ls-topics-list     { list-style:none; margin:0; padding:4px 0; }
        #ls-curriculum-tree .ls-item-header     { display:flex; align-items:center; gap:8px; padding:8px 12px; }
        #ls-curriculum-tree .ls-drag-handle     { cursor:grab; color:#aaa; flex-shrink:0; font-size:18px; }
        #ls-curriculum-tree .ls-drag-handle:active { cursor:grabbing; }
        #ls-curriculum-tree .ls-title           { flex:1; border:1px solid transparent; border-radius:3px; padding:4px 8px; background:transparent; font-size:13px; }
        #ls-curriculum-tree .ls-title:hover,
        #ls-curriculum-tree .ls-title:focus     { border-color:#72aee6; background:#fff; outline:none; }
        #ls-curriculum-tree .ls-btn-add         { background:#2271b1; color:#fff; border:none; border-radius:3px; padding:4px 10px; cursor:pointer; font-size:12px; white-space:nowrap; }
        #ls-curriculum-tree .ls-btn-add:hover   { background:#135e96; }
        #ls-curriculum-tree .ls-btn-del         { background:#fff; color:#b32d2e; border:1px solid #d63638; border-radius:3px; padding:4px 10px; cursor:pointer; font-size:12px; white-space:nowrap; }
        #ls-curriculum-tree .ls-btn-del:hover   { background:#fcf0f1; }
        #ls-curriculum-tree .ls-btn-edit        { display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; background:#f6f7f7; border:1px solid #c3c4c7; border-radius:3px; color:#2271b1; text-decoration:none; flex-shrink:0; transition:background 0.15s,border-color 0.15s; }
        #ls-curriculum-tree .ls-btn-edit:hover  { background:#2271b1; color:#fff; border-color:#2271b1; }
        #ls-curriculum-tree .ls-btn-edit .dashicons { font-size:14px; width:14px; height:14px; line-height:1; }
        #ls-curriculum-tree .ls-btn-add:disabled,
        #ls-curriculum-tree .ls-btn-del:disabled { opacity:0.6; cursor:not-allowed; }
        .ls-cb-spinner { display:inline-block; width:14px; height:14px; border:2px solid rgba(255,255,255,0.4); border-top-color:#fff; border-radius:50%; animation:ls-spin 0.6s linear infinite; vertical-align:middle; }
        .ls-cb-spinner-dark { border-color:rgba(0,0,0,0.2); border-top-color:#b32d2e; }
        @keyframes ls-spin { to { transform:rotate(360deg); } }
        .ls-tree-loader { display:flex; align-items:center; gap:10px; color:#646970; padding:16px 0; }
        .ls-tree-loader .ls-cb-spinner { border-color:rgba(0,0,0,0.15); border-top-color:#2271b1; }
    `;
    document.head.appendChild( style );



    // -----------------------------------------------------------------------
    // Debounce helper – fires saveOrder at most once per 800ms of inactivity.
    // -----------------------------------------------------------------------
    let saveTimer = null;
    function debouncedSave() {
        clearTimeout( saveTimer );
        saveTimer = setTimeout( saveOrder, 800 );
    }

    // -----------------------------------------------------------------------
    // Load structure from server.
    // -----------------------------------------------------------------------
    function loadStructure() {
        treeContainer.innerHTML = '<div class="ls-tree-loader"><span class="ls-cb-spinner"></span> Loading curriculum...</div>';
        return fetch( `${apiRoot}/curriculum/course/${courseId}`, {
            method:  'GET',
            headers: { 'X-WP-Nonce': apiNonce }
        } )
            .then( r => r.json() )
            .then( data => {
                if ( data.success ) {
                    renderTree( Array.isArray( data.structure ) ? data.structure : [] );
                } else {
                    treeContainer.innerHTML = '<p style="color:#b32d2e;">Could not load curriculum.</p>';
                }
            } )
            .catch( err => {
                console.error( 'Curriculum load error:', err );
                treeContainer.innerHTML = '<p style="color:#b32d2e;">Connection error. Please reload.</p>';
            } );
    }

    // -----------------------------------------------------------------------
    // Render tree.
    // -----------------------------------------------------------------------
    function renderTree( structure ) {
        treeContainer.innerHTML = '';
        const ul = document.createElement( 'ul' );
        ul.className = 'ls-curriculum-root';

        structure.forEach( module => ul.appendChild( createModuleItem( module ) ) );
        treeContainer.appendChild( ul );

        new Sortable( ul, { animation:150, handle:'.ls-drag-handle', onEnd: debouncedSave } );
    }

    // -----------------------------------------------------------------------
    // Create DOM items.
    // -----------------------------------------------------------------------
    function createModuleItem( module ) {
        const li = document.createElement( 'li' );
        li.className  = 'ls-module-item';
        li.dataset.id = module.id;

        const header = document.createElement( 'div' );
        header.className = 'ls-item-header';

        const drag = mkEl( 'span', 'ls-drag-handle dashicons dashicons-move' );
        const titleInput = mkInput( module.title, 'Module title' );
        const editLink = mkEditLink( module.id );
        const addBtn  = mkBtn( '+ Lesson', 'ls-btn-add' );
        const delBtn  = mkBtn( 'Delete',   'ls-btn-del' );

        header.append( drag, titleInput, editLink, addBtn, delBtn );
        li.appendChild( header );

        const lessonUl = document.createElement( 'ul' );
        lessonUl.className = 'ls-lessons-list';
        ( module.items || [] ).forEach( lesson => lessonUl.appendChild( createLessonItem( lesson ) ) );
        li.appendChild( lessonUl );

        new Sortable( lessonUl, { animation:150, handle:'.ls-drag-handle', group:'lessons', onEnd: debouncedSave } );

        // Events
        titleInput.addEventListener( 'change', () => updateTitle( module.id, titleInput.value, 'module' ) );

        addBtn.addEventListener( 'click', () => {
            setLoading( addBtn, true, 'Adding...' );
            apiPost( `${apiRoot}/curriculum/lesson`, { parent_id: module.id, course_id: courseId, title: 'New Lesson' } )
                .then( data => {
                    if ( data.success ) {
                        const newLi = createLessonItem( { id: data.id, title: 'New Lesson', items: [] } );
                        lessonUl.appendChild( newLi );
                        debouncedSave();
                    }
                } )
                .finally( () => setLoading( addBtn, false, '+ Lesson' ) );
        } );

        delBtn.addEventListener( 'click', () => {
            if ( ! confirm( LearnshapesCurriculum.l10n.confirmDelete ) ) return;
            setLoading( delBtn, true, 'Deleting...', true );
            apiFetch( `${apiRoot}/curriculum/module/${module.id}`, 'DELETE' )
                .then( data => {
                    if ( data.success ) {
                        li.remove();
                        debouncedSave();
                    } else {
                        setLoading( delBtn, false, 'Delete', true );
                    }
                } )
                .catch( () => setLoading( delBtn, false, 'Delete', true ) );
        } );

        return li;
    }

    function createLessonItem( lesson ) {
        const li = document.createElement( 'li' );
        li.className  = 'ls-lesson-item';
        li.dataset.id = lesson.id;

        const header = document.createElement( 'div' );
        header.className = 'ls-item-header';

        const drag = mkEl( 'span', 'ls-drag-handle dashicons dashicons-move' );
        const titleInput = mkInput( lesson.title, 'Lesson title' );
        const editLink = mkEditLink( lesson.id );
        const addBtn  = mkBtn( '+ Topic', 'ls-btn-add' );
        const delBtn  = mkBtn( 'Delete',  'ls-btn-del' );

        header.append( drag, titleInput, editLink, addBtn, delBtn );
        li.appendChild( header );

        const topicUl = document.createElement( 'ul' );
        topicUl.className = 'ls-topics-list';
        ( lesson.items || [] ).forEach( topic => topicUl.appendChild( createTopicItem( topic ) ) );
        li.appendChild( topicUl );

        new Sortable( topicUl, { animation:150, handle:'.ls-drag-handle', group:'topics', onEnd: debouncedSave } );

        titleInput.addEventListener( 'change', () => updateTitle( lesson.id, titleInput.value, 'lesson' ) );

        addBtn.addEventListener( 'click', () => {
            setLoading( addBtn, true, 'Adding...' );
            apiPost( `${apiRoot}/curriculum/topic`, { parent_id: lesson.id, course_id: courseId, title: 'New Topic' } )
                .then( data => {
                    if ( data.success ) {
                        topicUl.appendChild( createTopicItem( { id: data.id, title: 'New Topic' } ) );
                        debouncedSave();
                    }
                } )
                .finally( () => setLoading( addBtn, false, '+ Topic' ) );
        } );

        delBtn.addEventListener( 'click', () => {
            if ( ! confirm( LearnshapesCurriculum.l10n.confirmDelete ) ) return;
            setLoading( delBtn, true, 'Deleting...', true );
            apiFetch( `${apiRoot}/curriculum/lesson/${lesson.id}`, 'DELETE' )
                .then( data => {
                    if ( data.success ) {
                        li.remove();
                        debouncedSave();
                    } else {
                        setLoading( delBtn, false, 'Delete', true );
                    }
                } )
                .catch( () => setLoading( delBtn, false, 'Delete', true ) );
        } );

        return li;
    }

    function createTopicItem( topic ) {
        const li = document.createElement( 'li' );
        li.className  = 'ls-topic-item';
        li.dataset.id = topic.id;

        const header = document.createElement( 'div' );
        header.className = 'ls-item-header';

        const drag = mkEl( 'span', 'ls-drag-handle dashicons dashicons-move' );
        const titleInput = mkInput( topic.title, 'Topic title' );
        const editLink = mkEditLink( topic.id );
        const delBtn  = mkBtn( 'Delete', 'ls-btn-del' );

        header.append( drag, titleInput, editLink, delBtn );
        li.appendChild( header );

        titleInput.addEventListener( 'change', () => updateTitle( topic.id, titleInput.value, 'topic' ) );

        delBtn.addEventListener( 'click', () => {
            if ( ! confirm( LearnshapesCurriculum.l10n.confirmDelete ) ) return;
            setLoading( delBtn, true, 'Deleting...', true );
            apiFetch( `${apiRoot}/curriculum/topic/${topic.id}`, 'DELETE' )
                .then( data => {
                    if ( data.success ) {
                        li.remove();
                        debouncedSave();
                    } else {
                        setLoading( delBtn, false, 'Delete', true );
                    }
                } )
                .catch( () => setLoading( delBtn, false, 'Delete', true ) );
        } );

        return li;
    }

    // -----------------------------------------------------------------------
    // Add Module button handler.
    // -----------------------------------------------------------------------
    addModuleBtn.addEventListener( 'click', () => {
        setLoading( addModuleBtn, true, 'Adding...' );
        apiPost( `${apiRoot}/curriculum/module`, { title: 'New Module', course_id: courseId } )
            .then( data => {
                if ( data.success ) {
                    let ul = treeContainer.querySelector( '.ls-curriculum-root' );
                    if ( ! ul ) {
                        // First module — create the list
                        ul = document.createElement( 'ul' );
                        ul.className = 'ls-curriculum-root';
                        treeContainer.innerHTML = '';
                        treeContainer.appendChild( ul );
                        new Sortable( ul, { animation:150, handle:'.ls-drag-handle', onEnd: debouncedSave } );
                    }
                    ul.appendChild( createModuleItem( { id: data.id, title: 'New Module', items: [] } ) );
                    debouncedSave();
                }
            } )
            .finally( () => setLoading( addModuleBtn, false, '<span class="dashicons dashicons-plus-alt2" style="font-size: 16px; height: 16px; width: 16px; display: flex; align-items: center; justify-content: center;"></span> Add Module' ) );
    } );

    // -----------------------------------------------------------------------
    // Save full order to server.
    // -----------------------------------------------------------------------
    function saveOrder() {
        const modules = [];
        treeContainer.querySelectorAll( '.ls-module-item' ).forEach( modEl => {
            const lessons = [];
            modEl.querySelectorAll( ':scope > .ls-lessons-list > .ls-lesson-item' ).forEach( lesEl => {
                const topics = [];
                lesEl.querySelectorAll( ':scope > .ls-topics-list > .ls-topic-item' ).forEach( topEl => {
                    topics.push( { id: parseInt( topEl.dataset.id, 10 ), title: topEl.querySelector('.ls-title').value.trim() } );
                } );
                lessons.push( { id: parseInt( lesEl.dataset.id, 10 ), title: lesEl.querySelector('.ls-title').value.trim(), items: topics } );
            } );
            modules.push( { id: parseInt( modEl.dataset.id, 10 ), title: modEl.querySelector('.ls-title').value.trim(), items: lessons } );
        } );

        fetch( `${apiRoot}/curriculum/course/${courseId}/structure`, {
            method:  'POST',
            headers: { 'X-WP-Nonce': apiNonce, 'Content-Type': 'application/json' },
            body:    JSON.stringify( { structure: modules } )
        } ).catch( console.error );
    }

    // -----------------------------------------------------------------------
    // Update a single title without saving the full structure.
    // -----------------------------------------------------------------------
    function updateTitle( id, title, type ) {
        fetch( `${apiRoot}/curriculum/${type}/${id}`, {
            method:  'PATCH',
            headers: { 'X-WP-Nonce': apiNonce, 'Content-Type': 'application/json' },
            body:    JSON.stringify( { title } )
        } ).catch( console.error );
    }

    // -----------------------------------------------------------------------
    // Shared fetch helpers.
    // -----------------------------------------------------------------------
    function apiPost( url, body ) {
        return fetch( url, {
            method:  'POST',
            headers: { 'X-WP-Nonce': apiNonce, 'Content-Type': 'application/json' },
            body:    JSON.stringify( body )
        } ).then( r => r.json() );
    }

    function apiFetch( url, method ) {
        return fetch( url, {
            method:  method,
            headers: { 'X-WP-Nonce': apiNonce }
        } ).then( r => r.json() );
    }

    // -----------------------------------------------------------------------
    // DOM helpers.
    // -----------------------------------------------------------------------
    function mkEl( tag, cls ) {
        const el = document.createElement( tag );
        el.className = cls;
        return el;
    }

    function mkInput( value, placeholder ) {
        const inp = document.createElement( 'input' );
        inp.type        = 'text';
        inp.className   = 'ls-title';
        inp.value       = value || '';
        inp.placeholder = placeholder;
        return inp;
    }

    function mkBtn( label, cls ) {
        const btn = document.createElement( 'button' );
        btn.type      = 'button';
        btn.className = cls;
        btn.innerHTML = label;
        return btn;
    }

    function mkEditLink( postId ) {
        const adminUrl = ( LearnshapesCurriculum.adminUrl || '' );
        const a = document.createElement( 'a' );
        a.href      = adminUrl + '?post=' + postId + '&action=edit';
        a.target    = '_blank';
        a.className = 'ls-btn-edit';
        a.title     = 'Edit this item';
        a.innerHTML = '<span class="dashicons dashicons-edit"></span>';
        return a;
    }

    /**
     * Toggle button loading state.
     * @param {HTMLButtonElement} btn
     * @param {boolean} loading
     * @param {string} loadingLabel  – shown while loading
     * @param {boolean} dark         – use dark spinner (for delete buttons)
     */
    function setLoading( btn, loading, loadingLabel, dark = false ) {
        if ( loading ) {
            btn._origHTML   = btn.innerHTML;
            btn.disabled    = true;
            const spinClass = dark ? 'ls-cb-spinner ls-cb-spinner-dark' : 'ls-cb-spinner';
            btn.innerHTML   = `<span class="${spinClass}"></span> ${loadingLabel}`;
        } else {
            btn.disabled  = false;
            btn.innerHTML = loadingLabel; // loadingLabel is the restored label when loading=false
        }
    }

    // -----------------------------------------------------------------------
    // Boot – ensure SortableJS is available then load.
    // -----------------------------------------------------------------------
    function boot() {
        if ( typeof Sortable !== 'undefined' ) {
            loadStructure();
        } else {
            const s   = document.createElement( 'script' );
            s.src     = 'https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js';
            s.onload  = loadStructure;
            s.onerror = () => { treeContainer.innerHTML = '<p style="color:#b32d2e;">SortableJS failed to load.</p>'; };
            document.head.appendChild( s );
        }
    }

    $( document ).ready( boot );

} )( jQuery );
