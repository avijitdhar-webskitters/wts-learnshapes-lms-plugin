(function($) {
    'use strict';

    if (typeof LearnshapesQuiz === 'undefined') return;

    const apiRoot = LearnshapesQuiz.root;
    const apiNonce = LearnshapesQuiz.nonce;
    let quizId = 0;
    
    // We will manage the questions state in JS and save to REST API
    let questions = [];

    const appContainer = document.getElementById('ls-quiz-builder-app');
    if (!appContainer) return;

    quizId = appContainer.dataset.quizId;

    function init() {
        // Fetch existing questions
        fetch(`${apiRoot}/quiz/${quizId}/questions`, {
            method: 'GET',
            headers: { 'X-WP-Nonce': apiNonce }
        })
        .then(r => r.json())
        .then(data => {
            if (data.success && Array.isArray(data.questions)) {
                questions = data.questions;
            } else {
                questions = [];
            }
            renderApp();
        })
        .catch(err => {
            console.error(err);
            questions = [];
            renderApp(); // Render empty
        });
    }

    function saveQuestions() {
        // Debounced or manual save
        fetch(`${apiRoot}/quiz/${quizId}/questions`, {
            method: 'POST',
            headers: { 'X-WP-Nonce': apiNonce, 'Content-Type': 'application/json' },
            body: JSON.stringify({ questions: questions })
        }).then(r => r.json()).then(res => {
            // handle res
        });
    }

    function renderApp() {
        appContainer.innerHTML = '';

        const listContainer = document.createElement('div');
        listContainer.className = 'ls-quiz-questions-list';

        questions.forEach((q, index) => {
            listContainer.appendChild(createQuestionEl(q, index));
        });

        appContainer.appendChild(listContainer);

        // Add new question row
        const addRow = document.createElement('div');
        addRow.className = 'ls-quiz-add-row';
        addRow.innerHTML = `
            <div class="ls-add-input-wrap">
                <span class="dashicons dashicons-plus"></span>
                <input type="text" id="ls-new-q-title" placeholder="Create a new question" />
            </div>
            <div class="ls-add-actions">
                <select id="ls-new-q-type">
                    <option value="single">Single Choice</option>
                    <option value="multi">Multi Choice</option>
                    <option value="true_false">True Or False</option>
                    <option value="blanks">Fill In Blanks</option>
                </select>
                <button type="button" class="button button-primary" id="ls-btn-add-q">Add Question</button>
                <button type="button" class="button" id="ls-btn-q-bank">Question Bank</button>
            </div>
        `;
        appContainer.appendChild(addRow);

        document.getElementById('ls-btn-add-q').addEventListener('click', () => {
            const title = document.getElementById('ls-new-q-title').value.trim();
            if (!title) return;
            const type = document.getElementById('ls-new-q-type').value;
            
            const newQ = {
                id: 'new_' + Date.now(),
                title: title,
                type: type,
                description: '',
                answers: createDefaultAnswers(type),
                points: 1,
                hint: '',
                explanation: '',
                expanded: true
            };
            questions.push(newQ);
            saveQuestions();
            renderApp();
        });
    }

    function createDefaultAnswers(type) {
        if (type === 'true_false') {
            return [
                { id: 'a1', text: 'True', isCorrect: true },
                { id: 'a2', text: 'False', isCorrect: false }
            ];
        }
        return [
            { id: 'a1', text: 'First option', isCorrect: true },
            { id: 'a2', text: 'Second option', isCorrect: false },
            { id: 'a3', text: 'Third option', isCorrect: false }
        ];
    }

    function createQuestionEl(q, index) {
        const el = document.createElement('div');
        el.className = 'ls-quiz-question-item';
        if (q.expanded) el.classList.add('expanded');

        const header = document.createElement('div');
        header.className = 'ls-qq-header';
        header.innerHTML = `
            <div class="ls-qq-title-wrap">
                <span class="dashicons dashicons-move"></span>
                <span class="ls-qq-toggle dashicons ${q.expanded ? 'dashicons-arrow-down-alt2' : 'dashicons-arrow-right-alt2'}"></span>
                <strong>${q.title}</strong>
            </div>
            <div class="ls-qq-actions">
                <span class="ls-qq-type">${formatType(q.type)}</span>
                <button type="button" class="ls-qq-delete dashicons dashicons-trash"></button>
            </div>
        `;

        header.querySelector('.ls-qq-toggle').addEventListener('click', () => {
            q.expanded = !q.expanded;
            renderApp();
        });
        
        header.querySelector('.ls-qq-title-wrap strong').addEventListener('click', () => {
            q.expanded = !q.expanded;
            renderApp();
        });

        header.querySelector('.ls-qq-delete').addEventListener('click', (e) => {
            e.stopPropagation();
            if (confirm(LearnshapesQuiz.l10n.deleteConfirm)) {
                questions.splice(index, 1);
                saveQuestions();
                renderApp();
            }
        });

        el.appendChild(header);

        if (q.expanded) {
            const body = document.createElement('div');
            body.className = 'ls-qq-body';
            
            // Description
            const descHtml = `
                <div class="ls-qq-section">
                    <label>Description</label>
                    <textarea class="ls-qq-desc" placeholder="Question description...">${q.description}</textarea>
                </div>
            `;

            // Main Editor Layout
            const editorGrid = document.createElement('div');
            editorGrid.className = 'ls-qq-editor-grid';

            // Left side: Answers
            let answersHtml = '';
            q.answers.forEach((ans, aIndex) => {
                let controlHtml = '';
                if (q.type === 'single' || q.type === 'true_false') {
                    controlHtml = `<input type="radio" name="q_${q.id}_correct" value="${aIndex}" ${ans.isCorrect ? 'checked' : ''} />`;
                } else if (q.type === 'multi') {
                    controlHtml = `<input type="checkbox" class="q-multi-correct" data-idx="${aIndex}" ${ans.isCorrect ? 'checked' : ''} />`;
                } else if (q.type === 'blanks') {
                    controlHtml = `<span class="dashicons dashicons-yes"></span>`; // blanks logic is different, text match
                }

                answersHtml += `
                    <div class="ls-qq-answer-row">
                        <span class="dashicons dashicons-menu"></span>
                        <input type="text" class="ls-qq-answer-text" data-idx="${aIndex}" value="${ans.text}" ${q.type === 'true_false' ? 'readonly' : ''} />
                        <div class="ls-qq-answer-control">${controlHtml}</div>
                        ${q.type !== 'true_false' ? `<button type="button" class="ls-qq-answer-del dashicons dashicons-no-alt" data-idx="${aIndex}"></button>` : ''}
                    </div>
                `;
            });

            // Right side: Options
            const optsHtml = `
                <div class="ls-qq-options">
                    <div class="ls-qq-options-header">Option Details <span class="dashicons dashicons-arrow-up-alt2"></span></div>
                    <div class="ls-qq-options-body">
                        <div class="ls-qq-opt-row">
                            <label>Points</label>
                            <input type="number" class="ls-qq-points" value="${q.points}" min="1" />
                            <p class="description">Points for choosing the correct answer.</p>
                        </div>
                        <div class="ls-qq-opt-row">
                            <label>Hint</label>
                            <textarea class="ls-qq-hint">${q.hint}</textarea>
                            <p class="description">Instructions shown when users click Hint.</p>
                        </div>
                        <div class="ls-qq-opt-row">
                            <label>Explanation</label>
                            <textarea class="ls-qq-exp">${q.explanation}</textarea>
                            <p class="description">Displayed when students click Check Answer.</p>
                        </div>
                    </div>
                </div>
            `;

            body.innerHTML = `
                ${descHtml}
                <div class="ls-qq-split">
                    <div class="ls-qq-answers-wrap">
                        <div class="ls-qq-answers-header">
                            <strong>Config Your Answer</strong>
                            <span>${formatType(q.type)}</span>
                        </div>
                        <div class="ls-qq-answers-list">
                            <div class="ls-qq-answers-col-headers">
                                <span>Answers</span>
                                <span>Corrects</span>
                            </div>
                            ${answersHtml}
                        </div>
                        ${q.type !== 'true_false' ? `<div class="ls-qq-add-ans-wrap"><button type="button" class="button ls-btn-add-ans">Add Option</button></div>` : ''}
                    </div>
                    ${optsHtml}
                </div>
            `;

            // Bind events for inputs
            body.querySelector('.ls-qq-desc').addEventListener('change', (e) => { q.description = e.target.value; saveQuestions(); });
            body.querySelector('.ls-qq-points').addEventListener('change', (e) => { q.points = parseInt(e.target.value, 10); saveQuestions(); });
            body.querySelector('.ls-qq-hint').addEventListener('change', (e) => { q.hint = e.target.value; saveQuestions(); });
            body.querySelector('.ls-qq-exp').addEventListener('change', (e) => { q.explanation = e.target.value; saveQuestions(); });

            // Answer bindings
            body.querySelectorAll('.ls-qq-answer-text').forEach(inp => {
                inp.addEventListener('change', (e) => {
                    const idx = e.target.dataset.idx;
                    q.answers[idx].text = e.target.value;
                    saveQuestions();
                });
            });

            if (q.type === 'single' || q.type === 'true_false') {
                body.querySelectorAll(`input[name="q_${q.id}_correct"]`).forEach(radio => {
                    radio.addEventListener('change', (e) => {
                        const idx = parseInt(e.target.value, 10);
                        q.answers.forEach((a, i) => a.isCorrect = (i === idx));
                        saveQuestions();
                    });
                });
            } else if (q.type === 'multi') {
                body.querySelectorAll('.q-multi-correct').forEach(chk => {
                    chk.addEventListener('change', (e) => {
                        const idx = e.target.dataset.idx;
                        q.answers[idx].isCorrect = e.target.checked;
                        saveQuestions();
                    });
                });
            }

            // Add answer
            const addAnsBtn = body.querySelector('.ls-btn-add-ans');
            if (addAnsBtn) {
                addAnsBtn.addEventListener('click', () => {
                    q.answers.push({ id: 'a' + Date.now(), text: 'New option', isCorrect: false });
                    saveQuestions();
                    renderApp();
                });
            }

            // Del answer
            body.querySelectorAll('.ls-qq-answer-del').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const idx = e.target.dataset.idx;
                    q.answers.splice(idx, 1);
                    saveQuestions();
                    renderApp();
                });
            });

            el.appendChild(body);
        }

        return el;
    }

    function formatType(type) {
        const map = {
            'single': 'Single Choice',
            'multi': 'Multi Choice',
            'true_false': 'True Or False',
            'blanks': 'Fill In Blanks'
        };
        return map[type] || type;
    }

    // Start
    init();

})(jQuery);
