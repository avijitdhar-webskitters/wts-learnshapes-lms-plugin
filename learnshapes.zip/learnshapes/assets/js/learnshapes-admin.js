/**
 * Learnshapes LMS - Admin JavaScript.
 *
 * Core interactive dashboard and settings panel logic.
 */
jQuery(document).ready(function($) {
    console.log('Learnshapes LMS admin console loaded.');
});
