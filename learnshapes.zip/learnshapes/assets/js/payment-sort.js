/**
 * assets/js/payment-sort.js
 * Drag-and-drop payment method ordering in Learnshapes Settings > Payments tab.
 * Persists the new order via AJAX using learnshapes_save_payment_order.
 */
jQuery( function ( $ ) {
    'use strict';

    // The payment methods table is inside the #payment-general subpanel.
    var $tbody = $( '#payment-general table.wp-list-table tbody' );

    if ( ! $tbody.length ) {
        return; // Not on the right page / panel.
    }

    // Map display labels to option-key suffixes.
    function gatewayId( $row ) {
        var small = $.trim( $row.find( 'td small' ).first().text() ).toLowerCase();
        if ( small ) return small;
        // Fallback: derive from the checkbox name attribute.
        var name = $row.find( 'input[type="checkbox"]' ).first().attr( 'name' ) || '';
        var m = name.match( /learnshapes_payment_([a-z]+)\[/ );
        return m ? m[1] : '';
    }

    $tbody.sortable( {
        placeholder : 'ls-sortable-placeholder',
        axis        : 'y',
        cursor      : 'grabbing',
        handle      : 'td:first-child',
        update: function () {
            var order = {};
            $tbody.find( 'tr' ).each( function ( index ) {
                var id = gatewayId( $( this ) );
                if ( id ) {
                    order[ id ] = index + 1;
                }
            } );

            $.post( learnshapesPaymentSort.ajaxurl, {
                action : 'learnshapes_save_payment_order',
                nonce  : learnshapesPaymentSort.nonce,
                order  : order
            } ).done( function ( res ) {
                if ( res.success ) {
                    // Brief visual feedback.
                    $tbody.closest( 'table' ).css( { 'outline': '2px solid #6366f1', 'outline-offset': '2px' } );
                    setTimeout( function () {
                        $tbody.closest( 'table' ).css( { 'outline': '' } );
                    }, 1000 );
                } else {
                    console.warn( 'Failed to save payment order', res );
                }
            } ).fail( function () {
                console.error( 'AJAX request failed when saving payment order.' );
            } );
        }
    } );

    // Add drag cursor style to first column.
    $tbody.find( 'td:first-child' ).css( 'cursor', 'grab' );
} );
