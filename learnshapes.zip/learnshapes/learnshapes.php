<?php
/**
 * Plugin Name: Learnshapes
 * Plugin URI: https://learnshapes.com
 * Description: Learnshapes is a modern, feature-rich WordPress LMS plugin for creating, managing, selling, and delivering online learning experiences.
 * Version: 1.0.0
 * Author: Avijit Dhar
 * Author URI: https://avijitdhar.com
 * License: GPL2 or later
 * Text Domain: learnshapes
 * Domain Path: /languages
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define Plugin Constants.
define( 'LEARNSHAPES_VERSION', '1.0.0' );
define( 'LEARNSHAPES_PATH', plugin_dir_path( __FILE__ ) );
define( 'LEARNSHAPES_URL', plugin_dir_url( __FILE__ ) );
define( 'LEARNSHAPES_BASENAME', plugin_basename( __FILE__ ) );

// PSR-4 Autoloader.
spl_autoload_register( function ( $class ) {
	// Project-specific namespace prefix.
	$prefix = 'Learnshapes\\';

	// Base directory for the namespace prefix.
	$base_dir = LEARNSHAPES_PATH . 'includes/';

	// Does the class use the namespace prefix?
	$len = strlen( $prefix );
	if ( strncmp( $prefix, $class, $len ) !== 0 ) {
		// No, move to the next registered autoloader.
		return;
	}

	// Get the relative class name.
	$relative_class = substr( $class, $len );

	// Replace the namespace prefix with the base directory, replace namespace
	// separators with directory separators in the relative class name, append
	// with .php.
	$file = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

	// If the file exists, require it.
	if ( file_exists( $file ) ) {
		require $file;
	}
} );

// Initialize the plugin.
add_action( 'plugins_loaded', function() {
	\Learnshapes\Core\Plugin::instance();
} );

// Register Activation and Deactivation Hooks.
register_activation_hook( __FILE__, [ '\Learnshapes\Database\Schema', 'activate' ] );
register_deactivation_hook( __FILE__, [ '\Learnshapes\Database\Schema', 'deactivate' ] );
